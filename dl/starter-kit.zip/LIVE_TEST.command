#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 qa_live_test.py
echo
read '?Press [Enter] to close...'
