export function extractMessageDetails(message) {
  const unwrapped = unwrapMessage(message)
  const contentKeys = Object.keys(unwrapped || {})
  const messageType = contentKeys[0] || "unknown"
  const payload = messageType === "unknown" ? {} : (unwrapped[messageType] || {})

  const direct = directTextFor(messageType, payload)
  if (direct) {
    return {
      text: direct.text,
      deliveryMode: direct.deliveryMode,
      messageType: direct.messageType,
      usedFallbackSummary: false,
      isUnknownShape: false,
      contentKeys,
    }
  }

  const fallback = fallbackSummaryFor(messageType, payload)
  return {
    text: fallback.text,
    deliveryMode: fallback.deliveryMode,
    messageType: fallback.messageType,
    usedFallbackSummary: true,
    isUnknownShape: fallback.isUnknownShape,
    contentKeys,
  }
}

function unwrapMessage(message) {
  let current = message || {}
  for (;;) {
    if (current.ephemeralMessage?.message) {
      current = current.ephemeralMessage.message
      continue
    }
    if (current.viewOnceMessage?.message) {
      current = current.viewOnceMessage.message
      continue
    }
    if (current.editedMessage?.message) {
      current = current.editedMessage.message
      continue
    }
    if (current.protocolMessage?.editedMessage) {
      current = current.protocolMessage.editedMessage
      continue
    }
    if (current.templateMessage?.hydratedTemplate?.hydratedContentText) {
      return { conversation: current.templateMessage.hydratedTemplate.hydratedContentText }
    }
    return current
  }
}

function directTextFor(messageType, payload) {
  if (messageType === "conversation" && typeof payload === "string") {
    return { text: payload, deliveryMode: "text", messageType: "conversation" }
  }
  if (messageType === "extendedTextMessage" && payload?.text) {
    return { text: payload.text, deliveryMode: "text", messageType: "extendedTextMessage" }
  }
  if (messageType === "imageMessage" && payload?.caption) {
    return { text: payload.caption, deliveryMode: "image_caption", messageType: "imageMessage" }
  }
  if (messageType === "videoMessage" && payload?.caption) {
    return { text: payload.caption, deliveryMode: "video_caption", messageType: "videoMessage" }
  }
  if (messageType === "pollCreationMessage" && payload?.name) {
    return { text: payload.name, deliveryMode: "poll_creation", messageType: "pollCreationMessage" }
  }
  if (messageType === "buttonsResponseMessage" && payload?.selectedDisplayText) {
    return { text: payload.selectedDisplayText, deliveryMode: "text", messageType: "buttonsResponseMessage" }
  }
  if (messageType === "listResponseMessage" && payload?.title) {
    return { text: payload.title, deliveryMode: "text", messageType: "listResponseMessage" }
  }
  return null
}

function fallbackSummaryFor(messageType, payload) {
  switch (messageType) {
    case "imageMessage":
      return { text: "Image shared", deliveryMode: "image", messageType, isUnknownShape: false }
    case "videoMessage":
      return { text: "Video shared", deliveryMode: "video", messageType, isUnknownShape: false }
    case "documentMessage":
      return { text: payload?.fileName ? `Document shared | ${payload.fileName}` : "Document shared", deliveryMode: "document", messageType, isUnknownShape: false }
    case "reactionMessage":
      return { text: payload?.text ? `Reaction: ${payload.text}` : "Reaction added", deliveryMode: "reaction", messageType, isUnknownShape: false }
    case "locationMessage":
      return { text: ["Location shared", payload?.name, payload?.address].filter(Boolean).join(" | "), deliveryMode: "location", messageType, isUnknownShape: false }
    case "audioMessage":
      return { text: payload?.ptt ? "Voice note" : "Audio shared", deliveryMode: payload?.ptt ? "voice_note" : "audio", messageType, isUnknownShape: false }
    case "contactMessage":
      return { text: payload?.displayName ? `Contact card | ${payload.displayName}` : "Contact card shared", deliveryMode: "contact", messageType, isUnknownShape: false }
    case "pollUpdateMessage":
      return { text: "Poll response update", deliveryMode: "poll_update", messageType, isUnknownShape: false }
    default:
      return { text: "Non-text message (unknown)", deliveryMode: "metadata_only:unknown", messageType: "unknown", isUnknownShape: true }
  }
}
