#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 doctor_runtime.py
echo
read '?Press [Enter] to close...'
