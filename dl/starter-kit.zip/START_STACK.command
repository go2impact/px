#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 stack_control.py start native baileys merge packets soak
echo
read '?Press [Enter] to close...'
