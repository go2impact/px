#!/usr/bin/env node

import { Boom } from '@hapi/boom'
import NodeCache from '@cacheable/node-cache'
import makeWASocket, {
  DisconnectReason,
  fetchLatestBaileysVersion,
  isJidNewsletter,
  isJidStatusBroadcast,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
} from '@whiskeysockets/baileys'
import P from 'pino'
import qrcode from 'qrcode-terminal'
import { mkdir, appendFile, readFile, rename, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { extractMessageDetails } from './baileys_message_normalization.mjs'

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url))
const BASE_DIR = process.env.COLLECTOR_BASE_DIR
  ? path.resolve(process.env.COLLECTOR_BASE_DIR)
  : SCRIPT_DIR
const AUTH_DIR = path.join(BASE_DIR, 'baileys_auth_info')
const EVENT_LOG_PATH = path.join(BASE_DIR, 'baileys-events.jsonl')
const SHAPE_CAPTURE_PATH = path.join(BASE_DIR, 'baileys-shape-corpus.jsonl')
const GROUP_CACHE_PATH = path.join(BASE_DIR, 'baileys-group-cache.json')
const STATUS_PATH = path.join(BASE_DIR, 'baileys-status.json')
const COLLECTOR_VERSION = '0.1.1'
const PARSER_VERSION = 'baileys_group_collector_v2'
const SOURCE_TYPE = 'baileys'
const COLLECTOR_INSTANCE_ID = process.env.COLLECTOR_INSTANCE_ID || 'baileys_group_collector'
const INITIAL_RECONNECT_DELAY_MS = 1_000
const MAX_RECONNECT_DELAY_MS = 60_000
const DEDUPE_HYDRATE_LINE_LIMIT = 50_000
const CONNECTED_HEARTBEAT_INTERVAL_MS = 30_000
const SHAPE_CAPTURE_MAX_BYTES = 10 * 1024 * 1024
const SHAPE_CAPTURE_TRIM_TARGET_LINES = 2_000

const logger = P({ level: process.env.LOG_LEVEL || 'info' })
const retryCache = new NodeCache()
const emittedEventCache = new NodeCache({ stdTTL: 6 * 60 * 60, checkperiod: 600, useClones: false })
const groupCache = new Map()
let reconnectDelayMs = INITIAL_RECONNECT_DELAY_MS
let lastEventAt = null
let lastStatus = 'starting'
let activeSocket = null
let restartTimer = null
let startPromise = null
let socketGeneration = 0
let statusWriteQueue = Promise.resolve()
let connectedHeartbeatTimer = null
let duplicateSuppressedCount = 0
let cryptoSignalCount = 0
let shapeCaptureCount = 0
let unknownShapeCount = 0

function utcNow() {
  return new Date().toISOString()
}

function isGroupJid(remoteJid) {
  return typeof remoteJid === 'string' && remoteJid.endsWith('@g.us')
}

function confidenceFor(text, sender) {
  let score = 0.5
  if (sender) score += 0.15
  if (text) score += 0.2
  return Math.min(score, 0.95)
}

function cryptoSignalFor(msg) {
  const retryCount = Number(msg?.retryCount || 0)
  const hasSenderKeyDistribution = Boolean(msg?.message?.senderKeyDistributionMessage)
  return {
    retryCount,
    hasSenderKeyDistribution,
    observed: retryCount > 0 || hasSenderKeyDistribution,
    kind: retryCount > 0 ? 'retry_receipt' : hasSenderKeyDistribution ? 'sender_key_distribution' : null,
  }
}

function dedupeKeyFor(event) {
  if (event.source_message_id) {
    return `${event.remote_jid || 'unknown-chat'}:${event.source_message_id}`
  }
  return `${event.remote_jid || 'unknown-chat'}:${event.message_timestamp || event.message_text || utcNow()}`
}

async function loadGroupCache() {
  try {
    const raw = await readFile(GROUP_CACHE_PATH, 'utf8')
    const data = JSON.parse(raw)
    for (const [jid, subject] of Object.entries(data)) {
      groupCache.set(jid, subject)
    }
  } catch {
    // cache is optional
  }
}

async function saveGroupCache() {
  const payload = JSON.stringify(Object.fromEntries(groupCache), null, 2)
  await appendFile(GROUP_CACHE_PATH, '')
  await writeFileAtomic(GROUP_CACHE_PATH, payload)
}

async function writeFileAtomic(filePath, contents) {
  const tmp = `${filePath}.${process.pid}.${Date.now()}.${randomUUID()}.tmp`
  await writeFile(tmp, contents, 'utf8')
  await rename(tmp, filePath)
}

async function appendJsonl(event) {
  await appendFile(EVENT_LOG_PATH, `${JSON.stringify(event)}\n`, 'utf8')
}

async function appendShapeCapture(shapeCapture) {
  await appendFile(SHAPE_CAPTURE_PATH, `${JSON.stringify(shapeCapture)}\n`, 'utf8')
  await compactShapeCaptureIfNeeded()
}

async function compactShapeCaptureIfNeeded() {
  try {
    const fileStat = await stat(SHAPE_CAPTURE_PATH)
    if (fileStat.size <= SHAPE_CAPTURE_MAX_BYTES) {
      return
    }
    const raw = await readFile(SHAPE_CAPTURE_PATH, 'utf8')
    const lines = raw
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
    const keptLines = lines.slice(-SHAPE_CAPTURE_TRIM_TARGET_LINES)
    await writeFileAtomic(
      SHAPE_CAPTURE_PATH,
      keptLines.length ? `${keptLines.join('\n')}\n` : ''
    )
    logger.warn(
      {
        max_bytes: SHAPE_CAPTURE_MAX_BYTES,
        trim_target_lines: SHAPE_CAPTURE_TRIM_TARGET_LINES,
        prior_lines: lines.length,
        kept_lines: keptLines.length,
      },
      'trimmed shape capture corpus after size cap'
    )
  } catch (error) {
    logger.error({ err: error }, 'failed to compact shape capture corpus')
  }
}

async function hydrateRecentDedupes() {
  try {
    const raw = await readFile(EVENT_LOG_PATH, 'utf8')
    const lines = raw
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
      .slice(-DEDUPE_HYDRATE_LINE_LIMIT)
    let hydrated = 0
    for (const line of lines) {
      try {
        const event = JSON.parse(line)
        if (!event?.remote_jid || !event?.source_message_id) {
          continue
        }
        emittedEventCache.set(`${event.remote_jid}:${event.source_message_id}`, true)
        hydrated += 1
      } catch {
        // ignore malformed scratch lines
      }
    }
    return hydrated
  } catch {
    return 0
  }
}

async function writeStatus(partial) {
  statusWriteQueue = statusWriteQueue
    .catch((error) => {
      logger.error({ err: error }, 'prior status write failed')
    })
    .then(async () => {
      lastStatus = partial.state || lastStatus
      let previous = {}
      try {
        previous = JSON.parse(await readFile(STATUS_PATH, 'utf8'))
      } catch {
        previous = {}
      }
      for (const legacyField of [
        'recovery_signal_count',
        'last_recovery_signal_at',
        'last_recovery_signal_kind',
        'last_recovery_source_message_id',
        'last_recovery_remote_jid',
        'last_recovery_retry_count',
      ]) {
        delete previous[legacyField]
      }
      const carried = {}
      for (const field of ['login_method', 'qr_payload', 'pairing_code', 'pairing_phone_e164', 'last_pairing_error']) {
        if (!(field in partial) && previous[field] !== undefined) {
          carried[field] = previous[field]
        }
      }
      const payload = {
        ...previous,
        source_type: SOURCE_TYPE,
        collector_instance_id: COLLECTOR_INSTANCE_ID,
        collector_version: COLLECTOR_VERSION,
        parser_version: PARSER_VERSION,
        auth_dir: AUTH_DIR,
        event_log_path: EVENT_LOG_PATH,
        group_cache_path: GROUP_CACHE_PATH,
        state: lastStatus,
        last_event_at: lastEventAt,
        reconnect_delay_ms: reconnectDelayMs,
        duplicate_suppressed_count: duplicateSuppressedCount,
        crypto_signal_count: cryptoSignalCount,
        updated_at: utcNow(),
        ...carried,
        ...partial,
      }
      await writeFileAtomic(STATUS_PATH, JSON.stringify(payload, null, 2))
    })
  return statusWriteQueue
}

async function resolveGroupSubject(sock, remoteJid) {
  if (groupCache.has(remoteJid)) {
    return groupCache.get(remoteJid)
  }
  try {
    const metadata = await sock.groupMetadata(remoteJid)
    const subject = metadata?.subject || remoteJid
    groupCache.set(remoteJid, subject)
    await saveGroupCache()
    return subject
  } catch (error) {
    logger.warn({ remoteJid, err: error }, 'failed to resolve group metadata')
    return remoteJid
  }
}

async function normalizeGroupMessage(sock, msg, details = extractMessageDetails(msg?.message)) {
  const remoteJid = msg?.key?.remoteJid
  if (!isGroupJid(remoteJid) || isJidNewsletter(remoteJid) || isJidStatusBroadcast(remoteJid)) {
    return null
  }

  const participant = msg.key?.participant || null
  const sender = msg.pushName || participant || null
  const text = details.text
  const messageType = details.messageType
  const chatName = await resolveGroupSubject(sock, remoteJid)
  const sourceMessageId = msg.key?.id || null
  const sourceEmittedAt = msg.messageTimestamp ? new Date(Number(msg.messageTimestamp) * 1000).toISOString() : null

  return {
    event_id: sourceMessageId || `${remoteJid}:${msg.messageTimestamp || utcNow()}`,
    schema_version: '2026-04-08.baileys-v1',
    event_type: 'whatsapp_message',
    observed_at: utcNow(),
    source_type: SOURCE_TYPE,
    source_instance_id: COLLECTOR_INSTANCE_ID,
    source_message_id: sourceMessageId,
    source_emitted_at: sourceEmittedAt,
    collector_version: COLLECTOR_VERSION,
    parser_version: PARSER_VERSION,
    message_type: messageType,
    delivery_mode: details.deliveryMode,
    confidence: confidenceFor(text, sender),
    completeness: {
      has_chat_name: Boolean(chatName),
      has_sender: Boolean(sender),
      has_text: Boolean(text),
    },
    remote_jid: remoteJid,
    conversation_key: remoteJid,
    conversation_display: chatName,
    participant_jid: participant,
    sender_key: participant,
    sender_display: sender,
    message_timestamp: msg.messageTimestamp ? String(msg.messageTimestamp) : null,
    from_me: Boolean(msg.key?.fromMe),
    chat_name: chatName,
    sender,
    message_text: text,
    message_shape: {
      content_keys: details.contentKeys,
      used_fallback_summary: details.usedFallbackSummary,
      is_unknown_shape: details.isUnknownShape,
    },
    raw_message: msg,
  }
}

function shouldCaptureShape(details) {
  if (details.isUnknownShape) {
    return true
  }
  if (details.usedFallbackSummary) {
    return true
  }
  return details.deliveryMode !== 'text'
}

async function recordShapeCapture(event, details) {
  const observedAt = utcNow()
  shapeCaptureCount += 1
  if (details.isUnknownShape) {
    unknownShapeCount += 1
  }
  await appendShapeCapture({
    observed_at: observedAt,
    source_type: SOURCE_TYPE,
    source_instance_id: COLLECTOR_INSTANCE_ID,
    collector_version: COLLECTOR_VERSION,
    parser_version: PARSER_VERSION,
    remote_jid: event.remote_jid,
    conversation_display: event.conversation_display,
    participant_jid: event.participant_jid,
    sender_display: event.sender_display,
    source_message_id: event.source_message_id,
    source_emitted_at: event.source_emitted_at,
    message_type: event.message_type,
    delivery_mode: event.delivery_mode,
    message_text: event.message_text,
    used_fallback_summary: details.usedFallbackSummary,
    is_unknown_shape: details.isUnknownShape,
    content_keys: details.contentKeys,
    raw_message: event.raw_message,
  })
  await writeStatus({
    state: 'connected',
    last_shape_capture_at: observedAt,
    last_shape_message_type: event.message_type,
    last_shape_delivery_mode: event.delivery_mode,
    last_shape_source_message_id: event.source_message_id,
    last_shape_remote_jid: event.remote_jid,
    shape_capture_count: shapeCaptureCount,
    unknown_shape_count: unknownShapeCount,
  })
}

async function recordCryptoSignal(partial) {
  cryptoSignalCount += 1
  await writeStatus({
    state: 'connected',
    last_crypto_signal_at: utcNow(),
    crypto_signal_count: cryptoSignalCount,
    ...partial,
  })
}

function stopConnectedHeartbeat() {
  if (connectedHeartbeatTimer) {
    clearInterval(connectedHeartbeatTimer)
    connectedHeartbeatTimer = null
  }
}

function startConnectedHeartbeat(generation) {
  stopConnectedHeartbeat()
  connectedHeartbeatTimer = setInterval(() => {
    if (generation !== socketGeneration || !activeSocket || lastStatus !== 'connected') {
      return
    }
    void writeStatus({
      state: 'connected',
      connection_heartbeat_at: utcNow(),
    })
  }, CONNECTED_HEARTBEAT_INTERVAL_MS)
}

function scheduleRestart() {
  if (restartTimer) {
    return
  }
  const delay = reconnectDelayMs
  reconnectDelayMs = Math.min(reconnectDelayMs * 2, MAX_RECONNECT_DELAY_MS)
  restartTimer = setTimeout(() => {
    restartTimer = null
    start().catch((error) => {
      logger.error({ err: error }, 'failed to restart baileys collector')
      process.exitCode = 1
    })
  }, delay)
}

async function start() {
  if (startPromise) {
    return startPromise
  }
  if (activeSocket && lastStatus !== 'logged_out') {
    logger.info({ state: lastStatus }, 'baileys collector already has an active socket')
    return
  }

  startPromise = (async () => {
    if (restartTimer) {
      clearTimeout(restartTimer)
      restartTimer = null
    }
    stopConnectedHeartbeat()

    await mkdir(AUTH_DIR, { recursive: true })
    await loadGroupCache()
    const hydratedRecentEventKeys = await hydrateRecentDedupes()
    await writeStatus({
      state: 'starting',
      dedupe_hydrated_at: utcNow(),
      hydrated_recent_event_keys: hydratedRecentEventKeys,
      last_event_at: null,
      last_remote_jid: null,
      last_source_message_id: null,
      last_shape_capture_at: null,
      last_shape_message_type: null,
      last_shape_delivery_mode: null,
      last_shape_source_message_id: null,
      last_shape_remote_jid: null,
      duplicate_suppressed_count: duplicateSuppressedCount,
      crypto_signal_count: cryptoSignalCount,
      shape_capture_count: shapeCaptureCount,
      unknown_shape_count: unknownShapeCount,
    })

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      version,
      logger,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, logger),
      },
      msgRetryCounterCache: retryCache,
      syncFullHistory: false,
      markOnlineOnConnect: false,
      generateHighQualityLinkPreview: false,
    })

    const generation = ++socketGeneration
    activeSocket = sock
    let pairingRequested = false

    sock.ev.on('creds.update', async () => {
      if (generation !== socketGeneration) {
        return
      }
      await saveCreds()
      await writeStatus({
        last_creds_updated_at: utcNow(),
      })
    })

    sock.ev.on('connection.update', async (update) => {
      if (generation !== socketGeneration) {
        return
      }
      const { connection, lastDisconnect, qr } = update

      if (qr) {
        await writeStatus({
          state: 'qr_required',
          login_method: process.env.WA_PHONE_E164 ? 'pairing_code' : 'qr',
          qr_payload: process.env.WA_PHONE_E164 ? null : qr,
          pairing_code: null,
          pairing_phone_e164: process.env.WA_PHONE_E164 || null,
        })
        if (process.env.WA_PHONE_E164 && !pairingRequested && !sock.authState.creds.registered) {
          pairingRequested = true
          try {
            const code = await sock.requestPairingCode(process.env.WA_PHONE_E164)
            await writeStatus({
              state: 'pairing_code_ready',
              login_method: 'pairing_code',
              qr_payload: null,
              pairing_code: code,
              pairing_phone_e164: process.env.WA_PHONE_E164,
              last_pairing_error: null,
            })
            logger.info({ code }, 'pairing code ready')
          } catch (error) {
            await writeStatus({
              state: 'pairing_code_error',
              login_method: 'pairing_code',
              qr_payload: qr,
              pairing_code: null,
              pairing_phone_e164: process.env.WA_PHONE_E164,
              last_pairing_error: error instanceof Error ? error.message : String(error),
            })
            logger.warn({ err: error }, 'pairing code request failed; qr fallback available')
            qrcode.generate(qr, { small: true })
          }
        } else {
          qrcode.generate(qr, { small: true })
        }
      }

      if (connection === 'open') {
        reconnectDelayMs = INITIAL_RECONNECT_DELAY_MS
        const connectedAt = utcNow()
        await writeStatus({
          state: 'connected',
          connected_at: connectedAt,
          connection_heartbeat_at: connectedAt,
          last_event_at: null,
          last_remote_jid: null,
          last_source_message_id: null,
          user_id: sock.user?.id || null,
          login_method: null,
          qr_payload: null,
          pairing_code: null,
          pairing_phone_e164: null,
        })
        startConnectedHeartbeat(generation)
        logger.info({ user: sock.user?.id }, 'baileys collector connected')
        return
      }

      if (connection === 'close') {
        const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
        const needsReauth = statusCode === DisconnectReason.badSession
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut && !needsReauth
        activeSocket = null
        stopConnectedHeartbeat()
        await writeStatus({
          state: needsReauth ? 'needs_reauth' : shouldReconnect ? 'reconnecting' : 'logged_out',
          last_disconnected_at: utcNow(),
          last_disconnect_status_code: statusCode || null,
          qr_payload: null,
          pairing_code: null,
        })
        logger.warn({ statusCode, shouldReconnect, needsReauth }, 'baileys connection closed')
        if (shouldReconnect) {
          scheduleRestart()
        }
      }
    })

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (generation !== socketGeneration) {
        return
      }
      if (type !== 'notify' && type !== 'append') {
        return
      }

      for (const msg of messages) {
        if (msg.key?.fromMe) {
          continue
        }

        if (!msg?.message) {
          if (isGroupJid(msg?.key?.remoteJid)) {
            await recordCryptoSignal({
              last_crypto_signal_kind: 'missing_message_payload',
              last_crypto_signal_remote_jid: msg.key?.remoteJid || null,
              last_crypto_signal_source_message_id: msg.key?.id || null,
            })
            logger.info(
              {
                remote_jid: msg.key?.remoteJid || null,
                source_message_id: msg.key?.id || null,
              },
              'group update observed without materialized message payload'
            )
          }
          continue
        }

        const details = extractMessageDetails(msg.message)
        const event = await normalizeGroupMessage(sock, msg, details)
        if (!event) {
          continue
        }

        const cryptoSignal = cryptoSignalFor(msg)
        const dedupeKey = dedupeKeyFor(event)
        if (emittedEventCache.has(dedupeKey)) {
          duplicateSuppressedCount += 1
          await writeStatus({
            state: 'connected',
            last_duplicate_suppressed_at: utcNow(),
            last_duplicate_source_message_id: event.source_message_id,
            last_duplicate_remote_jid: event.remote_jid,
          })
          logger.info(
            {
              remote_jid: event.remote_jid,
              source_message_id: event.source_message_id,
              dedupe_key: dedupeKey,
            },
            'duplicate source event suppressed'
          )
          continue
        }

        await appendJsonl(event)
        emittedEventCache.set(dedupeKey, true)
        if (shouldCaptureShape(details)) {
          await recordShapeCapture(event, details)
        }
        lastEventAt = utcNow()
        const statusUpdate = {
          state: 'connected',
          last_event_at: lastEventAt,
          last_remote_jid: event.remote_jid,
          last_source_message_id: event.source_message_id,
        }
        if (cryptoSignal.observed) {
          cryptoSignalCount += 1
          statusUpdate.last_crypto_signal_at = lastEventAt
          statusUpdate.last_crypto_signal_kind = cryptoSignal.kind
          statusUpdate.last_crypto_signal_source_message_id = event.source_message_id
          statusUpdate.last_crypto_signal_remote_jid = event.remote_jid
          statusUpdate.last_crypto_signal_retry_count = cryptoSignal.retryCount
          statusUpdate.crypto_signal_count = cryptoSignalCount
        }
        await writeStatus({
          ...statusUpdate,
        })
        logger.info(
          {
            remote_jid: event.remote_jid,
            chat_name: event.chat_name,
            sender: event.sender,
            message_text: event.message_text,
            crypto_signal_kind: cryptoSignal.kind,
            retry_count: cryptoSignal.retryCount,
          },
          'group message captured'
        )
      }
    })

    sock.ev.on('messages.update', async (updates) => {
      if (generation !== socketGeneration) {
        return
      }
      for (const updateEvent of updates || []) {
        const remoteJid = updateEvent?.key?.remoteJid
        if (!isGroupJid(remoteJid)) {
          continue
        }
        const update = updateEvent?.update || {}
        const hasMessage = Boolean(update.message)
        const hasPollUpdates = Array.isArray(update.pollUpdates) && update.pollUpdates.length > 0
        const hasStatus = update.status !== undefined
        const kind = hasMessage
          ? 'message_update'
          : hasPollUpdates
            ? 'poll_update_without_message'
            : hasStatus
              ? 'status_update_without_message'
              : 'messages_update_without_message'
        if (hasMessage) {
          const signal = cryptoSignalFor({ message: update.message })
          if (!signal.observed) {
            continue
          }
        }
        await recordCryptoSignal({
          last_crypto_signal_kind: kind,
          last_crypto_signal_remote_jid: remoteJid,
          last_crypto_signal_source_message_id: updateEvent?.key?.id || null,
        })
        logger.info(
          {
            remote_jid: remoteJid,
            source_message_id: updateEvent?.key?.id || null,
            kind,
          },
          'group messages.update signal observed'
        )
      }
    })
  })()

  try {
    await startPromise
  } finally {
    startPromise = null
  }
}

start().catch((error) => {
  logger.error({ err: error }, 'baileys collector crashed')
  process.exit(1)
})
