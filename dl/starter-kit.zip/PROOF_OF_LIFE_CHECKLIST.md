# Proof Of Life Checklist

Use this after a fresh install, after recovery, or before handing the bundle to
someone else.

## Prerequisites

- The observer phone is powered on and still owns the WhatsApp account.
- The Mac is awake and allowed to show WhatsApp notifications.
- `npm install` has already completed.

## Checklist

1. Run `python3 doctor_runtime.py`.
2. Confirm there is no obvious install blocker.
3. Start the stack:
   - `python3 stack_control.py start native baileys merge packets soak`
4. Run `python3 stack_control.py status`.
5. Confirm:
   - `native` is not `down`
   - `baileys` is `connected_idle`, `healthy`, or clearly asking for onboarding
   - `packets` is not `down`
6. If Baileys needs registration, run `npm run baileys:onboarding` and link the phone.
7. Pick a unique test phrase such as `LIVE TEST 48271`.
8. Run `python3 qa_live_test.py --token "LIVE TEST 48271" --no-prompt`.
9. Send that exact phrase from a different WhatsApp account into a monitored group.
10. Let the helper wait for the packet layer to update.
11. If it fails, inspect `operator-packets-latest.json`.
12. Confirm the packet shows the right group, sender, and test text.

## Pass criteria

- A fresh group message becomes a packet row.
- `best_source_type` is ideally `baileys`.
- The status files still look healthy after the test.

## If it fails

- Read `TROUBLESHOOTING_AND_RECOVERY.md`.
- Then inspect:
  - `baileys-status.json`
  - `merge-status.json`
  - `packet-status.json`
  - `runtime/soak-status.json`
