#!/usr/bin/env python3
"""
Local runtime controller for the notification probe stack.

Keeps the short-run processes explicit:
- native notification watcher
- richer Baileys collector
- canonical merge follower

This avoids guessing from hanging terminals and makes duplicate-process cleanup
mechanical instead of manual.
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
MANAGED_ENV_PATH = RUNTIME_DIR / "launcher-managed-env.json"
MANAGED_ENV_KEYS = {
    "WA_PHONE_E164",
    "WA_PACKET_WEBHOOK_URL",
    "WA_PACKET_EVENT_COMMAND",
    "WA_PACKET_RELAY",
    "WA_PRIMARY_DESTINATION",
    "WA_AFTER_HOURS_DESTINATION",
    "WA_BACKUP_DESTINATION",
    "WA_PACKET_DISPATCH_NOT_BEFORE",
    "WA_PENDING_REPLIES_PATH",
    "WA_IMESSAGE_SERVICE",
    "WA_IMESSAGE_CHAT_GUID",
    "WA_OPERATOR_HANDLES",
}


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def parse_iso_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def freshness_age_seconds(value: str | None) -> float | None:
    parsed = parse_iso_timestamp(value)
    if parsed is None:
        return None
    return (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()


def describe_disconnect_status(status_code: int | None) -> str | None:
    if status_code is None:
        return None
    labels = {
        401: "logged_out",
        403: "forbidden",
        408: "timed_out_or_connection_lost",
        428: "precondition_failed",
        440: "stale_session",
        500: "server_error",
        515: "restart_required",
    }
    return labels.get(status_code, f"status_{status_code}")


def join_multi_values(values: list[str] | None) -> str | None:
    if not values:
        return None
    normalized: list[str] = []
    for raw in values:
        for piece in raw.split(","):
            value = piece.strip()
            if value:
                normalized.append(value)
    if not normalized:
        return None
    return ",".join(normalized)


def load_managed_env_state() -> dict[str, dict[str, str]]:
    if not MANAGED_ENV_PATH.exists():
        return {}
    try:
        payload = json.loads(MANAGED_ENV_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}
    state: dict[str, dict[str, str]] = {}
    for proc_name, values in payload.items():
        if not isinstance(proc_name, str) or not isinstance(values, dict):
            continue
        filtered = {
            str(key): str(value)
            for key, value in values.items()
            if isinstance(key, str) and isinstance(value, str) and key in MANAGED_ENV_KEYS
        }
        state[proc_name] = filtered
    return state


def save_managed_env_state(state: dict[str, dict[str, str]]) -> None:
    MANAGED_ENV_PATH.write_text(
        json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


@dataclass(frozen=True)
class ProcSpec:
    name: str
    argv: list[str]
    match_substring: str
    health_kind: str | None = None

    @property
    def pidfile(self) -> Path:
        return RUNTIME_DIR / f"{self.name}.pid"

    @property
    def logfile(self) -> Path:
        return RUNTIME_DIR / f"{self.name}.log"


SPECS = {
    "native": ProcSpec(
        name="native",
        argv=[
            sys.executable,
            str(BASE_DIR / "poll_whatsapp_notifications.py"),
            "--event-log",
            str(BASE_DIR / "events.jsonl"),
        ],
        match_substring=str(BASE_DIR / "poll_whatsapp_notifications.py"),
        health_kind="native",
    ),
    "baileys": ProcSpec(
        name="baileys",
        argv=[
            "node",
            str(BASE_DIR / "baileys_group_collector.mjs"),
        ],
        match_substring=str(BASE_DIR / "baileys_group_collector.mjs"),
        health_kind="baileys",
    ),
    "merge": ProcSpec(
        name="merge",
        argv=[
            sys.executable,
            str(BASE_DIR / "merge_collector_events.py"),
            "--native-log",
            str(BASE_DIR / "events.jsonl"),
            "--baileys-log",
            str(BASE_DIR / "baileys-events.jsonl"),
            "--db",
            str(BASE_DIR / "merged-events.sqlite3"),
            "--follow",
        ],
        match_substring=str(BASE_DIR / "merge_collector_events.py"),
        health_kind="merge",
    ),
    "packets": ProcSpec(
        name="packets",
        argv=[
            sys.executable,
            str(BASE_DIR / "emit_operator_packets.py"),
            "--process-role",
            "packets",
            "--follow",
        ],
        match_substring=f"{BASE_DIR / 'emit_operator_packets.py'} --process-role packets",
        health_kind="packets",
    ),
    "actions": ProcSpec(
        name="actions",
        argv=[
            sys.executable,
            str(BASE_DIR / "emit_operator_packets.py"),
            "--process-role",
            "actions",
            "--poll-imessage-actions",
            "--follow",
            "--action-status-json",
            str(RUNTIME_DIR / "operator-actions-status.json"),
        ],
        match_substring=f"{BASE_DIR / 'emit_operator_packets.py'} --process-role actions",
        health_kind="actions",
    ),
    "soak": ProcSpec(
        name="soak",
        argv=[
            sys.executable,
            str(BASE_DIR / "stack_soak_watch.py"),
        ],
        match_substring=str(BASE_DIR / "stack_soak_watch.py"),
        health_kind="soak",
    ),
}


def read_pid(pidfile: Path) -> int | None:
    try:
        return int(pidfile.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def process_command(pid: int) -> str | None:
    try:
        output = subprocess.check_output(
            ["ps", "-p", str(pid), "-o", "command="],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, PermissionError):
        return None
    return output or None


def process_matches(pid: int, match_substring: str) -> bool:
    command = process_command(pid)
    return bool(command and match_substring in command)


def discover_pids(match_substring: str) -> tuple[list[int], bool]:
    try:
        output = subprocess.check_output(
            ["ps", "-axww", "-o", "pid=,command="],
            text=True,
            stderr=subprocess.DEVNULL,
        ).splitlines()
    except (subprocess.CalledProcessError, PermissionError):
        return [], True
    pids: list[int] = []
    current_pid = os.getpid()
    for line in output:
        parts = line.rstrip().split(maxsplit=1)
        if not parts:
            continue
        try:
            pid = int(parts[0])
        except ValueError:
            continue
        command = parts[1] if len(parts) > 1 else ""
        if pid == current_pid:
            continue
        if match_substring not in command:
            continue
        pids.append(pid)
    return pids, False


def known_pids(spec: ProcSpec) -> list[int]:
    discovered, inspection_blocked = discover_pids(spec.match_substring)
    pidfile_pid = read_pid(spec.pidfile)
    if pidfile_pid and process_matches(pidfile_pid, spec.match_substring):
        if pidfile_pid not in discovered:
            discovered.append(pidfile_pid)
    elif pidfile_pid and not discovered and inspection_blocked:
        # When process inspection is blocked, prefer conservative pidfile reuse
        # over accidentally spawning duplicate long-running collectors.
        discovered.append(pidfile_pid)
    return sorted(set(discovered))


def start_proc(spec: ProcSpec) -> dict[str, object]:
    return start_proc_with_env(spec, None)


def start_proc_with_env(spec: ProcSpec, env_overrides: dict[str, str] | None) -> dict[str, object]:
    existing = known_pids(spec)
    if existing:
        spec.pidfile.write_text(f"{existing[0]}\n", encoding="utf-8")
        return {
            "name": spec.name,
            "action": "already_running",
            "pids": existing,
            "pidfile": str(spec.pidfile),
            "logfile": str(spec.logfile),
        }

    env = os.environ.copy()
    for key in MANAGED_ENV_KEYS:
        env.pop(key, None)
    if env_overrides:
        env.update(env_overrides)

    with spec.logfile.open("ab") as handle:
        proc = subprocess.Popen(
            spec.argv,
            cwd=str(BASE_DIR),
            stdout=handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            env=env,
        )
    spec.pidfile.write_text(f"{proc.pid}\n", encoding="utf-8")
    return {
        "name": spec.name,
        "action": "started",
        "pid": proc.pid,
        "pidfile": str(spec.pidfile),
        "logfile": str(spec.logfile),
        "started_at": utc_now(),
        "env_overrides": env_overrides or {},
    }


def stop_pid(pid: int, timeout: float = 3.0) -> str:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return "missing"

    deadline = time.time() + timeout
    while time.time() < deadline:
        if process_command(pid) is None:
            return "terminated"
        time.sleep(0.1)

    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return "terminated"
    return "killed"


def stop_proc(spec: ProcSpec) -> dict[str, object]:
    pids = known_pids(spec)
    results = []
    for pid in pids:
        results.append({"pid": pid, "result": stop_pid(pid)})
    try:
        spec.pidfile.unlink()
    except FileNotFoundError:
        pass
    return {
        "name": spec.name,
        "action": "stopped",
        "results": results,
    }


def native_health() -> dict[str, object] | None:
    db_path = BASE_DIR / "observer.sqlite3"
    if not db_path.exists():
        return None
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        heartbeat = conn.execute(
            """
            SELECT source, observed_at, details_json
            FROM heartbeats
            WHERE source = 'notification_center_ax'
            ORDER BY observed_at DESC
            LIMIT 1
            """
        ).fetchone()
        if heartbeat is None:
            return None
        details = json.loads(heartbeat["details_json"]) if heartbeat["details_json"] else {}
        return {
            "observed_at": heartbeat["observed_at"],
            "details": details,
        }
    finally:
        conn.close()


def merge_health() -> dict[str, object] | None:
    status_path = BASE_DIR / "merge-status.json"
    if not status_path.exists():
        return None
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    heartbeats = payload.get("heartbeats") or []
    heartbeat = heartbeats[0] if heartbeats else None
    return {
        "observed_at": heartbeat.get("observed_at") if heartbeat else None,
        "details": heartbeat.get("details") if heartbeat else {},
        "ingested": payload.get("ingested"),
        "duplicates": payload.get("duplicates"),
        "parse_errors": payload.get("parse_errors"),
        "source_event_count": payload.get("source_event_count"),
        "canonical_event_count": payload.get("canonical_event_count"),
        "provisional_canonical_count": payload.get("provisional_canonical_count"),
        "confirmed_canonical_count": payload.get("confirmed_canonical_count"),
        "rich_provisional_canonical_count": payload.get("rich_provisional_canonical_count"),
        "notification_provisional_canonical_count": payload.get("notification_provisional_canonical_count"),
        "last_source_event": payload.get("last_source_event"),
        "last_canonical_event": payload.get("last_canonical_event"),
    }


def baileys_health() -> dict[str, object] | None:
    status_path = BASE_DIR / "baileys-status.json"
    if not status_path.exists():
        return None
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return {
        "observed_at": payload.get("updated_at"),
        "details": payload,
    }


def packets_health() -> dict[str, object] | None:
    status_path = BASE_DIR / "packet-status.json"
    if not status_path.exists():
        return None
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return {
        "observed_at": payload.get("observed_at"),
        "details": payload.get("details") or {},
    }


def actions_health() -> dict[str, object] | None:
    status_path = RUNTIME_DIR / "operator-actions-status.json"
    if not status_path.exists():
        return None
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return {
        "observed_at": payload.get("observed_at"),
        "details": payload,
    }


def soak_health() -> dict[str, object] | None:
    status_path = RUNTIME_DIR / "soak-status.json"
    if not status_path.exists():
        return None
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return {
        "observed_at": payload.get("observed_at"),
        "details": payload,
    }


def status_proc(spec: ProcSpec) -> dict[str, object]:
    pidfile_pid = read_pid(spec.pidfile)
    running_pids = known_pids(spec)
    managed_env_state = load_managed_env_state()
    managed_env = managed_env_state.get(spec.name) or {}
    if running_pids and pidfile_pid != running_pids[0]:
        spec.pidfile.write_text(f"{running_pids[0]}\n", encoding="utf-8")
        pidfile_pid = running_pids[0]
    if spec.health_kind == "native":
        health = native_health()
    elif spec.health_kind == "merge":
        health = merge_health()
    elif spec.health_kind == "baileys":
        health = baileys_health()
    elif spec.health_kind == "packets":
        health = packets_health()
    elif spec.health_kind == "actions":
        health = actions_health()
    elif spec.health_kind == "soak":
        health = soak_health()
    else:
        health = None
    age_seconds = freshness_age_seconds((health or {}).get("observed_at") if health else None)
    state_summary = summarize_state(spec, pidfile_pid, running_pids, health)
    recommended_action = recommend_action(spec, state_summary, health)
    return {
        "name": spec.name,
        "pidfile_pid": pidfile_pid,
        "running_pids": running_pids,
        "pidfile": str(spec.pidfile),
        "logfile": str(spec.logfile),
        "managed_env": managed_env,
        "state_summary": state_summary,
        "age_seconds": age_seconds,
        "recommended_action": recommended_action,
        "health": health,
    }


def summarize_state(
    spec: ProcSpec,
    pidfile_pid: int | None,
    running_pids: list[int],
    health: dict[str, object] | None,
) -> str:
    if spec.health_kind == "baileys":
        details = (health or {}).get("details") or {}
        state = details.get("state")
        if state in {"qr_required", "pairing_code_ready"}:
            return "registration_required"
        if state == "pairing_code_error":
            return "registration_required"
        if state == "connected":
            age = freshness_age_seconds((health or {}).get("observed_at"))
            if details.get("last_event_at") is None:
                if age is not None and age <= 120:
                    return "connected_idle"
                return "stale"
            if age is not None and age <= 120:
                return "healthy"
            return "stale"
        if state in {"reconnecting", "creds_updated", "starting"}:
            return "starting"
        if state == "needs_reauth":
            return "needs_reauth"
        if state == "logged_out":
            return "logged_out"
        return "down"

    if spec.health_kind == "merge":
        last_source = (health or {}).get("last_source_event") or {}
        canonical_count = (health or {}).get("canonical_event_count") or 0
        provisional_count = (health or {}).get("provisional_canonical_count") or 0
        confirmed_count = (health or {}).get("confirmed_canonical_count") or 0
        rich_provisional_count = (health or {}).get("rich_provisional_canonical_count") or 0
        age = freshness_age_seconds((health or {}).get("observed_at"))
        if age is not None and age > 30:
            return "stale"
        if canonical_count == 0 and running_pids:
            return "running_no_events"
        if confirmed_count and rich_provisional_count:
            return "mixed_confidence"
        if rich_provisional_count and confirmed_count == 0:
            return "rich_provisional_only"
        if canonical_count and provisional_count == canonical_count:
            if last_source.get("source_type") == "notification_center_ax":
                return "provisional_only"
        if running_pids:
            return "healthy"
        if pidfile_pid and health:
            return "likely_running_but_uninspectable"
        return "down"

    if spec.health_kind == "packets":
        details = (health or {}).get("details") or {}
        age = freshness_age_seconds((health or {}).get("observed_at"))
        total_packets = details.get("total_packets") or 0
        if age is not None and age > 30:
            return "stale"
        if total_packets == 0 and running_pids:
            return "running_no_packets"
        if running_pids:
            return "healthy"
        if pidfile_pid and health:
            return "likely_running_but_uninspectable"
        return "down"

    if spec.health_kind == "actions":
        details = (health or {}).get("details") or {}
        state = details.get("state")
        age = freshness_age_seconds((health or {}).get("observed_at"))
        if not running_pids:
            if pidfile_pid and health and age is not None and age <= 30:
                return "likely_running_but_uninspectable"
            if age is not None and age > 90:
                return "stale"
            return "down"
        if state == "blocked":
            return "blocked"
        if state == "degraded":
            return "degraded"
        if age is not None and age > 90:
            return "stale"
        if state == "primed":
            return "primed"
        if state == "healthy":
            return "healthy"
        if running_pids:
            return "running_no_heartbeat"
        if pidfile_pid and health:
            return "likely_running_but_uninspectable"
        return "down"

    if spec.health_kind == "soak":
        details = (health or {}).get("details") or {}
        age = freshness_age_seconds((health or {}).get("observed_at"))
        cycles = details.get("cycles") or 0
        if age is not None and age > 150:
            return "stale"
        if cycles == 0 and running_pids:
            return "running_no_samples"
        if running_pids:
            return "healthy"
        if pidfile_pid and health:
            return "likely_running_but_uninspectable"
        return "down"

    if running_pids:
        age = freshness_age_seconds((health or {}).get("observed_at") if health else None)
        if age is None:
            return "running_no_heartbeat"
        if age <= 15:
            return "healthy"
        return "stale"

    if pidfile_pid and health:
        age = freshness_age_seconds(health.get("observed_at"))
        if age is not None and age <= 30:
            return "likely_running_but_uninspectable"
        return "stale"

    return "down"


def recommend_action(
    spec: ProcSpec,
    state_summary: str,
    health: dict[str, object] | None,
) -> str | None:
    if spec.health_kind == "baileys":
        details = (health or {}).get("details") or {}
        state = details.get("state")
        if state_summary == "connected_idle":
            return "Collector is connected but has not seen a post-start event yet."
        if state == "pairing_code_ready":
            phone = details.get("pairing_phone_e164") or "observer phone"
            return f"Enter the pairing code from status on {phone} now."
        if state == "pairing_code_error":
            error_text = details.get("last_pairing_error")
            if details.get("qr_payload"):
                if error_text:
                    return f"Pairing code failed ({error_text}); use the QR fallback or correct the phone number and retry."
                return "Pairing code failed; use the QR fallback or correct the phone number and retry."
            if error_text:
                return f"Pairing code failed ({error_text}); retry with a valid phone number."
            return "Pairing code failed; retry with a valid phone number."
        if state == "qr_required":
            if details.get("qr_payload"):
                return "Render or scan the current QR payload to link the observer account."
            return "Start Baileys with a linked observer account, either by QR or --wa-phone-e164 for pairing code."
        if state == "reconnecting":
            label = describe_disconnect_status(details.get("last_disconnect_status_code"))
            if label:
                return f"Collector is reconnecting after {label}; watch for registration fallback."
            return "Collector is reconnecting; watch for registration fallback."
        if state == "needs_reauth":
            return "Current auth state is invalid; clear or replace it and re-link the observer account."
        if state == "logged_out":
            return "Re-link the observer account; current auth state is no longer valid."
        if state_summary == "down":
            return "Start the Baileys collector before trusting richer intake."
        return None

    if spec.health_kind == "merge" and state_summary != "healthy":
        if state_summary == "mixed_confidence":
            return "Merge has both confirmed events and richer-source provisional events; newest traffic may still need corroboration."
        if state_summary == "rich_provisional_only":
            return "Merge is ingesting richer-source events, but none are cross-confirmed yet."
        if state_summary == "provisional_only":
            return "Merge is alive but only has notification-grade evidence; do not treat canonical output as complete."
        if state_summary == "running_no_events":
            return "Merge follower is up but has not ingested any source events yet."
        return "Check merge-status.json and recent spool offsets before trusting canonical output."

    if spec.health_kind == "packets" and state_summary != "healthy":
        if state_summary == "running_no_packets":
            return "Packet emitter is up but has not emitted any operator packets yet."
        return "Check packet-status.json and operator-packets.jsonl before trusting downstream routing."

    if spec.health_kind == "actions" and state_summary != "healthy":
        details = (health or {}).get("details") or {}
        reason = details.get("reason")
        if state_summary == "primed":
            return "Operator reply adapter is primed and waiting for ACK/DONE/ESC/NACK replies."
        if state_summary == "blocked":
            if reason == "operator_identity_unconfigured":
                return "Set WA_OPERATOR_HANDLES or WA_IMESSAGE_CHAT_GUID before trusting inbound operator replies."
            if reason == "chat_db_unreadable":
                return "Grant Full Disk Access for Messages chat.db before trusting inbound operator replies."
            return "Operator reply adapter is blocked; inspect runtime/operator-actions-status.json."
        if state_summary == "degraded":
            return "Operator reply adapter hit an error; inspect runtime/operator-actions-status.json before trusting inbound replies."
        return "Start the operator reply adapter if you want ACK/DONE/ESC replies to change packet state."

    if spec.health_kind == "soak" and state_summary != "healthy":
        if state_summary == "running_no_samples":
            return "Soak watcher is up but has not written a first snapshot yet."
        return "Check runtime/soak-status.json and runtime/stack-soak.jsonl before trusting overnight evidence."

    if spec.health_kind == "native" and state_summary != "healthy":
        return "Check notification permissions and the native log before trusting wake-up events."

    return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["start", "stop", "restart", "status"])
    parser.add_argument(
        "--wa-phone-e164",
        help="observer WhatsApp number for pairing-code login when starting the Baileys collector",
    )
    parser.add_argument("--webhook-url", help="packet webhook target for outbound delivery")
    parser.add_argument("--event-command", help="packet event command for outbound delivery")
    parser.add_argument("--packet-relay", help="outbound relay mode, for example imessage")
    parser.add_argument("--primary-destination", help="primary operator destination")
    parser.add_argument("--after-hours-destination", help="after-hours operator destination")
    parser.add_argument("--backup-destination", help="backup operator destination")
    parser.add_argument(
        "--dispatch-not-before",
        help="only auto-dispatch packets emitted at or after this UTC timestamp",
    )
    parser.add_argument(
        "--pending-replies-path",
        help="shared pending-replies tracker path for already-sent outbound messages",
    )
    parser.add_argument("--imessage-service", help="Messages service name, for example iMessage")
    parser.add_argument("--imessage-chat-guid", help="Messages chat guid for inbound reply allowlist")
    parser.add_argument(
        "--operator-handle",
        action="append",
        help="allowed operator handle for ACK/DONE/ESC/NACK replies; repeat or comma-separate",
    )
    parser.add_argument(
        "--clear-managed-env",
        action="store_true",
        help="clear persisted launcher-managed env for the targeted process or processes before start/restart",
    )
    parser.add_argument(
        "targets",
        nargs="*",
        help="defaults to all managed processes",
    )
    args = parser.parse_args()
    invalid = sorted(set(args.targets) - set(SPECS.keys()))
    if invalid:
        parser.error(f"invalid targets: {', '.join(invalid)}")
    return args


def env_overrides_for(args: argparse.Namespace) -> dict[str, str]:
    overrides: dict[str, str] = {}
    if args.wa_phone_e164:
        overrides["WA_PHONE_E164"] = args.wa_phone_e164
    if args.webhook_url:
        overrides["WA_PACKET_WEBHOOK_URL"] = args.webhook_url
    if args.event_command:
        overrides["WA_PACKET_EVENT_COMMAND"] = args.event_command
    if args.packet_relay:
        overrides["WA_PACKET_RELAY"] = args.packet_relay
    if args.primary_destination:
        overrides["WA_PRIMARY_DESTINATION"] = args.primary_destination
    if args.after_hours_destination:
        overrides["WA_AFTER_HOURS_DESTINATION"] = args.after_hours_destination
    if args.backup_destination:
        overrides["WA_BACKUP_DESTINATION"] = args.backup_destination
    if args.dispatch_not_before:
        overrides["WA_PACKET_DISPATCH_NOT_BEFORE"] = args.dispatch_not_before
    if args.pending_replies_path:
        overrides["WA_PENDING_REPLIES_PATH"] = args.pending_replies_path
    if args.imessage_service:
        overrides["WA_IMESSAGE_SERVICE"] = args.imessage_service
    if args.imessage_chat_guid:
        overrides["WA_IMESSAGE_CHAT_GUID"] = args.imessage_chat_guid
    operator_handles = join_multi_values(args.operator_handle)
    if operator_handles:
        overrides["WA_OPERATOR_HANDLES"] = operator_handles
    return overrides


def env_overrides_for_spec(spec: ProcSpec, args: argparse.Namespace) -> dict[str, str] | None:
    overrides = env_overrides_for(args)
    if not overrides:
        return None
    allowed_keys: set[str] = set()
    if spec.name == "baileys":
        allowed_keys.add("WA_PHONE_E164")
    if spec.name in {"packets", "actions"}:
        allowed_keys.update(
            {
                "WA_PACKET_WEBHOOK_URL",
                "WA_PACKET_EVENT_COMMAND",
                "WA_PACKET_RELAY",
                "WA_PRIMARY_DESTINATION",
                "WA_AFTER_HOURS_DESTINATION",
                "WA_BACKUP_DESTINATION",
                "WA_PACKET_DISPATCH_NOT_BEFORE",
                "WA_PENDING_REPLIES_PATH",
                "WA_IMESSAGE_SERVICE",
                "WA_IMESSAGE_CHAT_GUID",
                "WA_OPERATOR_HANDLES",
            }
        )
    filtered = {key: value for key, value in overrides.items() if key in allowed_keys}
    return filtered or None


def resolved_managed_env_for_spec(
    spec: ProcSpec,
    args: argparse.Namespace,
    state: dict[str, dict[str, str]],
) -> dict[str, str] | None:
    explicit = env_overrides_for_spec(spec, args) or {}
    if args.clear_managed_env:
        effective = dict(explicit)
    else:
        effective = dict(state.get(spec.name) or {})
        effective.update(explicit)
    return effective or None


def persist_managed_env_for_spec(
    spec: ProcSpec,
    env_overrides: dict[str, str] | None,
    state: dict[str, dict[str, str]],
) -> None:
    if env_overrides:
        state[spec.name] = dict(env_overrides)
    else:
        state.pop(spec.name, None)


def start_and_record_managed_env(
    spec: ProcSpec,
    *,
    managed_env: dict[str, str] | None,
    state: dict[str, dict[str, str]],
) -> tuple[dict[str, object], bool]:
    try:
        result = start_proc_with_env(spec, managed_env)
    except Exception as exc:
        return (
            {
                "name": spec.name,
                "action": "start_failed",
                "error": str(exc),
                "managed_env_requested": managed_env or {},
            },
            False,
        )

    action = result.get("action")
    if action == "started":
        persist_managed_env_for_spec(spec, managed_env, state)
        return result, True

    if action == "already_running":
        if managed_env is not None:
            result = {
                **result,
                "managed_env_applied": False,
                "managed_env_note": "process already running; requested managed env was not applied",
                "managed_env_requested": managed_env,
            }
        return result, False

    return result, False


def main() -> int:
    args = parse_args()
    targets = args.targets or list(SPECS.keys())
    specs = [SPECS[target] for target in targets]
    results: list[dict[str, object]] = []
    managed_env_state = load_managed_env_state()

    if args.action == "start":
        for spec in specs:
            resolved = resolved_managed_env_for_spec(spec, args, managed_env_state)
            result, changed_state = start_and_record_managed_env(
                spec,
                managed_env=resolved,
                state=managed_env_state,
            )
            results.append(result)
            if changed_state:
                save_managed_env_state(managed_env_state)
    elif args.action == "stop":
        results = [stop_proc(spec) for spec in specs]
    elif args.action == "restart":
        for spec in specs:
            resolved = resolved_managed_env_for_spec(spec, args, managed_env_state)
            results.append(stop_proc(spec))
            result, changed_state = start_and_record_managed_env(
                spec,
                managed_env=resolved,
                state=managed_env_state,
            )
            results.append(result)
            if changed_state:
                save_managed_env_state(managed_env_state)
    elif args.action == "status":
        results = [status_proc(spec) for spec in specs]

    print(json.dumps({"results": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
