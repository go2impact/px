#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 stack_control.py status
echo
read '?Press [Enter] to close...'
