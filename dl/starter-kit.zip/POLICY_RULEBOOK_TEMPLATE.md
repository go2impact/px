# Policy Rulebook Template

Use this file to teach a local harness or operator how to interpret incoming
messages.

## How to use this template

- Be explicit.
- Write rules as checks and actions, not as vague principles.
- Prefer a human review path when confidence is low.
- Treat this file as the decision layer above the collectors.
- Edit this markdown directly when you want to tighten thresholds, escalation rules, or suggested response language.

## Rule schema

For each rule, define:

- `rule_name`
- `why_it_exists`
- `what_counts_as_a_hit`
- `what_counts_as_a_possible_hit`
- `ignore_cases`
- `recommended_action`
- `escalation_threshold`
- `off_platform_follow_up_allowed`
- `human_review_required`
- `dashboard_bucket`

## Generic decision logic

Every message or packet should be evaluated in this order:

1. Is this a real user-authored message or just system / join noise?
2. Does it possibly hit one or more policy buckets?
3. Is the evidence native-only, richer-but-provisional, or confirmed?
4. Does the action require a human now, a queued review, or no action?
5. If a warning is appropriate, should it happen in-group, off-platform by text, or only after human confirmation?

## Example rule categories

### Real-name policy

- Require identifiable full-name style profiles.
- Flag anonymous, troll-like, or obviously fake identities for human review.

### Solicitation / deal promotion

- Flag messages that pitch a deal, product, service, or direct commercial ask.
- Distinguish between ordinary member discussion and active solicitation.

### Respect / hostility

- Flag personal attacks, insults, escalation spirals, or abusive tone.
- Allow normal disagreement that stays respectful.

### Spam / repetition

- Flag repeated promotional posts, repetitive pushes, or obvious flooding behavior.

## Routing outcomes

Every message or packet should end in one of these buckets:

- `ignore`
- `log_only`
- `review_now`
- `review_pending_confirmation`
- `human_warning_recommended`
- `off_platform_message_recommended`
- `escalate_admin`

## Confidence guidance

- Native-only evidence should usually stay provisional.
- Cross-source or richer evidence can justify stronger action.
- If the system is unsure, queue the packet for human review instead of pretending certainty.

## Notes for 3i-style deployments

- Group/channel moderation is the first-class path.
- Off-platform text/iMessage follow-up may be easier to operationalize than outbound WhatsApp automation.
- Keep the action path separate from the observer path whenever possible.
- Keep the rule language generic at first, then tighten it once the community operators show you where the edge cases actually are.
