# WhatsApp Intake Starter Kit

This is a stripped-down Mac-first starter for local WhatsApp monitoring.
It is strongest on group monitoring and is meant to be installed, tested, and tuned by a local harness.

Safe to share:
- no live auth
- no live message history
- no real logs
- no personal databases

Read in this order:
1. `START_HERE.md`
2. `MANUAL_START_HERE.html`
3. `MANUAL_OPERATIONS.html`
4. `HARNESS_INSTRUCTIONS.md`

Then use the deeper files only if you need them:
- `OBSERVER_ACCOUNT_RULES.md`
- `POLICY_RULEBOOK_TEMPLATE.md`
- `MANUAL_POLICY_AND_RULES.html`
- `MANUAL_DATA_MODEL.html`
- `PROOF_OF_LIFE_CHECKLIST.md`
- `TROUBLESHOOTING_AND_RECOVERY.md`

If you are proving the install:
1. `INSTALL.command`
2. `RUN_DOCTOR.command`
3. `START_STACK.command`
4. `CHECK_STATUS.command`
5. `SHOW_ONBOARDING.command` if linking is required
6. `LIVE_TEST.command`

Look for output in:
- `./runtime/`
- `./baileys-status.json`
- `./merge-status.json`
- `./packet-status.json`
- `./operator-packets-latest.json`
