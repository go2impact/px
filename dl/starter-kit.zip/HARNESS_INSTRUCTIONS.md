# Harness Instructions

This file is for the local AI harness or technical helper.

## What this bundle is

This is a stripped-down Mac starter for watching WhatsApp activity.
It is not a hosted app. It is not a finished dashboard. It is the Mac-side intake and packet flow that someone else can wrap.
Keep it local. Do not try to migrate it to a server as your first move.

## What is safe to assume

- The bundle does not include live auth, real logs, or the author's databases.
- This is Mac-first.
- Group traffic is the strongest path.
- Native DMs are best-effort only.
- Baileys DMs are not included.
- The local outputs are SQLite and JSON.
- A `packet` is the local review record the system creates after it sees and processes a message.

## Your job

1. Get the prerequisites installed.
2. Start the stack cleanly.
3. Link Baileys if needed.
4. Prove one fresh group message reaches `operator-packets-latest.json`.
5. Tell the human exactly what still needs wrapping.

## Prerequisites you may need to install

- WhatsApp Desktop on the Mac
- Node.js LTS
- Apple's Command Line Tools if `python3` is missing:
  - `xcode-select --install`
- If Node.js is missing, install the current LTS release from `nodejs.org`
- Accessibility permission for the app running this stack
- The Mac must stay awake during active monitoring
- WhatsApp Desktop must stay open during active monitoring

Only if they want outbound text/iMessage sending on the same Mac:
- Messages configured on that Mac
- Full Disk Access for the harness process if it needs to read `Messages/chat.db`

## Copy/paste prompt for a local harness

Use this prompt as the first instruction after opening this folder:

"""
You are setting up a Mac-first WhatsApp monitoring starter.
This package is meant to be installed and QA'd locally by a harness such as Openwork, Codex Desktop, or Claude Code.

Read these files first:
1. START_HERE.md
2. OBSERVER_ACCOUNT_RULES.md
3. POLICY_RULEBOOK_TEMPLATE.md
4. TROUBLESHOOTING_AND_RECOVERY.md

Then do this in order:
1. Verify prerequisites:
   - WhatsApp Desktop installed and linked to the account being observed
   - Node.js available
   - python3 available (`python3 --version`)
   - Focus / Do Not Disturb off during the live QA test
2. Run `INSTALL.command` (or `npm install` if you prefer Terminal)
3. Run `RUN_DOCTOR.command` (or `python3 doctor_runtime.py`)
4. Start the stack with `START_STACK.command` (or `python3 stack_control.py start native baileys merge packets soak`)
5. If the web-linked collector still needs its own pairing step, run `SHOW_ONBOARDING.command` (or `npm run baileys:onboarding`)
6. Pick a unique test phrase such as `LIVE TEST 48271`
7. Ask for that exact phrase in one fresh group message in a group already visible to the observer account
8. Run `python3 qa_live_test.py --token "LIVE TEST 48271" --no-prompt`
9. If the live test fails, check `baileys-status.json`, `merge-status.json`, `packet-status.json`, and `runtime/` logs before declaring failure

When you report status, separate:
- what is working now
- what is not included in this starter
- what you think you can finish locally without a developer

Important truths:
- This is Mac-first and local-first.
- Group monitoring is the strongest supported path.
- Native DMs are best-effort only.
- Baileys DMs are not supported in this starter.
- The editable markdown files control moderation rules, escalation logic, and response guidance.
- Keep the architecture local instead of redesigning it into a cloud service as your first move.
"""

## How to interpret the system

- Native-only signals are wake-up signals, not perfect truth.
- Baileys group evidence is stronger.
- Packets are the operator-facing output.
- Health means forward progress, not just a living process.

## Main files to inspect

- `baileys-status.json`
- `merge-status.json`
- `packet-status.json`
- `operator-packets-latest.json`
- `runtime/soak-status.json`
- `runtime/` logs if something dies early

## What you can likely finish without a developer

- local install
- relinking the observer account
- reading packet JSON/SQLite output
- editing the policy markdown
- adding a light workflow around the packet output
- tuning rules, escalation logic, and suggested responses in markdown

## What still needs wrapping

- a polished operator workflow
- final routing and escalation rules
- hosted storage or dashboard, if desired
- richer DM support if the customer needs it
- any future second-observer or cloud-relay hardening

## What not to assume

- Do not assume Baileys DMs work here.
- Do not assume the Mac-side outbound Messages path is already polished enough for a full operator console.
- Do not assume a process being up means real traffic is flowing.
- Do not assume native notifications are enough if richer evidence is absent.
- Do not leave the Mac asleep during monitoring windows.
