#!/usr/bin/env node

import fs from 'node:fs'
import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import QRCode from 'qrcode'
import qrcode from 'qrcode-terminal'

const baseDir = process.argv[2]
  ? path.resolve(process.argv[2])
  : path.resolve(path.dirname(new URL(import.meta.url).pathname))
const statusPath = path.join(baseDir, 'baileys-status.json')
const runtimeDir = path.join(baseDir, 'runtime')
const qrSvgPath = path.join(runtimeDir, 'baileys-onboarding-qr.svg')
const qrPngPath = path.join(runtimeDir, 'baileys-onboarding-qr.png')

function fail(message) {
  console.error(message)
  process.exit(1)
}

if (!fs.existsSync(statusPath)) {
  fail(`No status file found at ${statusPath}`)
}

const status = JSON.parse(fs.readFileSync(statusPath, 'utf8'))
const state = status.state || 'unknown'

if (status.pairing_code) {
  console.log(`State: ${state}`)
  if (status.pairing_phone_e164) {
    console.log(`Phone: ${status.pairing_phone_e164}`)
  }
  console.log(`Pairing code: ${status.pairing_code}`)
  process.exit(0)
}

if (status.qr_payload) {
  console.log(`State: ${state}`)
  console.log('Render from qr_payload:')
  qrcode.generate(status.qr_payload, { small: true })
  await mkdir(runtimeDir, { recursive: true })
  const svg = await QRCode.toString(status.qr_payload, { type: 'svg', margin: 1, width: 512 })
  await writeFile(qrSvgPath, svg, 'utf8')
  await QRCode.toFile(qrPngPath, status.qr_payload, { margin: 1, width: 768 })
  console.log(`Saved SVG: ${qrSvgPath}`)
  console.log(`Saved PNG: ${qrPngPath}`)
  process.exit(0)
}

if (state === 'qr_required') {
  fail('QR is required but no qr_payload is stored yet. Restart the Baileys collector on the current code path, then run this again.')
}

fail(`No pairing code or QR payload available. Current state: ${state}`)
