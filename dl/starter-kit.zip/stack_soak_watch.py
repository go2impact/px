#!/usr/bin/env python3
"""
Watch the managed collector stack over time and write compact soak snapshots.

This is intentionally boring:
- poll the managed runtime status
- write a compact JSONL snapshot on first run, state transitions, and periodic heartbeats
- keep a small summary JSON for tomorrow-morning inspection
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Any

import stack_control


DEFAULT_TARGETS = ("native", "baileys", "merge", "packets", "actions")


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(f"{path.suffix}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def compact_result(result: dict[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {
        "name": result["name"],
        "state_summary": result["state_summary"],
        "age_seconds": result["age_seconds"],
        "recommended_action": result["recommended_action"],
    }
    health = result.get("health") or {}
    details = health.get("details") or {}
    compact["observed_at"] = health.get("observed_at")

    if result["name"] == "native":
        compact["details"] = {
            "collector_version": details.get("collector_version"),
            "parser_version": details.get("parser_version"),
            "alert_count": details.get("alert_count"),
            "poll_interval_seconds": details.get("poll_interval_seconds"),
        }
    elif result["name"] == "baileys":
        compact["details"] = {
            "state": details.get("state"),
            "connected_at": details.get("connected_at"),
            "connection_heartbeat_at": details.get("connection_heartbeat_at"),
            "last_event_at": details.get("last_event_at"),
            "last_remote_jid": details.get("last_remote_jid"),
            "last_source_message_id": details.get("last_source_message_id"),
            "duplicate_suppressed_count": details.get("duplicate_suppressed_count"),
            "crypto_signal_count": details.get("crypto_signal_count"),
            "shape_capture_count": details.get("shape_capture_count"),
            "unknown_shape_count": details.get("unknown_shape_count"),
            "last_shape_message_type": details.get("last_shape_message_type"),
            "last_shape_delivery_mode": details.get("last_shape_delivery_mode"),
            "last_disconnect_status_code": details.get("last_disconnect_status_code"),
        }
    elif result["name"] == "merge":
        compact["details"] = {
            "source_event_count": health.get("source_event_count"),
            "canonical_event_count": health.get("canonical_event_count"),
            "confirmed_canonical_count": health.get("confirmed_canonical_count"),
            "provisional_canonical_count": health.get("provisional_canonical_count"),
            "rich_provisional_canonical_count": health.get("rich_provisional_canonical_count"),
            "notification_provisional_canonical_count": health.get("notification_provisional_canonical_count"),
            "last_source_event": health.get("last_source_event"),
            "last_canonical_event": health.get("last_canonical_event"),
        }
    elif result["name"] == "packets":
        compact["details"] = {
            "total_packets": details.get("total_packets"),
            "latest_packets_total": details.get("latest_packets_total"),
            "latest_review_now_count": details.get("latest_review_now_count"),
            "latest_review_pending_count": details.get("latest_review_pending_count"),
            "oldest_review_now_age_seconds": details.get("oldest_review_now_age_seconds"),
            "oldest_review_pending_age_seconds": details.get("oldest_review_pending_age_seconds"),
        }
    else:
        compact["details"] = details

    return compact


def signature_result(result: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": result["name"],
        "state_summary": result["state_summary"],
        "recommended_action": result["recommended_action"],
        "details": result["details"],
    }


def snapshot_hash(snapshot: list[dict[str, Any]]) -> str:
    return hashlib.sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False))
        handle.write("\n")


def parse_args() -> argparse.Namespace:
    base = stack_control.BASE_DIR
    runtime = stack_control.RUNTIME_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=float, default=60.0)
    parser.add_argument("--heartbeat-cycles", type=int, default=10)
    parser.add_argument("--restart-after-cycles", type=int, default=2)
    parser.add_argument("--jsonl", type=Path, default=runtime / "stack-soak.jsonl")
    parser.add_argument("--status-json", type=Path, default=runtime / "soak-status.json")
    parser.add_argument("targets", nargs="*", default=list(DEFAULT_TARGETS))
    args = parser.parse_args()
    invalid = sorted(set(args.targets) - set(stack_control.SPECS.keys()))
    if invalid:
        parser.error(f"invalid targets: {', '.join(invalid)}")
    return args


def main() -> int:
    args = parse_args()
    specs = [stack_control.SPECS[name] for name in args.targets]
    started_at = utc_now()
    last_hash: str | None = None
    last_states: dict[str, str] = {}
    transition_history: list[dict[str, Any]] = []
    restart_history: list[dict[str, Any]] = []
    bad_state_counts: dict[str, int] = {}
    cycles = 0
    written_snapshots = 0
    transition_count = 0
    restart_count = 0
    last_written_at: str | None = None

    while True:
        cycles += 1
        compact_results = [compact_result(stack_control.status_proc(spec)) for spec in specs]
        signature_results = [signature_result(result) for result in compact_results]
        current_states = {result["name"]: result["state_summary"] for result in compact_results}
        current_actions = {
            result["name"]: result["recommended_action"]
            for result in compact_results
            if result.get("recommended_action")
        }

        for result in compact_results:
            name = result["name"]
            prior = last_states.get(name)
            current = result["state_summary"]
            if prior is not None and prior != current:
                transition_count += 1
                transition_history.append(
                    {
                        "observed_at": utc_now(),
                        "name": name,
                        "from": prior,
                        "to": current,
                    }
                )
                transition_history = transition_history[-25:]
            last_states[name] = current

            if current in {
                "stale",
                "down",
                "running_no_events",
                "running_no_packets",
                "running_no_samples",
                "running_no_heartbeat",
                "degraded",
            }:
                bad_state_counts[name] = bad_state_counts.get(name, 0) + 1
            else:
                bad_state_counts[name] = 0

            if (
                args.restart_after_cycles > 0
                and bad_state_counts[name] >= args.restart_after_cycles
                and name in stack_control.SPECS
            ):
                spec = stack_control.SPECS[name]
                stop_result = stack_control.stop_proc(spec)
                start_result = stack_control.start_proc(spec)
                restart_count += 1
                restart_history.append(
                    {
                        "observed_at": utc_now(),
                        "name": name,
                        "bad_state": current,
                        "bad_state_count": bad_state_counts[name],
                        "stop_result": stop_result,
                        "start_result": start_result,
                    }
                )
                restart_history = restart_history[-25:]
                bad_state_counts[name] = 0

        current_hash = snapshot_hash(signature_results)
        write_reason = None
        if last_hash is None:
            write_reason = "initial"
        elif current_hash != last_hash:
            write_reason = "state_change"
        elif args.heartbeat_cycles > 0 and cycles % args.heartbeat_cycles == 0:
            write_reason = "heartbeat"

        if write_reason is not None:
            written_snapshots += 1
            last_written_at = utc_now()
            append_jsonl(
                args.jsonl,
                {
                    "observed_at": last_written_at,
                    "write_reason": write_reason,
                    "cycle": cycles,
                    "results": compact_results,
                },
            )
            last_hash = current_hash

        atomic_write_json(
            args.status_json,
            {
                "runner": "stack_soak_watch",
                "runner_version": "0.1.0",
                "started_at": started_at,
                "observed_at": utc_now(),
                "interval_seconds": args.interval,
                "heartbeat_cycles": args.heartbeat_cycles,
                "cycles": cycles,
                "written_snapshots": written_snapshots,
                "transition_count": transition_count,
                "restart_count": restart_count,
                "last_written_at": last_written_at,
                "targets": list(args.targets),
                "jsonl_path": str(args.jsonl),
                "current_states": current_states,
                "current_recommended_actions": current_actions,
                "bad_state_counts": bad_state_counts,
                "transition_history_tail": transition_history,
                "restart_history_tail": restart_history,
                "last_snapshot": compact_results,
            },
        )
        time.sleep(args.interval)


if __name__ == "__main__":
    raise SystemExit(main())
