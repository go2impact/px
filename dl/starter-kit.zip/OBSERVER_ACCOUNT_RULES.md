# Observer Account Rules

This starter kit works best when the WhatsApp observer identity is boring,
stable, and separate from the human operator identity.

## Recommended posture

- Use a dedicated observer number.
- Keep that number on a real physical phone with the official WhatsApp app.
- A cheap SIM-backed line is fine.
- Avoid Google Voice if you may want same-number Mac/iPhone relay later.
- Keep the phone plugged in, healthy, and on stable Wi-Fi.
- Link one desktop/device collector path for intake.
- Keep the observer account mostly passive. Its job is to watch, not to chat.

## Why this matters

- Native notifications are easier to trust when the observer account is not also being actively used by a person.
- If the observer account is frontmost in WhatsApp Desktop when a message arrives, the native notification path may not fire at all.
- Linked-device collectors behave better when the primary phone is real, stable, and not constantly being reconfigured.
- Mixing operator and observer behavior makes it harder to reason about what the system did versus what a person did.

## What not to do

- Do not use someone's personal WhatsApp account as the observer by default.
- Do not run Baileys and another WhatsApp protocol collector on the same number at the same time.
- Do not point multiple machines/processes at the same auth state.
- Do not keep relinking the account casually because a clean session is more valuable than brute-force persistence.
- Do not use the observer account as the main human moderation account.
- Do not sit in the observer chat window during active monitoring if you want native notifications to keep waking the stack up.

## Account hygiene

- One number, one primary phone, one linked observer stack.
- Back up auth state if you are managing this operationally.
- Treat relinking as an operational event, not casual background noise.
- Prefer idle over noisy. The observer account should not mimic a human chatter pattern.

## Mac-first note

The current bundle is Mac-first because the native intake adapter uses macOS
notification surfaces. The observer-account strategy itself is portable. If you
move to PC later, the intake adapter changes but the account rules should stay
basically the same.

## macOS alerting note

- Turn off Focus Modes / Do Not Disturb during active monitoring windows.
- If the observer chat is frontmost in WhatsApp Desktop when a message lands, native wake-up may not fire.
