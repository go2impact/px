#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent


def default_token() -> str:
    return f"LIVE TEST {int(time.time()) % 100000:05d}"


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def snapshot(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"generated_at": None, "packet_count": 0, "packets": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"generated_at": None, "packet_count": 0, "packets": [], "error": "unreadable_json"}
    if not isinstance(data, dict):
        return {"generated_at": None, "packet_count": 0, "packets": [], "error": "unexpected_shape"}
    packets = data.get("packets")
    if not isinstance(packets, list):
        packets = []
    return {
        "generated_at": data.get("generated_at"),
        "packet_count": len(packets),
        "packets": packets,
    }


def packet_seen_after(packet: dict[str, Any], started_at: datetime, token: str | None) -> bool:
    message_text = str(packet.get("message_text") or "")
    if token:
        return token.casefold() in message_text.casefold()
    for key in (
        "last_observed_at",
        "first_observed_at",
        "canonical_updated_at",
        "presented_at",
        "delivered_at",
        "acknowledged_at",
    ):
        value = parse_iso(packet.get(key))
        if value and value >= started_at:
            return True
    return False


def summarize_packet(packet: dict[str, Any]) -> str:
    packet_id = packet.get("packet_id") or "unknown"
    group_name = packet.get("group_name") or packet.get("conversation_display") or "unknown"
    sender = packet.get("sender_display_name") or packet.get("sender_display") or "unknown"
    text = packet.get("message_text") or ""
    short_text = text if len(text) <= 160 else text[:157] + "..."
    return (
        f"PASS\n"
        f"packet_id: {packet_id}\n"
        f"group_or_chat: {group_name}\n"
        f"sender: {sender}\n"
        f"message_text: {short_text}\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--latest-snapshot", type=Path, default=BASE_DIR / "operator-packets-latest.json")
    parser.add_argument("--timeout-seconds", type=int, default=45)
    parser.add_argument("--poll-interval", type=float, default=2.0)
    parser.add_argument("--token")
    parser.add_argument("--no-prompt", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    before = snapshot(args.latest_snapshot)
    started_at = datetime.now(timezone.utc)
    token = (args.token or "").strip() or None

    if not args.json and not args.no_prompt:
        token = token or default_token()
        print("Live test helper")
        print("1. Make sure the observer account can already see the target group.")
        print(f"2. Send one fresh group message from a different WhatsApp account with this exact text:")
        print(f"   {token}")
        input("3. Press Enter once that message has been sent...")

    deadline = time.time() + max(args.timeout_seconds, 1)
    last_seen = before
    while time.time() < deadline:
        current = snapshot(args.latest_snapshot)
        last_seen = current
        for packet in current.get("packets", []):
            if isinstance(packet, dict) and packet_seen_after(packet, started_at, token):
                if args.json:
                    print(json.dumps({"ok": True, "token": token, "packet": packet}, ensure_ascii=False, indent=2))
                else:
                    print("")
                    print(summarize_packet(packet))
                return 0
        time.sleep(max(args.poll_interval, 0.2))

    failure = {
        "ok": False,
        "reason": "no_recent_packet_detected",
        "generated_at": last_seen.get("generated_at"),
        "packet_count": last_seen.get("packet_count"),
        "next_checks": [
            "Run CHECK_STATUS.command",
            "Inspect baileys-status.json",
            "Inspect merge-status.json",
            "Inspect packet-status.json",
            "Inspect runtime/ logs",
        ],
    }
    if args.json:
        print(json.dumps(failure, ensure_ascii=False, indent=2))
    else:
        print("")
        print("FAIL")
        print("No fresh packet was detected during the live-test window.")
        print("Processes may be running, but no fresh message reached the packet layer during this test.")
        if token:
            print(f"expected_test_token: {token}")
        if failure["generated_at"]:
            print(f"latest_snapshot_generated_at: {failure['generated_at']}")
        print("Next checks:")
        for item in failure["next_checks"]:
            print(f"- {item}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
