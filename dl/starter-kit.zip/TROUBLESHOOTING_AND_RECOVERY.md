# Troubleshooting And Recovery

This system is practical, but it is not self-healing magic. Use this file when
the stack looks alive but the signal is weak, stale, or missing.

## Quick triage

1. Is the phone alive and still logged into WhatsApp?
2. Is the Mac awake, unlocked enough, and allowed to show notifications?
3. Did `python3 stack_control.py status` report real movement, not just living processes?
4. Did a fresh group message produce a packet row?
5. Is macOS hiding banners because Focus Mode / Do Not Disturb is on?

## Common symptoms

### `node_modules_baileys: no`

- Cause: dependencies were not installed.
- Fix: run `npm install`.

### Baileys says `registration_required`

- Cause: linked-device session is missing or expired.
- Fix: run `npm run baileys:onboarding`, then relink the observer phone from WhatsApp > Settings > Linked Devices.

### The phone is dead, offline, or logged out

- Cause: the real primary device is no longer healthy enough to anchor the linked session.
- Fix:
  1. restore the phone first
  2. confirm WhatsApp is still logged in on the phone
  3. reconnect Wi-Fi/cellular
  4. rerun onboarding only if the linked session still does not recover

### `native` is `down` or `stale`

- Cause: WhatsApp Desktop is closed, permissions drifted, or macOS is suppressing the notification path.
- Fix:
  1. open WhatsApp Desktop
  2. confirm notifications are allowed
  3. disable Focus Modes / Do Not Disturb
  4. keep the Mac awake
  5. rerun `python3 stack_control.py start native`

### `packets` are stale even though traffic happened

- Cause: richer collector, merge, or packet emitter is lagging.
- Fix:
  1. inspect `baileys-status.json`
  2. inspect `merge-status.json`
  3. inspect `packet-status.json`
  4. restart through `stack_control.py`, not ad hoc shell commands

### Group traffic works but DMs do not show up richly

- Cause: Baileys DM support is not implemented in this starter kit.
- Fix: none inside this starter kit. Treat native DM notifications as the only current DM signal.

## Safe restart order

1. `python3 stack_control.py stop native baileys merge packets soak`
2. `python3 stack_control.py start native baileys merge packets soak`
3. rerun the proof checklist

## When to escalate

- repeated forced relinks
- packet corruption or impossible merge states
- the observer phone is no longer under control
- the Mac can no longer hold notification permissions or stay awake reliably
- a WhatsApp Desktop update materially changes the notification surface
