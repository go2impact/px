# Start Here

This zip is a stripped-down copy of the Mac setup I use to monitor WhatsApp locally.
It is a Mac-first observer starter with a local review database and packet output.
It is strongest on group monitoring and should be treated as a practical starter, not a finished product.

What is included:
- the Mac-side collectors
- the merge layer
- the packet layer
- simple `.command` launchers
- human/operator guides
- harness/setup instructions

What is not included:
- live auth state
- real message history
- live logs
- my personal databases
- a hosted dashboard or hosted backend

If you just want the shortest path:
1. download the zip
2. unzip it anywhere on the Mac
3. open the folder in your harness
4. have the harness read `HARNESS_INSTRUCTIONS.md`
5. let it walk the install and first-run steps with you

Here, `harness` just means your local AI helper or coding tool, for example Openwork, Codex Desktop, or Claude Code.

If you are the person operating the observer phone, start here instead:
- `MANUAL_START_HERE.html`
- `MANUAL_OPERATIONS.html`

If you are using an AI harness or technical helper, read these:
- `HARNESS_INSTRUCTIONS.md`
- `OBSERVER_ACCOUNT_RULES.md`
- `POLICY_RULEBOOK_TEMPLATE.md`
- `MANUAL_POLICY_AND_RULES.html`
- `MANUAL_DATA_MODEL.html`
- `PROOF_OF_LIFE_CHECKLIST.md`
- `TROUBLESHOOTING_AND_RECOVERY.md`

## Before you install

This starter is Mac-first and assumes:
- WhatsApp Desktop is installed on the Mac
- WhatsApp Desktop stays open during monitoring windows
- WhatsApp Desktop is linked to the observer phone through WhatsApp > Settings > Linked Devices
- a real phone still owns the WhatsApp account
- the observer account is set up as a boring, passive account rather than a working human account
- Node.js LTS is installed
- `python3` is available on the Mac
- the app running this stack can be granted Accessibility access if the doctor asks for it
- Focus / Do Not Disturb is off during monitoring windows

If `python3` is missing, install Apple's Command Line Tools first:

```bash
xcode-select --install
```

If Node.js is missing, install the current LTS release from `nodejs.org`.

If double-clicking a `.command` file is blocked, right-click it and choose `Open`.

## Install

From this folder:

```bash
npm install
```

Or double-click:
- `INSTALL.command`

You should not need a separate `pip install` step for the stripped-down starter.

## First run

1. Run `RUN_DOCTOR.command`
2. Run `START_STACK.command`
3. Run `CHECK_STATUS.command`
4. If the web-linked collector still needs its own pairing step, run `SHOW_ONBOARDING.command`
5. Run `LIVE_TEST.command`
6. If macOS asks for Accessibility or other privacy permissions during setup, allow them

What these files mean:
- `RUN_DOCTOR.command` checks whether the Mac has the basic prerequisites and whether the starter is ready for a live test.
- A `packet` is the local review record the system creates after it sees and processes a message.
- `LIVE_TEST.command` asks for one fresh group message with a unique test phrase, waits for the packet layer, and reports pass or fail.

What you want to see in `operator-packets-latest.json`:
- a recent row inside the `packets` array
- the right group or chat
- the right sender
- the right message text

## What your harness can likely finish quickly

A good local harness should be able to:
- get the stack installed and running
- relink Baileys if needed
- read the local packet JSON/SQLite outputs
- tune the editable policy markdown
- add a thin operator workflow on top
- keep the architecture local and Mac-first instead of trying to redesign it

What still needs wrapping:
- a polished operator workflow
- final routing and escalation rules
- any hosted dashboard or remote queue
- richer DM handling if you need it
- optional outbound operator messaging if you want the Mac to text someone directly
- a harder backup path if you later want a second observer setup or a cloud relay

## Important limits

- This is Mac-first.
- Group traffic is the strongest path.
- Native DMs are best-effort only.
- Direct messages through the web-linked collector are not included.
- Native notifications help wake the system up, but they are not perfect truth.
- Do not run this and another WhatsApp protocol collector on the same number at the same time.
