#!/usr/bin/env python3
"""
Turn canonical collector events into operator-facing packet rows.

This sits one layer above merge:
- reads canonical events from merged-events.sqlite3
- emits durable packet JSONL rows for downstream adapters/humans
- keeps its own emission state so merge rebuilds do not blindly resend
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shlex
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


STATE_SCHEMA = """
CREATE TABLE IF NOT EXISTS emitted_packets (
    packet_id TEXT PRIMARY KEY,
    canonical_event_id TEXT NOT NULL,
    packet_kind TEXT NOT NULL,
    route TEXT NOT NULL,
    priority TEXT NOT NULL,
    thread_key TEXT,
    actor_key TEXT,
    sender_key TEXT,
    sender_display_name TEXT,
    is_group INTEGER NOT NULL DEFAULT 0,
    group_name TEXT,
    source_confidence TEXT,
    primary_rule_id TEXT,
    primary_rule_label TEXT,
    primary_rule_confidence REAL,
    violation_guess TEXT,
    violation_confidence REAL,
    full_name_signal TEXT,
    solicitation_signal TEXT,
    respect_signal TEXT,
    overall_assessment TEXT,
    overall_assessment_score INTEGER,
    human_review_status TEXT,
    human_final_disposition TEXT,
    external_person_key TEXT,
    dispatch_target TEXT,
    dispatch_backup_target TEXT,
    dispatch_period TEXT,
    dispatch_mode TEXT,
    delivery_status TEXT,
    delivery_attempt_count INTEGER NOT NULL DEFAULT 0,
    last_delivery_attempt_at TEXT,
    last_delivery_error TEXT,
    delivered_at TEXT,
    presented_at TEXT,
    ack_required INTEGER NOT NULL DEFAULT 0,
    ack_timeout_seconds INTEGER,
    ack_due_at TEXT,
    escalate_after_seconds INTEGER,
    escalate_due_at TEXT,
    escalation_target TEXT,
    acknowledged_at TEXT,
    escalated_at TEXT,
    human_review_actor TEXT,
    human_review_note TEXT,
    human_review_updated_at TEXT,
    packet_revision INTEGER NOT NULL DEFAULT 1,
    supersedes_packet_id TEXT,
    superseded_by_packet_id TEXT,
    transition_reason TEXT,
    emitted_at TEXT NOT NULL,
    canonical_updated_at TEXT,
    last_observed_at TEXT,
    status TEXT NOT NULL,
    best_source_type TEXT,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS heartbeats (
    source TEXT PRIMARY KEY,
    observed_at TEXT NOT NULL,
    details_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS packet_events (
    event_id TEXT PRIMARY KEY,
    packet_id TEXT NOT NULL,
    canonical_event_id TEXT,
    event_type TEXT NOT NULL,
    action_type TEXT,
    source TEXT,
    actor TEXT,
    note TEXT,
    observed_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS connector_cursors (
    source_key TEXT PRIMARY KEY,
    cursor_value TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    details_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS connector_events (
    event_id TEXT PRIMARY KEY,
    source_key TEXT NOT NULL,
    connector_type TEXT NOT NULL,
    external_event_id TEXT NOT NULL,
    actor TEXT,
    raw_text TEXT,
    status TEXT NOT NULL,
    reason TEXT,
    observed_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);
"""

RICH_SOURCE_TYPES = {"baileys", "whatsapp_web", "whatsapp_web_js"}
DELIVERY_FINAL_STATUSES = {"accepted_by_adapter", "delivered_confirmed"}
DELIVERY_RETRYABLE_STATUSES = {
    "queued_local_only",
    "blocked_unwired_target",
    "dispatch_pending",
    "delivery_failed",
    "dispatching",
}

IMESSAGE_SEND_CHAT_SCRIPT = """on run argv
  tell application "Messages" to send (item 1 of argv) to chat id (item 2 of argv)
end run
"""

IMESSAGE_SEND_HANDLE_SCRIPT = """on run argv
  set bodyText to item 1 of argv
  set handleText to item 2 of argv
  set serviceTypeText to item 3 of argv
  tell application "Messages"
    repeat with svc in every service
      if (service type of svc as text) is serviceTypeText then
        send bodyText to buddy handleText of svc
        return
      end if
    end repeat
    error "No Messages service found for " & serviceTypeText
  end tell
end run
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def stable_hash(parts: list[str | None]) -> str:
    blob = json.dumps(parts, ensure_ascii=False, sort_keys=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def event_id_for(
    *,
    packet_id: str,
    event_type: str,
    observed_at: str,
    source: str | None,
    actor: str | None,
    action_type: str | None,
    payload: dict[str, Any] | None,
) -> str:
    return stable_hash(
        [
            packet_id,
            event_type,
            observed_at,
            normalize_text(source),
            normalize_text(actor),
            normalize_text(action_type),
            json.dumps(payload or {}, ensure_ascii=False, sort_keys=True),
        ]
    )


def operator_token_for(packet_id: str | None) -> str | None:
    text = normalize_text(packet_id)
    if not text:
        return None
    return text[:8].upper()


def normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = " ".join(value.strip().split())
    return cleaned or None


def derived_messages_chat_guid(target: str | None) -> str | None:
    text = normalize_text(target)
    if not text:
        return None
    if text.startswith("chat") or text.startswith("any;"):
        return text
    if " " in text:
        return None
    is_phone = bool(re.fullmatch(r"\+[1-9]\d{6,14}", text))
    is_email = bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", text))
    if not (is_phone or is_email):
        return None
    return f"any;-;{text}"


def safe_json_object(raw: str | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def safe_json_list(raw: str | None) -> list[Any]:
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return []
    return parsed if isinstance(parsed, list) else []


def slug_key(value: str | None) -> str | None:
    text = normalize_text(value)
    if not text:
        return None
    return re.sub(r"[^a-z0-9]+", "_", text.casefold()).strip("_") or None


def age_seconds_from_iso(value: str | None) -> float | None:
    parsed = parse_iso(value)
    if parsed is None:
        return None
    return max(0.0, (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds())


def future_iso(seconds: int | None) -> str | None:
    if seconds is None:
        return None
    return (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()


def retry_backoff_seconds(attempt_count: int) -> int:
    return min(60 * (2 ** max(0, attempt_count - 1)), 1800)


def now_dt() -> datetime:
    return datetime.now(timezone.utc)


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(f"{path.suffix}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def write_runtime_status(path: Path | None, payload: dict[str, Any]) -> None:
    if path is None:
        return
    atomic_write_json(path, payload)


def operator_action_status_payload(
    *,
    state: str,
    path: Path,
    source_key: str | None = None,
    reason: str | None = None,
    error: str | None = None,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "adapter": "imessage_chatdb",
        "state": state,
        "observed_at": utc_now(),
        "path": str(path),
    }
    if source_key:
        payload["source_key"] = source_key
    if reason:
        payload["reason"] = reason
    if error:
        payload["error"] = error
    if details:
        payload["details"] = details
    return payload


def classify_operator_action_error(exc: Exception, chat_db_path: Path) -> tuple[dict[str, Any], int]:
    text = str(exc)
    lowered = text.casefold()
    if isinstance(exc, ValueError) and "operator handle allowlist or operator chat guid is required" in lowered:
        return (
            operator_action_status_payload(
                state="blocked",
                path=chat_db_path,
                reason="operator_identity_unconfigured",
                error=text,
            ),
            2,
        )
    if "cannot read messages chat.db" in lowered or "full disk access" in lowered:
        return (
            operator_action_status_payload(
                state="blocked",
                path=chat_db_path,
                reason="chat_db_unreadable",
                error=text,
            ),
            2,
        )
    return (
        operator_action_status_payload(
            state="degraded",
            path=chat_db_path,
            reason="poll_failed",
            error=text,
        ),
        1,
    )


class ReadonlyCliCursor:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    def fetchone(self) -> dict[str, Any] | None:
        return self._rows[0] if self._rows else None

    def fetchall(self) -> list[dict[str, Any]]:
        return list(self._rows)


class ReadonlyCliConnection:
    def __init__(self, chat_db_path: Path) -> None:
        self.chat_db_path = chat_db_path
        self.sqlite3_bin = shutil.which("sqlite3")
        if not self.sqlite3_bin:
            raise RuntimeError("sqlite3 binary not found for Messages chat.db fallback")

    def _literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, (int, float)):
            return str(value)
        text = str(value).replace("'", "''")
        return f"'{text}'"

    def _render_query(self, query: str, params: tuple[Any, ...]) -> str:
        rendered = query
        for value in params:
            rendered = rendered.replace("?", self._literal(value), 1)
        return rendered

    def execute(self, query: str, params: tuple[Any, ...] = ()) -> ReadonlyCliCursor:
        sql = self._render_query(query, params)
        result = subprocess.run(
            [self.sqlite3_bin, "-readonly", "-json", str(self.chat_db_path), sql],
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
        if result.returncode != 0:
            error = result.stderr.strip() or result.stdout.strip() or f"sqlite3 exit {result.returncode}"
            raise RuntimeError(error)
        raw = result.stdout.strip()
        if not raw:
            rows: list[dict[str, Any]] = []
        else:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                rows = [parsed]
            elif isinstance(parsed, list):
                rows = [row for row in parsed if isinstance(row, dict)]
            else:
                rows = []
        return ReadonlyCliCursor(rows)

    def close(self) -> None:
        return None


def open_imessage_db(chat_db_path: Path) -> sqlite3.Connection | ReadonlyCliConnection:
    try:
        msg_conn = sqlite3.connect(f"file:{chat_db_path}?mode=ro&nolock=1", uri=True, timeout=5.0)
        msg_conn.row_factory = sqlite3.Row
        msg_conn.execute("PRAGMA query_only = ON")
        msg_conn.execute("SELECT 1")
        return msg_conn
    except sqlite3.Error as exc:
        try:
            fallback = ReadonlyCliConnection(chat_db_path)
            fallback.execute("SELECT 1 AS ok").fetchone()
            return fallback
        except Exception as fallback_exc:
            raise RuntimeError(
                f"cannot read Messages chat.db at {chat_db_path}: {exc}. "
                f"sqlite3 fallback also failed: {fallback_exc}. "
                "Grant Full Disk Access to the harness process before trusting inbound operator replies."
            ) from exc


def operator_loop_state_for(
    *,
    relay_adapter: str | None,
    webhook_url: str | None,
    command: str | None,
    pending_replies_path: Path | None,
) -> str:
    if relay_adapter == "imessage":
        if pending_replies_path is not None:
            return "outbound_imessage_with_followup_tracking"
        return "outbound_only_imessage"
    if command:
        return "outbound_only_local_command"
    if webhook_url:
        return "outbound_only_webhook"
    return "local_queue_only"


def coverage_profile_for(
    *,
    relay_adapter: str | None,
    webhook_url: str | None,
    command: str | None,
    pending_replies_path: Path | None,
) -> dict[str, Any]:
    operator_loop_state = operator_loop_state_for(
        relay_adapter=relay_adapter,
        webhook_url=webhook_url,
        command=command,
        pending_replies_path=pending_replies_path,
    )
    limitations = [
        "Group coverage is the strongest path and can be corroborated by Baileys plus native wake-up.",
        "Native DM coverage is best-effort only and should not be treated as authoritative intake.",
        "Baileys DM coverage is currently unsupported in this collector.",
        "Operator ACK/DONE/ESC/NACK tracks workflow state only and does not prove customer delivery.",
    ]
    if operator_loop_state == "local_queue_only":
        limitations.append("No outbound relay is wired yet, so actionable packets remain local to this Mac.")
    elif operator_loop_state == "outbound_imessage_with_followup_tracking":
        limitations.append("Outbound iMessage relay is live and sent items are tracked in the shared pending-replies surface; inbound operator reply automation still depends on the supervised actions adapter state.")
    else:
        limitations.append("Outbound relay can present packets; inbound operator reply ingestion depends on the supervised actions adapter state.")
    return {
        "groups": "dual_source_confirmable",
        "native_dms": "best_effort_notification_only",
        "baileys_dms": "unsupported",
        "operator_loop_state": operator_loop_state,
        "limitations": limitations,
    }


def iso_for_compare(value: str | None) -> str | None:
    parsed = parse_iso(value)
    if parsed is None:
        return None
    return parsed.astimezone(timezone.utc).isoformat()


def truncate_line(value: str | None, limit: int = 280) -> str:
    text = normalize_text(value) or ""
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def pending_reply_entry_for(packet: dict[str, Any], *, sent_at: str) -> dict[str, Any]:
    packet_id = normalize_text(packet.get("packet_id")) or "unknown-packet"
    target = normalize_text(packet.get("dispatch_target")) or normalize_text(packet.get("dispatch_backup_target"))
    chat_name = normalize_text(packet.get("group_name")) or normalize_text(packet.get("conversation_display"))
    sender = normalize_text(packet.get("sender_display_name")) or normalize_text(packet.get("sender_display"))
    summary = truncate_line(normalize_text(packet.get("operator_summary")), 180)
    if not summary:
        summary = truncate_line(
            f"{chat_name or 'WhatsApp chat'} | {sender or 'unknown sender'} | "
            f"{normalize_text(packet.get('message_text')) or 'message'}",
            180,
        )
    return {
        "id": f"operator-packet-{packet_id}",
        "schema_version": 1,
        "kind": "operator_followup_tracking",
        "platform": "imessage",
        "recipient": target or "unresolved-recipient",
        "channel_id": target or "",
        "sent_at": sent_at,
        "delivery_semantics": "local_send_accepted",
        "topic": summary,
        "urgency": (normalize_text(packet.get("priority")) or "medium").casefold(),
        "status": "awaiting_reply",
        "source": "operator_packet",
        "packet_id": packet_id,
        "route": normalize_text(packet.get("route")) or "",
        "group_name": chat_name or "",
        "sender_display_name": sender or "",
        "message_preview": truncate_line(
            normalize_text(packet.get("message_text")) or "(no visible message text)",
            220,
        ),
    }


def split_dispatch_text(text: str, limit: int = 900) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= limit:
        return [text]

    chunks: list[str] = []
    current = ""
    for line in text.splitlines():
        candidate = line if not current else f"{current}\n{line}"
        if len(candidate) <= limit:
            current = candidate
            continue
        if current:
            chunks.append(current)
            current = ""
        while len(line) > limit:
            chunks.append(line[:limit].rstrip())
            line = line[limit:].lstrip()
        current = line
    if current:
        chunks.append(current)
    return chunks


def dispatch_text_for(packet: dict[str, Any]) -> str:
    operator_token = operator_token_for(packet.get("packet_id"))
    lines = [f"WhatsApp alert [{str(packet.get('priority') or 'medium').upper()}]"]
    route = normalize_text(packet.get("route"))
    if route:
        lines.append(f"Queue: {route}")

    conversation = normalize_text(packet.get("group_name")) or normalize_text(packet.get("conversation_display"))
    if conversation:
        lines.append(f"Chat: {conversation}")

    sender = normalize_text(packet.get("sender_display_name")) or normalize_text(packet.get("sender_display"))
    if sender:
        lines.append(f"From: {sender}")

    message_text = truncate_line(packet.get("message_text"), 320) or "(no visible message text)"
    lines.append(f"Message: {message_text}")

    assessment = normalize_text(packet.get("overall_assessment"))
    if assessment and assessment != "none":
        lines.append(f"Assessment: {assessment}")

    rule_label = normalize_text(packet.get("primary_rule_label")) or normalize_text(packet.get("violation_guess"))
    if rule_label:
        lines.append(f"Flag: {rule_label}")

    suggested_actions = packet.get("suggested_actions") or []
    if isinstance(suggested_actions, list) and suggested_actions:
        lines.append(f"Next: {truncate_line(str(suggested_actions[0]), 220)}")

    response_guidance = normalize_text(packet.get("response_guidance"))
    if response_guidance:
        lines.append(f"Tone: {truncate_line(response_guidance, 180)}")

    if operator_token:
        lines.append(f"Token: {operator_token}")
        lines.append(f"Reply: ACK {operator_token} | DONE {operator_token} | ESC {operator_token}")
    return "\n".join(line for line in lines if line)


OPERATOR_REPLY_RE = re.compile(
    r"^\s*(ACK|DONE|ESC|NACK)\s+([A-Z0-9]{6,12})(?:\s+(.+))?\s*$",
    re.IGNORECASE,
)

APPLE_EPOCH_MS = 978307200000


def parse_operator_reply(text: str | None) -> dict[str, str] | None:
    normalized = normalize_text(text)
    if not normalized:
        return None
    match = OPERATOR_REPLY_RE.match(normalized)
    if not match:
        return None
    action = match.group(1).upper()
    token = match.group(2).upper()
    note = normalize_text(match.group(3))
    return {"action": action, "token": token, "note": note or ""}


def apple_ns_to_iso(value: int | None) -> str | None:
    if value is None:
        return None
    try:
        return datetime.fromtimestamp((int(value) / 1e9) + (APPLE_EPOCH_MS / 1000), tz=timezone.utc).isoformat()
    except Exception:
        return None


def parse_attributed_body(blob: bytes | str | None) -> str | None:
    if not blob:
        return None
    if isinstance(blob, str):
        try:
            blob = blob.encode("latin-1")
        except UnicodeEncodeError:
            return None
    marker = b"NSString"
    idx = blob.find(marker)
    if idx < 0:
        return None
    idx += len(marker)
    while idx < len(blob) and blob[idx] != 0x2B:
        idx += 1
    if idx >= len(blob):
        return None
    idx += 1
    if idx >= len(blob):
        return None
    flag = blob[idx]
    idx += 1
    if flag == 0x81:
        if idx >= len(blob):
            return None
        length = blob[idx]
        idx += 1
    elif flag == 0x82:
        if idx + 2 > len(blob):
            return None
        length = int.from_bytes(blob[idx:idx + 2], "little")
        idx += 2
    elif flag == 0x83:
        if idx + 3 > len(blob):
            return None
        length = int.from_bytes(blob[idx:idx + 3], "little")
        idx += 3
    else:
        length = flag
    if idx + length > len(blob):
        return None
    try:
        return blob[idx:idx + length].decode("utf-8")
    except UnicodeDecodeError:
        return None


def imessage_message_text(row: sqlite3.Row) -> str:
    raw = row["text"]
    if raw:
        return str(raw)
    parsed = parse_attributed_body(row["attributedBody"])
    return parsed or ""


def normalize_operator_handle(value: str | None) -> str | None:
    text = normalize_text(value)
    if not text:
        return None
    stripped = text.casefold()
    if stripped.startswith("e:") or stripped.startswith("p:"):
        stripped = stripped[2:]
    return stripped


def looks_like_system_event(message_text: str | None) -> bool:
    text = (message_text or "").strip()
    if not text:
        return True
    lowered = text.casefold()
    return (
        " added you to the group " in lowered
        or lowered.startswith("you were added")
        or lowered.startswith("security code")
        or lowered.startswith("messages and calls are end-to-end encrypted")
    )


def looks_like_full_name(sender_display: str | None) -> bool:
    text = normalize_text(sender_display)
    if not text:
        return False
    lowered = text.casefold()
    if lowered.startswith("+") or any(char.isdigit() for char in lowered):
        return False
    parts = [part for part in text.split(" ") if part]
    return len(parts) >= 2


def full_name_rule_hint(sender_display: str | None) -> dict[str, Any] | None:
    text = normalize_text(sender_display)
    if not text or looks_like_full_name(text):
        return None
    return {
        "rule_id": "full_name_rule",
        "label": "Full name check",
        "severity": "medium",
        "confidence": 0.6,
        "reason": f"Sender display '{text}' does not look like a full real name.",
    }


def solicitation_rule_hint(message_text: str | None) -> dict[str, Any] | None:
    text = (normalize_text(message_text) or "").casefold()
    if not text:
        return None
    phrases = [
        "dm me",
        "book a call",
        "check out my",
        "check out our",
        "for sale",
        "discount code",
        "sign up",
        "buy my",
        "buy our",
        "invest in my",
        "invest in this deal",
        "raising for",
        "looking for investors",
        "we're offering",
        "we are offering",
        "my service",
        "our service",
        "my product",
        "our product",
        "my resort",
        "our resort",
    ]
    matched = [phrase for phrase in phrases if phrase in text]
    if not matched:
        return None
    return {
        "rule_id": "no_solicitation_rule",
        "label": "Potential solicitation",
        "severity": "high",
        "confidence": 0.7,
        "reason": f"Message matched solicitation phrase(s): {', '.join(matched[:3])}.",
    }


def respect_rule_hint(message_text: str | None) -> dict[str, Any] | None:
    text = (normalize_text(message_text) or "").casefold()
    if not text:
        return None
    phrases = [
        "fuck you",
        "you idiot",
        "you're an idiot",
        "you are an idiot",
        "shut up",
        "moron",
        "dumbass",
        "piece of shit",
        "go to hell",
        "you suck",
        "trash take",
    ]
    matched = [phrase for phrase in phrases if phrase in text]
    if not matched:
        return None
    return {
        "rule_id": "respect_rule",
        "label": "Respect escalation",
        "severity": "high",
        "confidence": 0.75,
        "reason": f"Message matched hostile phrase(s): {', '.join(matched[:3])}.",
    }


def build_rule_hints(sender_display: str | None, message_text: str | None) -> list[dict[str, Any]]:
    hints: list[dict[str, Any]] = []
    for hint in (
        full_name_rule_hint(sender_display),
        solicitation_rule_hint(message_text),
        respect_rule_hint(message_text),
    ):
        if hint is not None:
            hints.append(hint)
    return hints


ASSESSMENT_ORDER = {
    "none": 0,
    "questionable": 1,
    "likely": 2,
    "confirmed": 3,
}

ASSESSMENT_SCORE = {
    "none": 0,
    "questionable": 35,
    "likely": 70,
    "confirmed": 100,
}


def signal_level_for_hint(hint: dict[str, Any] | None) -> str:
    if hint is None:
        return "none"
    confidence = float(hint.get("confidence") or 0.0)
    severity = str(hint.get("severity") or "").casefold()
    if confidence >= 0.9:
        return "confirmed"
    if confidence >= 0.75:
        return "likely"
    if severity == "high" and confidence >= 0.7:
        return "likely"
    return "questionable"


def select_primary_rule(rule_hints: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not rule_hints:
        return None
    return max(
        rule_hints,
        key=lambda hint: (
            ASSESSMENT_ORDER[signal_level_for_hint(hint)],
            float(hint.get("confidence") or 0.0),
        ),
    )


def overall_assessment_from_hints(rule_hints: list[dict[str, Any]]) -> str:
    level = "none"
    for hint in rule_hints:
        hint_level = signal_level_for_hint(hint)
        if ASSESSMENT_ORDER[hint_level] > ASSESSMENT_ORDER[level]:
            level = hint_level
    return level


def signal_for_rule(rule_hints: list[dict[str, Any]], rule_id: str) -> str:
    matching = [hint for hint in rule_hints if hint.get("rule_id") == rule_id]
    if not matching:
        return "none"
    return max((signal_level_for_hint(hint) for hint in matching), key=lambda level: ASSESSMENT_ORDER[level])


def source_confidence_for(row: sqlite3.Row) -> str:
    best_source = row["best_source_type"]
    if best_source in RICH_SOURCE_TYPES and row["status"] == "confirmed":
        return "high"
    if best_source in RICH_SOURCE_TYPES:
        return "medium"
    return "low"


def actor_key_for(row: sqlite3.Row) -> str | None:
    return row["sender_key"] or slug_key(row["sender_display"])


def is_group_for(row: sqlite3.Row) -> bool:
    conversation_key = row["conversation_key"] or ""
    return conversation_key.endswith("@g.us")


def suggested_actions_for(route: str, rule_hints: list[dict[str, Any]]) -> list[str]:
    actions: list[str] = []
    rule_ids = {hint["rule_id"] for hint in rule_hints}
    if "full_name_rule" in rule_ids:
        actions.append("Ask the member to update their WhatsApp profile to a full real name.")
    if "no_solicitation_rule" in rule_ids:
        actions.append("Review whether the message is pitching a deal, product, or service and remind them solicitation is not allowed.")
    if "respect_rule" in rule_ids:
        actions.append("Review the surrounding thread for escalation and consider a de-escalation warning or temporary freeze.")
    if not actions:
        if route == "review_now":
            actions.append("Open the thread and decide whether intervention is needed now.")
        elif route == "review_pending_confirmation":
            actions.append("Monitor for confirming evidence or open the thread manually if the context looks risky.")
    return actions


def response_guidance_for(rule_hints: list[dict[str, Any]]) -> str | None:
    rule_ids = {hint["rule_id"] for hint in rule_hints}
    if "respect_rule" in rule_ids:
        return "Keep the message calm, brief, and de-escalatory."
    if "no_solicitation_rule" in rule_ids:
        return "Be clear about the no-solicitation policy without sounding accusatory."
    if "full_name_rule" in rule_ids:
        return "Use a friendly reminder tone and explain the rule simply."
    return None


def packet_kind_for(row: sqlite3.Row) -> str:
    if looks_like_system_event(row["message_text"]):
        return "system_event"
    if row["status"] == "confirmed":
        return "confirmed_message"
    if row["best_source_type"] in RICH_SOURCE_TYPES:
        return "rich_provisional_message"
    return "notification_provisional_message"


def route_for(row: sqlite3.Row) -> str:
    if looks_like_system_event(row["message_text"]):
        return "log_only"
    if row["status"] == "confirmed":
        return "review_now"
    if row["best_source_type"] in RICH_SOURCE_TYPES:
        return "review_pending_confirmation"
    return "hold_for_confirmation"


def priority_for(row: sqlite3.Row) -> str:
    if looks_like_system_event(row["message_text"]):
        return "low"
    if row["status"] == "confirmed":
        return "high"
    if row["best_source_type"] in RICH_SOURCE_TYPES:
        return "medium"
    return "low"


def packet_id_for(row: sqlite3.Row) -> str:
    return stable_hash(
        [
            row["canonical_event_id"],
            row["status"],
            row["best_source_type"],
            str(row["source_count"]),
            str(row["evidence_count"]),
            row["last_observed_at"],
            row["updated_at"],
        ]
    )


def operator_summary_for(row: sqlite3.Row, route: str) -> str:
    conversation = row["conversation_display"] or "Unknown chat"
    sender = row["sender_display"] or "Unknown sender"
    message = normalize_text(row["message_text"]) or "(no visible message text)"
    return f"{route} | {conversation} | {sender}: {message}"


def packet_assessment_fields(
    *,
    conversation_key: str | None,
    conversation_display: str | None,
    sender_key: str | None,
    sender_display: str | None,
    best_source_type: str | None,
    status: str | None,
    rule_hints: list[dict[str, Any]],
) -> dict[str, Any]:
    primary_rule = select_primary_rule(rule_hints)
    overall_assessment = overall_assessment_from_hints(rule_hints)
    is_group = bool((conversation_key or "").endswith("@g.us"))
    group_name = conversation_display if is_group else None
    source_confidence = "low"
    if best_source_type in RICH_SOURCE_TYPES and status == "confirmed":
        source_confidence = "high"
    elif best_source_type in RICH_SOURCE_TYPES:
        source_confidence = "medium"
    actor_key = sender_key
    identity_quality = "stable_sender_key"
    if not actor_key:
        display_slug = slug_key(sender_display)
        if display_slug:
            actor_key = f"display:{display_slug}"
            identity_quality = "display_name_fallback"
        else:
            identity_quality = "unknown"
    return {
        "thread_key": conversation_key,
        "actor_key": actor_key,
        "sender_key": sender_key,
        "sender_display_name": sender_display,
        "is_group": is_group,
        "group_name": group_name,
        "source_confidence": source_confidence,
        "primary_rule_id": primary_rule["rule_id"] if primary_rule else None,
        "primary_rule_label": primary_rule["label"] if primary_rule else None,
        "primary_rule_confidence": float(primary_rule["confidence"]) if primary_rule else None,
        "violation_guess": primary_rule["rule_id"] if primary_rule else None,
        "violation_confidence": float(primary_rule["confidence"]) if primary_rule else None,
        "full_name_signal": signal_for_rule(rule_hints, "full_name_rule"),
        "solicitation_signal": signal_for_rule(rule_hints, "no_solicitation_rule"),
        "respect_signal": signal_for_rule(rule_hints, "respect_rule"),
        "overall_assessment": overall_assessment,
        "overall_assessment_score": ASSESSMENT_SCORE[overall_assessment],
        "identity_quality": identity_quality,
        "human_review_status": None,
        "human_final_disposition": None,
        "external_person_key": None,
    }


class PacketEmitter:
    def __init__(
        self,
        *,
        merge_db: Path,
        state_db: Path,
        output_path: Path,
        status_path: Path,
        latest_snapshot_path: Path | None = None,
        include_notification_only: bool = False,
        webhook_url: str | None = None,
        command: str | None = None,
        relay_adapter: str | None = None,
        primary_destination: str | None = None,
        after_hours_destination: str | None = None,
        backup_destination: str | None = None,
        pending_replies_path: Path | None = None,
        dispatch_not_before: str | None = None,
        imessage_service: str | None = None,
        imessage_chat_guid: str | None = None,
        dispatch_lease_seconds: int = 45,
        max_delivery_attempts: int = 5,
        business_hours_start: int = 8,
        business_hours_end: int = 18,
        ack_timeout_high: int = 300,
        ack_timeout_medium: int = 900,
        ack_timeout_low: int = 1800,
        escalate_after_high: int = 600,
        escalate_after_medium: int = 1800,
        escalate_after_low: int = 3600,
    ) -> None:
        self.merge_db = merge_db
        self.state_db = state_db
        self.output_path = output_path
        self.status_path = status_path
        self.latest_snapshot_path = latest_snapshot_path
        self.include_notification_only = include_notification_only
        self.webhook_url = webhook_url
        self.command = command
        self.relay_adapter = (normalize_text(relay_adapter) or "").casefold() or None
        self.primary_destination = normalize_text(primary_destination)
        self.after_hours_destination = normalize_text(after_hours_destination)
        self.backup_destination = normalize_text(backup_destination)
        self.pending_replies_path = pending_replies_path
        self.dispatch_not_before = iso_for_compare(dispatch_not_before)
        self.imessage_service = normalize_text(imessage_service) or "iMessage"
        self.imessage_chat_guid = normalize_text(imessage_chat_guid)
        self.dispatch_lease_seconds = max(5, int(dispatch_lease_seconds))
        self.max_delivery_attempts = max(1, int(max_delivery_attempts))
        self.business_hours_start = business_hours_start
        self.business_hours_end = business_hours_end
        self.ack_timeout_high = ack_timeout_high
        self.ack_timeout_medium = ack_timeout_medium
        self.ack_timeout_low = ack_timeout_low
        self.escalate_after_high = escalate_after_high
        self.escalate_after_medium = escalate_after_medium
        self.escalate_after_low = escalate_after_low
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_db.parent.mkdir(parents=True, exist_ok=True)
        if self.latest_snapshot_path:
            self.latest_snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.state_db, timeout=30.0)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA synchronous = NORMAL")
        self.conn.execute("PRAGMA busy_timeout = 30000")
        self.conn.executescript(STATE_SCHEMA)
        self._ensure_schema()
        self._backfill_existing_packet_chain()
        self._ensure_packet_event_history()
        self.conn.commit()

    def _within_business_hours(self) -> bool:
        current_hour = datetime.now().astimezone().hour
        start = self.business_hours_start
        end = self.business_hours_end
        if start == end:
            return True
        if start < end:
            return start <= current_hour < end
        return current_hour >= start or current_hour < end

    def routing_fields_for(self, route: str, priority: str) -> dict[str, Any]:
        in_business_hours = self._within_business_hours()
        dispatch_period = "business_hours" if in_business_hours else "after_hours"
        dispatch_target = self.primary_destination
        if not in_business_hours and self.after_hours_destination:
            dispatch_target = self.after_hours_destination

        if route == "log_only":
            ack_required = False
            ack_timeout_seconds = None
            escalate_after_seconds = None
        elif route == "review_now":
            ack_required = True
            if priority == "high":
                ack_timeout_seconds = self.ack_timeout_high
                escalate_after_seconds = self.escalate_after_high
            elif priority == "medium":
                ack_timeout_seconds = self.ack_timeout_medium
                escalate_after_seconds = self.escalate_after_medium
            else:
                ack_timeout_seconds = self.ack_timeout_low
                escalate_after_seconds = self.escalate_after_low
        elif route == "review_pending_confirmation":
            ack_required = True
            ack_timeout_seconds = self.ack_timeout_medium
            escalate_after_seconds = self.escalate_after_medium
        else:
            ack_required = False
            ack_timeout_seconds = None
            escalate_after_seconds = None

        if ack_required and ack_timeout_seconds is not None and escalate_after_seconds is not None:
            escalate_after_seconds = max(escalate_after_seconds, ack_timeout_seconds)

        if self.relay_adapter == "imessage" and (self.imessage_chat_guid or dispatch_target):
            dispatch_mode = "local_imessage"
        elif self.command:
            dispatch_mode = "local_command"
        elif self.webhook_url:
            dispatch_mode = "remote_webhook"
        elif dispatch_target:
            dispatch_mode = "destination_resolved_unwired"
        else:
            dispatch_mode = "local_queue_only"

        if dispatch_mode == "local_queue_only":
            delivery_status = "queued_local_only"
        elif dispatch_mode == "destination_resolved_unwired":
            delivery_status = "blocked_unwired_target"
        else:
            delivery_status = "dispatch_pending"

        return {
            "dispatch_target": dispatch_target,
            "dispatch_backup_target": self.backup_destination,
            "dispatch_period": dispatch_period,
            "dispatch_mode": dispatch_mode,
            "delivery_status": delivery_status,
            "delivery_attempt_count": 0,
            "last_delivery_attempt_at": None,
            "last_delivery_error": None,
            "delivered_at": None,
            "presented_at": None,
            "ack_required": ack_required,
            "ack_timeout_seconds": ack_timeout_seconds,
            "ack_due_at": None,
            "escalate_after_seconds": escalate_after_seconds if ack_required else None,
            "escalate_due_at": None,
            "escalation_target": self.backup_destination if ack_required else None,
            "acknowledged_at": None,
            "escalated_at": None,
            "human_review_actor": None,
            "human_review_note": None,
            "human_review_updated_at": None,
        }

    def close(self) -> None:
        self.conn.close()

    def _run_osascript(self, script: str, *argv: str) -> None:
        result = subprocess.run(
            ["osascript", "-", *argv],
            input=script,
            text=True,
            capture_output=True,
            timeout=15,
            check=False,
        )
        if result.returncode != 0:
            error = result.stderr.strip() or result.stdout.strip() or f"osascript exit {result.returncode}"
            raise RuntimeError(error)

    def _send_imessage(self, packet: dict[str, Any]) -> dict[str, Any]:
        message = dispatch_text_for(packet)
        chunks = split_dispatch_text(message)
        if not chunks:
            raise ValueError("dispatch text was empty")

        target = normalize_text(packet.get("dispatch_target"))
        chat_candidates: list[str] = []
        for candidate in (self.imessage_chat_guid, derived_messages_chat_guid(target)):
            if candidate and candidate not in chat_candidates:
                chat_candidates.append(candidate)

        chat_errors: list[str] = []
        for chat_guid in chat_candidates:
            try:
                for chunk in chunks:
                    self._run_osascript(IMESSAGE_SEND_CHAT_SCRIPT, chunk, chat_guid)
                return {"send_path": "chat_guid", "chat_guid": chat_guid}
            except RuntimeError as exc:
                chat_errors.append(f"{chat_guid}: {exc}")

        if not target:
            if chat_errors:
                raise RuntimeError(" ; ".join(chat_errors))
            raise ValueError("dispatch target required for imessage relay")

        try:
            for chunk in chunks:
                self._run_osascript(IMESSAGE_SEND_HANDLE_SCRIPT, chunk, target, self.imessage_service)
            return {"send_path": "handle", "handle": target, "service": self.imessage_service}
        except RuntimeError as exc:
            if chat_errors:
                raise RuntimeError(" ; ".join(chat_errors + [f"handle:{exc}"])) from exc
            raise

    def register_pending_reply(self, packet: dict[str, Any], *, sent_at: str) -> dict[str, Any] | None:
        path = self.pending_replies_path
        if path is None:
            return None
        path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = path.with_suffix(path.suffix + ".lock")
        entry = pending_reply_entry_for(packet, sent_at=sent_at)
        with lock_path.open("a+", encoding="utf-8") as lock_handle:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
            rows: list[Any] = []
            if path.exists():
                try:
                    payload = json.loads(path.read_text(encoding="utf-8"))
                except Exception as exc:
                    raise RuntimeError(f"cannot parse pending replies file at {path}: {exc}") from exc
                if not isinstance(payload, list):
                    raise RuntimeError(
                        f"pending replies file at {path} is not a JSON array; refusing to rewrite foreign schema"
                    )
                rows = payload
            existing_index = next(
                (
                    index
                    for index, row in enumerate(rows)
                    if isinstance(row, dict) and normalize_text(row.get("id")) == entry["id"]
                ),
                None,
            )
            if existing_index is None:
                rows.append(entry)
            else:
                current = rows[existing_index] if isinstance(rows[existing_index], dict) else {}
                merged = dict(current)
                merged.update(entry)
                rows[existing_index] = merged
                entry = merged
            temp_path = path.with_name(f"{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
            temp_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(temp_path, path)
        return entry

    def _ensure_schema(self) -> None:
        existing_columns = {
            row["name"] for row in self.conn.execute("PRAGMA table_info(emitted_packets)")
        }
        wanted_columns = {
            "thread_key": "TEXT",
            "actor_key": "TEXT",
            "sender_key": "TEXT",
            "sender_display_name": "TEXT",
            "is_group": "INTEGER NOT NULL DEFAULT 0",
            "group_name": "TEXT",
            "source_confidence": "TEXT",
            "primary_rule_id": "TEXT",
            "primary_rule_label": "TEXT",
            "primary_rule_confidence": "REAL",
            "violation_guess": "TEXT",
            "violation_confidence": "REAL",
            "full_name_signal": "TEXT",
            "solicitation_signal": "TEXT",
            "respect_signal": "TEXT",
            "overall_assessment": "TEXT",
            "overall_assessment_score": "INTEGER",
            "identity_quality": "TEXT",
            "human_review_status": "TEXT",
            "human_final_disposition": "TEXT",
            "external_person_key": "TEXT",
            "dispatch_target": "TEXT",
            "dispatch_backup_target": "TEXT",
            "dispatch_period": "TEXT",
            "dispatch_mode": "TEXT",
            "delivery_status": "TEXT",
            "delivery_attempt_count": "INTEGER NOT NULL DEFAULT 0",
            "last_delivery_attempt_at": "TEXT",
            "last_delivery_error": "TEXT",
            "delivered_at": "TEXT",
            "presented_at": "TEXT",
            "ack_required": "INTEGER NOT NULL DEFAULT 0",
            "ack_timeout_seconds": "INTEGER",
            "ack_due_at": "TEXT",
            "escalate_after_seconds": "INTEGER",
            "escalate_due_at": "TEXT",
            "escalation_target": "TEXT",
            "acknowledged_at": "TEXT",
            "escalated_at": "TEXT",
            "human_review_actor": "TEXT",
            "human_review_note": "TEXT",
            "human_review_updated_at": "TEXT",
            "packet_revision": "INTEGER NOT NULL DEFAULT 1",
            "supersedes_packet_id": "TEXT",
            "superseded_by_packet_id": "TEXT",
            "transition_reason": "TEXT",
        }
        for name, definition in wanted_columns.items():
            if name not in existing_columns:
                self.conn.execute(f"ALTER TABLE emitted_packets ADD COLUMN {name} {definition}")
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_emitted_packets_current ON emitted_packets(superseded_by_packet_id)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_emitted_packets_actor ON emitted_packets(actor_key, overall_assessment)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_emitted_packets_thread ON emitted_packets(thread_key, overall_assessment)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_emitted_packets_canonical ON emitted_packets(canonical_event_id, packet_revision, emitted_at)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_emitted_packets_delivery ON emitted_packets(delivery_status, ack_due_at)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_packet_events_packet ON packet_events(packet_id, observed_at)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_packet_events_type ON packet_events(event_type, observed_at)"
        )
        self.conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_connector_events_source_ext ON connector_events(source_key, external_event_id)"
        )
        self.conn.execute("DROP VIEW IF EXISTS current_packets")
        self.conn.execute(
            """
            CREATE VIEW current_packets AS
            SELECT ep.*
            FROM emitted_packets ep
            WHERE NOT EXISTS (
                SELECT 1
                FROM emitted_packets newer
                WHERE newer.canonical_event_id = ep.canonical_event_id
                  AND (
                    COALESCE(newer.packet_revision, 1) > COALESCE(ep.packet_revision, 1)
                    OR (
                        COALESCE(newer.packet_revision, 1) = COALESCE(ep.packet_revision, 1)
                        AND newer.emitted_at > ep.emitted_at
                    )
                    OR (
                        COALESCE(newer.packet_revision, 1) = COALESCE(ep.packet_revision, 1)
                        AND newer.emitted_at = ep.emitted_at
                        AND newer.rowid > ep.rowid
                    )
                  )
            )
            """
        )
        self.conn.execute("DROP VIEW IF EXISTS sender_risk_rollup")
        self.conn.execute(
            """
            CREATE VIEW sender_risk_rollup AS
            SELECT
                COALESCE(actor_key, 'packet:' || packet_id) AS actor_bucket,
                MAX(sender_display_name) AS sender_display_name,
                MAX(sender_key) AS sender_key,
                MAX(identity_quality) AS identity_quality,
                COUNT(*) AS total_packets,
                SUM(CASE WHEN overall_assessment = 'questionable' THEN 1 ELSE 0 END) AS questionable_count,
                SUM(CASE WHEN overall_assessment = 'likely' THEN 1 ELSE 0 END) AS likely_count,
                SUM(CASE WHEN overall_assessment = 'confirmed' THEN 1 ELSE 0 END) AS confirmed_count,
                COUNT(DISTINCT thread_key) AS distinct_threads,
                MAX(last_observed_at) AS last_seen_at
            FROM current_packets
            GROUP BY COALESCE(actor_key, 'packet:' || packet_id)
            """
        )

    def append_packet_event(
        self,
        *,
        packet_id: str,
        canonical_event_id: str | None,
        event_type: str,
        action_type: str | None = None,
        source: str | None = None,
        actor: str | None = None,
        note: str | None = None,
        payload: dict[str, Any] | None = None,
        observed_at: str | None = None,
        commit: bool = False,
    ) -> dict[str, Any]:
        observed = observed_at or utc_now()
        event_payload = payload or {}
        event_id = event_id_for(
            packet_id=packet_id,
            event_type=event_type,
            observed_at=observed,
            source=source,
            actor=actor,
            action_type=action_type,
            payload=event_payload,
        )
        self.conn.execute(
            """
            INSERT OR REPLACE INTO packet_events (
                event_id,
                packet_id,
                canonical_event_id,
                event_type,
                action_type,
                source,
                actor,
                note,
                observed_at,
                payload_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id,
                packet_id,
                canonical_event_id,
                event_type,
                normalize_text(action_type),
                normalize_text(source),
                normalize_text(actor),
                normalize_text(note),
                observed,
                json.dumps(event_payload, ensure_ascii=False),
            ),
        )
        if commit:
            self.conn.commit()
        return {
            "event_id": event_id,
            "packet_id": packet_id,
            "canonical_event_id": canonical_event_id,
            "event_type": event_type,
            "action_type": normalize_text(action_type),
            "source": normalize_text(source),
            "actor": normalize_text(actor),
            "note": normalize_text(note),
            "observed_at": observed,
            "payload": event_payload,
        }

    def connector_event_exists(self, source_key: str, external_event_id: str) -> bool:
        row = self.conn.execute(
            """
            SELECT 1
            FROM connector_events
            WHERE source_key = ?
              AND external_event_id = ?
            LIMIT 1
            """,
            (source_key, external_event_id),
        ).fetchone()
        return row is not None

    def append_connector_event(
        self,
        *,
        source_key: str,
        connector_type: str,
        external_event_id: str,
        status: str,
        actor: str | None = None,
        raw_text: str | None = None,
        reason: str | None = None,
        payload: dict[str, Any] | None = None,
        observed_at: str | None = None,
        commit: bool = False,
    ) -> dict[str, Any]:
        observed = observed_at or utc_now()
        event_payload = payload or {}
        event_id = stable_hash(
            [
                source_key,
                connector_type,
                external_event_id,
                status,
                observed,
                normalize_text(actor),
                normalize_text(reason),
                json.dumps(event_payload, ensure_ascii=False, sort_keys=True),
            ]
        )
        self.conn.execute(
            """
            INSERT OR REPLACE INTO connector_events (
                event_id,
                source_key,
                connector_type,
                external_event_id,
                actor,
                raw_text,
                status,
                reason,
                observed_at,
                payload_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id,
                source_key,
                connector_type,
                external_event_id,
                normalize_text(actor),
                raw_text,
                status,
                normalize_text(reason),
                observed,
                json.dumps(event_payload, ensure_ascii=False),
            ),
        )
        if commit:
            self.conn.commit()
        return {
            "event_id": event_id,
            "source_key": source_key,
            "connector_type": connector_type,
            "external_event_id": external_event_id,
            "status": status,
            "actor": normalize_text(actor),
            "reason": normalize_text(reason),
            "observed_at": observed,
            "payload": event_payload,
        }

    def retry_deferred_operator_actions(
        self,
        *,
        source_key: str,
        limit: int = 25,
    ) -> dict[str, int]:
        rows = self.conn.execute(
            """
            SELECT event_id, actor, raw_text, payload_json
            FROM connector_events
            WHERE source_key = ?
              AND connector_type = 'imessage_chatdb'
              AND status = 'deferred_packet_resolution'
            ORDER BY observed_at ASC
            LIMIT ?
            """,
            (source_key, limit),
        ).fetchall()
        retried = 0
        resolved = 0
        for row in rows:
            payload = safe_json_object(row["payload_json"])
            token = normalize_text(payload.get("token"))
            action_type = normalize_text(payload.get("action_type"))
            if not token or not action_type:
                continue
            retried += 1
            packet_rows = self.conn.execute(
                """
                SELECT packet_id
                FROM current_packets
                WHERE UPPER(SUBSTR(packet_id, 1, 8)) = ?
                """,
                (token.upper(),),
            ).fetchall()
            if len(packet_rows) != 1:
                continue
            packet_id = packet_rows[0]["packet_id"]
            self.apply_operator_action(
                packet_id=packet_id,
                action_type=action_type,
                actor=row["actor"],
                source="imessage_chatdb",
                note=normalize_text(payload.get("note")) or row["raw_text"],
                commit=False,
            )
            next_payload = dict(payload)
            next_payload.update(
                {
                    "packet_id": packet_id,
                    "match_count": 1,
                    "resolved_at": utc_now(),
                }
            )
            self.conn.execute(
                """
                UPDATE connector_events
                SET status = 'accepted',
                    reason = NULL,
                    payload_json = ?
                WHERE event_id = ?
                """,
                (json.dumps(next_payload, ensure_ascii=False), row["event_id"]),
            )
            resolved += 1
        return {"retried": retried, "resolved": resolved}

    def _transition_reason_for_rows(
        self,
        previous_packet: sqlite3.Row | None,
        current_packet: sqlite3.Row,
    ) -> str | None:
        if previous_packet is None:
            return None
        if previous_packet["status"] != current_packet["status"]:
            return "status_upgrade"
        if previous_packet["route"] != current_packet["route"]:
            return "route_change"
        if previous_packet["priority"] != current_packet["priority"]:
            return "priority_change"
        if previous_packet["packet_kind"] != current_packet["packet_kind"]:
            return "kind_change"
        if previous_packet["canonical_updated_at"] != current_packet["canonical_updated_at"]:
            return "state_refresh"
        return None

    def _backfill_existing_packet_chain(self) -> None:
        rows = self.conn.execute(
            """
            SELECT rowid, *
            FROM emitted_packets
            ORDER BY canonical_event_id ASC, emitted_at ASC, rowid ASC
            """
        ).fetchall()
        if not rows:
            return

        changed = False
        current_group: list[sqlite3.Row] = []
        current_canonical: str | None = None

        def flush_group(group: list[sqlite3.Row]) -> None:
            nonlocal changed
            lease_cutoff = (now_dt() - timedelta(seconds=self.dispatch_lease_seconds)).isoformat()
            for index, row in enumerate(group):
                previous_row = group[index - 1] if index > 0 else None
                next_row = group[index + 1] if index + 1 < len(group) else None
                expected_revision = index + 1
                expected_supersedes = previous_row["packet_id"] if previous_row is not None else None
                expected_superseded_by = next_row["packet_id"] if next_row is not None else None
                expected_transition = self._transition_reason_for_rows(previous_row, row)
                payload = safe_json_object(row["payload_json"])
                canonical_identity = self.fetch_canonical_identity(row["canonical_event_id"])
                conversation_key = (
                    payload.get("thread_key")
                    or payload.get("conversation_key")
                    or canonical_identity.get("conversation_key")
                )
                conversation_display = (
                    payload.get("conversation_display")
                    or canonical_identity.get("conversation_display")
                )
                sender_key = payload.get("sender_key") or canonical_identity.get("sender_key")
                sender_display = payload.get("sender_display") or canonical_identity.get("sender_display")
                message_text = payload.get("message_text")
                route = payload.get("route") or row["route"]
                best_source_type = (
                    payload.get("best_source_type")
                    or canonical_identity.get("best_source_type")
                    or row["best_source_type"]
                )
                status = payload.get("status") or canonical_identity.get("status") or row["status"]
                expected_rule_hints = build_rule_hints(sender_display, message_text)
                expected_suggested_actions = suggested_actions_for(route, expected_rule_hints)
                expected_response_guidance = response_guidance_for(expected_rule_hints)
                expected_priority = payload.get("priority") or row["priority"]
                expected_routing = self.routing_fields_for(route, expected_priority)
                derived = packet_assessment_fields(
                    conversation_key=conversation_key,
                    conversation_display=conversation_display,
                    sender_key=sender_key,
                    sender_display=sender_display,
                    best_source_type=best_source_type,
                    status=status,
                    rule_hints=expected_rule_hints,
                )
                updated_payload = {
                    **payload,
                    "conversation_display": conversation_display,
                    "sender_display": sender_display,
                    "packet_revision": expected_revision,
                    "supersedes_packet_id": expected_supersedes,
                    "superseded_by_packet_id": expected_superseded_by,
                    "transition_reason": expected_transition,
                    "rule_hints": expected_rule_hints,
                    "suggested_actions": expected_suggested_actions,
                    "response_guidance": expected_response_guidance,
                    **expected_routing,
                    **derived,
                }
                if (
                    row["packet_revision"] != expected_revision
                    or row["supersedes_packet_id"] != expected_supersedes
                    or row["superseded_by_packet_id"] != expected_superseded_by
                    or row["transition_reason"] != expected_transition
                    or payload.get("rule_hints") != expected_rule_hints
                    or payload.get("suggested_actions") != expected_suggested_actions
                    or payload.get("response_guidance") != expected_response_guidance
                    or any(payload.get(key) != value for key, value in expected_routing.items())
                    or any(payload.get(key) != value for key, value in derived.items())
                ):
                    self.conn.execute(
                        """
                        UPDATE emitted_packets
                        SET packet_revision = ?,
                            supersedes_packet_id = ?,
                            superseded_by_packet_id = ?,
                            transition_reason = ?,
                            payload_json = ?,
                            thread_key = ?,
                            actor_key = ?,
                            sender_key = ?,
                            sender_display_name = ?,
                            is_group = ?,
                            group_name = ?,
                            source_confidence = ?,
                            primary_rule_id = ?,
                            primary_rule_label = ?,
                            primary_rule_confidence = ?,
                            violation_guess = ?,
                            violation_confidence = ?,
                            full_name_signal = ?,
                            solicitation_signal = ?,
                            respect_signal = ?,
                            overall_assessment = ?,
                            overall_assessment_score = ?,
                            identity_quality = ?,
                            dispatch_target = ?,
                            dispatch_backup_target = ?,
                            dispatch_period = ?,
                            dispatch_mode = ?,
                            delivery_status = CASE
                                WHEN delivery_status IN ('accepted_by_adapter', 'delivered_confirmed') THEN delivery_status
                                WHEN delivery_status = 'dispatching' AND COALESCE(last_delivery_attempt_at, '') >= ? THEN delivery_status
                                WHEN COALESCE(presented_at, '') != '' THEN delivery_status
                                WHEN delivery_status = 'delivery_failed' AND COALESCE(delivery_attempt_count, 0) > 0 THEN delivery_status
                                ELSE ?
                            END,
                            delivery_attempt_count = COALESCE(delivery_attempt_count, ?),
                            last_delivery_attempt_at = COALESCE(last_delivery_attempt_at, ?),
                            last_delivery_error = COALESCE(last_delivery_error, ?),
                            delivered_at = COALESCE(delivered_at, ?),
                            presented_at = COALESCE(presented_at, ?),
                            ack_required = ?,
                            ack_timeout_seconds = ?,
                            ack_due_at = CASE
                                WHEN presented_at IS NOT NULL THEN ack_due_at
                                ELSE NULL
                            END,
                            escalate_after_seconds = ?,
                            escalate_due_at = CASE
                                WHEN presented_at IS NOT NULL THEN escalate_due_at
                                ELSE NULL
                            END,
                            escalation_target = ?,
                            acknowledged_at = COALESCE(acknowledged_at, ?),
                            escalated_at = COALESCE(escalated_at, ?),
                            human_review_actor = COALESCE(human_review_actor, ?),
                            human_review_note = COALESCE(human_review_note, ?),
                            human_review_updated_at = COALESCE(human_review_updated_at, ?),
                            human_review_status = COALESCE(human_review_status, ?),
                            human_final_disposition = COALESCE(human_final_disposition, ?),
                            external_person_key = COALESCE(external_person_key, ?)
                        WHERE rowid = ?
                        """,
                        (
                            expected_revision,
                            expected_supersedes,
                            expected_superseded_by,
                            expected_transition,
                            json.dumps(updated_payload, ensure_ascii=False),
                            derived["thread_key"],
                            derived["actor_key"],
                            derived["sender_key"],
                            derived["sender_display_name"],
                            1 if derived["is_group"] else 0,
                            derived["group_name"],
                            derived["source_confidence"],
                            derived["primary_rule_id"],
                            derived["primary_rule_label"],
                            derived["primary_rule_confidence"],
                            derived["violation_guess"],
                            derived["violation_confidence"],
                            derived["full_name_signal"],
                            derived["solicitation_signal"],
                            derived["respect_signal"],
                            derived["overall_assessment"],
                            derived["overall_assessment_score"],
                            derived["identity_quality"],
                            expected_routing["dispatch_target"],
                            expected_routing["dispatch_backup_target"],
                            expected_routing["dispatch_period"],
                            expected_routing["dispatch_mode"],
                            lease_cutoff,
                            expected_routing["delivery_status"],
                            expected_routing["delivery_attempt_count"],
                            expected_routing["last_delivery_attempt_at"],
                            expected_routing["last_delivery_error"],
                            expected_routing["delivered_at"],
                            expected_routing["presented_at"],
                            1 if expected_routing["ack_required"] else 0,
                            expected_routing["ack_timeout_seconds"],
                            expected_routing["escalate_after_seconds"],
                            expected_routing["escalation_target"],
                            expected_routing["acknowledged_at"],
                            expected_routing["escalated_at"],
                            expected_routing["human_review_actor"],
                            expected_routing["human_review_note"],
                            expected_routing["human_review_updated_at"],
                            derived["human_review_status"],
                            derived["human_final_disposition"],
                            derived["external_person_key"],
                            row["rowid"],
                        ),
                    )
                    changed = True

        for row in rows:
            canonical_event_id = row["canonical_event_id"]
            if current_canonical is None:
                current_canonical = canonical_event_id
            if canonical_event_id != current_canonical:
                flush_group(current_group)
                current_group = []
                current_canonical = canonical_event_id
            current_group.append(row)

        flush_group(current_group)
        if changed:
            self.conn.commit()

    def _ensure_packet_event_history(self) -> None:
        rows = self.conn.execute(
            """
            SELECT packet_id, canonical_event_id, packet_kind, route, priority,
                   status, best_source_type, packet_revision, supersedes_packet_id,
                   transition_reason, emitted_at
            FROM emitted_packets
            ORDER BY emitted_at ASC, rowid ASC
            """
        ).fetchall()
        if not rows:
            return

        changed = False
        for row in rows:
            exists = self.conn.execute(
                """
                SELECT 1
                FROM packet_events
                WHERE packet_id = ?
                  AND event_type = 'packet_emitted'
                LIMIT 1
                """,
                (row["packet_id"],),
            ).fetchone()
            if exists is not None:
                continue
            self.append_packet_event(
                packet_id=row["packet_id"],
                canonical_event_id=row["canonical_event_id"],
                event_type="packet_emitted",
                source="packet_emitter_backfill",
                payload={
                    "packet_kind": row["packet_kind"],
                    "route": row["route"],
                    "priority": row["priority"],
                    "status": row["status"],
                    "best_source_type": row["best_source_type"],
                    "packet_revision": row["packet_revision"],
                    "supersedes_packet_id": row["supersedes_packet_id"],
                    "transition_reason": row["transition_reason"],
                },
                observed_at=row["emitted_at"],
                commit=False,
            )
            changed = True

        if changed:
            self.conn.commit()

    def write_heartbeat(self, details: dict[str, Any]) -> None:
        now = utc_now()
        self.conn.execute(
            """
            INSERT INTO heartbeats (source, observed_at, details_json)
            VALUES ('operator_packets', ?, ?)
            ON CONFLICT(source) DO UPDATE SET
                observed_at = excluded.observed_at,
                details_json = excluded.details_json
            """,
            (now, json.dumps(details, ensure_ascii=False, sort_keys=True)),
        )
        self.conn.commit()
        atomic_write_json(
            self.status_path,
            {
                "observed_at": now,
                "details": details,
            },
        )

    def packet_exists(self, packet_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM emitted_packets WHERE packet_id = ?",
            (packet_id,),
        ).fetchone()
        return row is not None

    def allows_auto_dispatch(self, emitted_at: str | None) -> bool:
        if self.dispatch_not_before is None:
            return True
        candidate = iso_for_compare(emitted_at)
        if candidate is None:
            return False
        return candidate >= self.dispatch_not_before

    def fetch_dispatchable_packets(self) -> list[dict[str, Any]]:
        query = """
            SELECT packet_id, payload_json, dispatch_target, dispatch_mode, delivery_status, emitted_at
            FROM current_packets
            WHERE dispatch_mode IN ('local_imessage', 'local_command', 'remote_webhook')
              AND delivery_status IN ('queued_local_only', 'blocked_unwired_target', 'dispatch_pending', 'delivery_failed')
              AND COALESCE(acknowledged_at, '') = ''
        """
        params: tuple[Any, ...] = ()
        if self.dispatch_not_before is not None:
            query += " AND COALESCE(emitted_at, '') >= ?"
            params = (self.dispatch_not_before,)
        query += """
            ORDER BY
                CASE delivery_status
                    WHEN 'delivery_failed' THEN 0
                    WHEN 'dispatch_pending' THEN 1
                    WHEN 'blocked_unwired_target' THEN 2
                    ELSE 3
                END,
                emitted_at ASC
            """
        rows = self.conn.execute(query, params).fetchall()
        packets: list[dict[str, Any]] = []
        for row in rows:
            payload = safe_json_object(row["payload_json"])
            payload["packet_id"] = row["packet_id"]
            payload["dispatch_target"] = row["dispatch_target"]
            payload["dispatch_mode"] = row["dispatch_mode"]
            payload["delivery_status"] = row["delivery_status"]
            payload["emitted_at"] = row["emitted_at"]
            packets.append(payload)
        return packets

    def dispatch_existing_packets(self) -> int:
        dispatched = 0
        for packet in self.fetch_dispatchable_packets():
            if self.dispatch_packet(packet):
                dispatched += 1
        return dispatched

    def fetch_current_packet_by_id(self, packet_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            """
            SELECT payload_json, packet_revision, supersedes_packet_id,
                   superseded_by_packet_id, transition_reason,
                   thread_key, actor_key, sender_key, sender_display_name,
                   is_group, group_name, source_confidence,
                   primary_rule_id, primary_rule_label, primary_rule_confidence,
                   violation_guess, violation_confidence,
                   full_name_signal, solicitation_signal, respect_signal,
                   overall_assessment, overall_assessment_score, identity_quality,
                   dispatch_target, dispatch_backup_target, dispatch_period,
                   dispatch_mode, delivery_status, delivery_attempt_count,
                   last_delivery_attempt_at, last_delivery_error, delivered_at, presented_at,
                   ack_required, ack_timeout_seconds, ack_due_at,
                   escalate_after_seconds, escalate_due_at, escalation_target,
                   acknowledged_at, escalated_at, human_review_actor,
                   human_review_note, human_review_updated_at,
                   human_review_status, human_final_disposition,
                   external_person_key, emitted_at
            FROM current_packets
            WHERE packet_id = ?
            LIMIT 1
            """,
            (packet_id,),
        ).fetchone()
        if row is None:
            return None
        payload = safe_json_object(row["payload_json"])
        payload["packet_id"] = packet_id
        payload["packet_revision"] = row["packet_revision"]
        payload["supersedes_packet_id"] = row["supersedes_packet_id"]
        payload["superseded_by_packet_id"] = row["superseded_by_packet_id"]
        payload["transition_reason"] = row["transition_reason"]
        for key in [
            "thread_key",
            "actor_key",
            "sender_key",
            "sender_display_name",
            "group_name",
            "source_confidence",
            "primary_rule_id",
            "primary_rule_label",
            "primary_rule_confidence",
            "violation_guess",
            "violation_confidence",
            "full_name_signal",
            "solicitation_signal",
            "respect_signal",
            "overall_assessment",
            "overall_assessment_score",
            "identity_quality",
            "dispatch_target",
            "dispatch_backup_target",
            "dispatch_period",
            "dispatch_mode",
            "delivery_status",
            "delivery_attempt_count",
            "last_delivery_attempt_at",
            "last_delivery_error",
            "delivered_at",
            "presented_at",
            "ack_timeout_seconds",
            "ack_due_at",
            "escalate_after_seconds",
            "escalate_due_at",
            "escalation_target",
            "acknowledged_at",
            "escalated_at",
            "human_review_actor",
            "human_review_note",
            "human_review_updated_at",
            "human_review_status",
            "human_final_disposition",
            "external_person_key",
            "emitted_at",
        ]:
            payload[key] = row[key]
        payload["is_group"] = bool(row["is_group"])
        payload["ack_required"] = bool(row["ack_required"])
        return payload

    def dispatch_packet_by_id(self, packet_id: str, *, force: bool = False) -> dict[str, Any]:
        packet = self.fetch_current_packet_by_id(packet_id)
        if packet is None:
            raise ValueError(f"packet_id not found in current_packets: {packet_id}")
        if not force and not self.allows_auto_dispatch(packet.get("emitted_at")):
            raise ValueError(
                f"packet {packet_id} is suppressed by dispatch_not_before={self.dispatch_not_before}; use --dispatch-force to bypass"
            )
        dispatched = self.dispatch_packet(packet)
        latest = self.fetch_current_packet_by_id(packet_id) or packet
        return {
            "packet_id": packet_id,
            "dispatched": dispatched,
            "forced": force,
            "dispatch_mode": latest.get("dispatch_mode"),
            "dispatch_target": latest.get("dispatch_target"),
            "delivery_status": latest.get("delivery_status"),
        }

    def write_latest_snapshot(self) -> dict[str, Any]:
        rows = self.conn.execute(
            """
            SELECT payload_json, packet_revision, supersedes_packet_id,
                   superseded_by_packet_id, transition_reason,
                   thread_key, actor_key, sender_key, sender_display_name,
                   is_group, group_name, source_confidence,
                   primary_rule_id, primary_rule_label, primary_rule_confidence,
                   violation_guess, violation_confidence,
                   full_name_signal, solicitation_signal, respect_signal,
                   overall_assessment, overall_assessment_score, identity_quality,
                   dispatch_target, dispatch_backup_target, dispatch_period,
                   dispatch_mode, delivery_status, delivery_attempt_count,
                   last_delivery_attempt_at, last_delivery_error, delivered_at, presented_at,
                   ack_required, ack_timeout_seconds, ack_due_at,
                   escalate_after_seconds, escalate_due_at, escalation_target,
                   acknowledged_at, escalated_at, human_review_actor,
                   human_review_note, human_review_updated_at,
                   human_review_status, human_final_disposition,
                   external_person_key
            FROM current_packets
            ORDER BY emitted_at DESC
            """
        ).fetchall()
        packets = []
        for row in rows:
            payload = safe_json_object(row["payload_json"])
            payload["packet_revision"] = row["packet_revision"]
            payload["supersedes_packet_id"] = row["supersedes_packet_id"]
            payload["superseded_by_packet_id"] = row["superseded_by_packet_id"]
            payload["transition_reason"] = row["transition_reason"]
            for key in [
                "thread_key",
                "actor_key",
                "sender_key",
                "sender_display_name",
                "group_name",
                "source_confidence",
                "primary_rule_id",
                "primary_rule_label",
                "primary_rule_confidence",
                "violation_guess",
                "violation_confidence",
                "full_name_signal",
                "solicitation_signal",
                "respect_signal",
                "overall_assessment",
                "overall_assessment_score",
                "identity_quality",
                "dispatch_target",
                "dispatch_backup_target",
                "dispatch_period",
                "dispatch_mode",
                "delivery_status",
                "delivery_attempt_count",
                "last_delivery_attempt_at",
                "last_delivery_error",
                "delivered_at",
                "presented_at",
                "ack_timeout_seconds",
                "ack_due_at",
                "escalate_after_seconds",
                "escalate_due_at",
                "escalation_target",
                "acknowledged_at",
                "escalated_at",
                "human_review_actor",
                "human_review_note",
                "human_review_updated_at",
                "human_review_status",
                "human_final_disposition",
                "external_person_key",
            ]:
                payload[key] = row[key]
            payload["is_group"] = bool(row["is_group"])
            payload["ack_required"] = bool(row["ack_required"])
            packets.append(payload)
        snapshot = {
            "generated_at": utc_now(),
            "packet_count": len(packets),
            "packets": packets,
        }
        if self.latest_snapshot_path:
            atomic_write_json(self.latest_snapshot_path, snapshot)
        return snapshot

    def fetch_candidate_rows(self) -> list[sqlite3.Row]:
        merge_conn = sqlite3.connect(self.merge_db, timeout=30.0)
        merge_conn.row_factory = sqlite3.Row
        try:
            return merge_conn.execute(
                """
                SELECT *
                FROM canonical_events
                WHERE message_text IS NOT NULL
                ORDER BY updated_at ASC, canonical_event_id ASC
                """
            ).fetchall()
        finally:
            merge_conn.close()

    def latest_packet_for_canonical(self, canonical_event_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT *
            FROM emitted_packets
            WHERE canonical_event_id = ?
            ORDER BY packet_revision DESC, emitted_at DESC, rowid DESC
            LIMIT 1
            """,
            (canonical_event_id,),
        ).fetchone()

    def fetch_source_context(self, canonical_event_id: str) -> list[dict[str, Any]]:
        merge_conn = sqlite3.connect(self.merge_db, timeout=30.0)
        merge_conn.row_factory = sqlite3.Row
        try:
            rows = merge_conn.execute(
                """
                SELECT source_type, observed_at, source_emitted_at, source_message_id,
                       conversation_display, sender_display, match_status, confidence
                FROM source_events
                WHERE canonical_event_id = ?
                ORDER BY observed_at ASC, ingested_at ASC
                LIMIT 12
                """,
                (canonical_event_id,),
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            merge_conn.close()

    def fetch_canonical_identity(self, canonical_event_id: str) -> dict[str, Any]:
        merge_conn = sqlite3.connect(self.merge_db, timeout=30.0)
        merge_conn.row_factory = sqlite3.Row
        try:
            row = merge_conn.execute(
                """
                SELECT canonical_event_id, status, best_source_type, conversation_key,
                       conversation_display, sender_key, sender_display
                FROM canonical_events
                WHERE canonical_event_id = ?
                """,
                (canonical_event_id,),
            ).fetchone()
            return dict(row) if row is not None else {}
        finally:
            merge_conn.close()

    def build_packet(self, row: sqlite3.Row) -> dict[str, Any]:
        evidence_sources = safe_json_list(row["evidence_sources_json"])
        route = route_for(row)
        priority = priority_for(row)
        packet_kind = packet_kind_for(row)
        rule_hints = build_rule_hints(row["sender_display"], row["message_text"])
        suggested_actions = suggested_actions_for(route, rule_hints)
        routing = self.routing_fields_for(route, priority)
        derived = packet_assessment_fields(
            conversation_key=row["conversation_key"],
            conversation_display=row["conversation_display"],
            sender_key=row["sender_key"],
            sender_display=row["sender_display"],
            best_source_type=row["best_source_type"],
            status=row["status"],
            rule_hints=rule_hints,
        )
        return {
            "packet_id": packet_id_for(row),
            "packet_kind": packet_kind,
            "route": route,
            "priority": priority,
            "operator_summary": operator_summary_for(row, route),
            "canonical_event_id": row["canonical_event_id"],
            "status": row["status"],
            "best_source_type": row["best_source_type"],
            "merged_confidence": row["merged_confidence"],
            "conversation_display": row["conversation_display"],
            "sender_display": row["sender_display"],
            "message_text": row["message_text"],
            "source_count": row["source_count"],
            "evidence_count": row["evidence_count"],
            "evidence_sources": evidence_sources,
            "rule_hints": rule_hints,
            "suggested_actions": suggested_actions,
            "response_guidance": response_guidance_for(rule_hints),
            "first_observed_at": row["first_observed_at"],
            "last_observed_at": row["last_observed_at"],
            "canonical_updated_at": row["updated_at"],
            "source_context": self.fetch_source_context(row["canonical_event_id"]),
            **routing,
            **derived,
        }

    @staticmethod
    def transition_reason(previous_packet: sqlite3.Row | None, packet: dict[str, Any]) -> str | None:
        if previous_packet is None:
            return None
        if previous_packet["status"] != packet["status"]:
            return "status_upgrade"
        if previous_packet["route"] != packet["route"]:
            return "route_change"
        if previous_packet["priority"] != packet["priority"]:
            return "priority_change"
        if previous_packet["packet_kind"] != packet["packet_kind"]:
            return "kind_change"
        if previous_packet["canonical_updated_at"] != packet["canonical_updated_at"]:
            return "state_refresh"
        return None

    def should_emit(self, row: sqlite3.Row) -> bool:
        if row["status"] == "confirmed":
            return True
        if row["best_source_type"] in RICH_SOURCE_TYPES:
            return True
        return self.include_notification_only

    def emit_packet(self, packet: dict[str, Any]) -> None:
        previous_packet = self.latest_packet_for_canonical(packet["canonical_event_id"])
        packet_revision = 1
        supersedes_packet_id = None
        transition_reason = None
        if previous_packet is not None and previous_packet["packet_id"] != packet["packet_id"]:
            packet_revision = int(previous_packet["packet_revision"] or 1) + 1
            supersedes_packet_id = previous_packet["packet_id"]
            transition_reason = self.transition_reason(previous_packet, packet)
        packet["packet_revision"] = packet_revision
        packet["supersedes_packet_id"] = supersedes_packet_id
        packet["transition_reason"] = transition_reason
        emitted_at = utc_now()
        packet["emitted_at"] = emitted_at

        insert_items = [
            ("packet_id", packet["packet_id"]),
            ("canonical_event_id", packet["canonical_event_id"]),
            ("packet_kind", packet["packet_kind"]),
            ("route", packet["route"]),
            ("priority", packet["priority"]),
            ("thread_key", packet["thread_key"]),
            ("actor_key", packet["actor_key"]),
            ("sender_key", packet["sender_key"]),
            ("sender_display_name", packet["sender_display_name"]),
            ("is_group", 1 if packet["is_group"] else 0),
            ("group_name", packet["group_name"]),
            ("source_confidence", packet["source_confidence"]),
            ("primary_rule_id", packet["primary_rule_id"]),
            ("primary_rule_label", packet["primary_rule_label"]),
            ("primary_rule_confidence", packet["primary_rule_confidence"]),
            ("violation_guess", packet["violation_guess"]),
            ("violation_confidence", packet["violation_confidence"]),
            ("full_name_signal", packet["full_name_signal"]),
            ("solicitation_signal", packet["solicitation_signal"]),
            ("respect_signal", packet["respect_signal"]),
            ("overall_assessment", packet["overall_assessment"]),
            ("overall_assessment_score", packet["overall_assessment_score"]),
            ("identity_quality", packet["identity_quality"]),
            ("dispatch_target", packet["dispatch_target"]),
            ("dispatch_backup_target", packet["dispatch_backup_target"]),
            ("dispatch_period", packet["dispatch_period"]),
            ("dispatch_mode", packet["dispatch_mode"]),
            ("delivery_status", packet["delivery_status"]),
            ("delivery_attempt_count", packet["delivery_attempt_count"]),
            ("last_delivery_attempt_at", packet["last_delivery_attempt_at"]),
            ("last_delivery_error", packet["last_delivery_error"]),
            ("delivered_at", packet["delivered_at"]),
            ("presented_at", packet["presented_at"]),
            ("ack_required", 1 if packet["ack_required"] else 0),
            ("ack_timeout_seconds", packet["ack_timeout_seconds"]),
            ("ack_due_at", packet["ack_due_at"]),
            ("escalate_after_seconds", packet["escalate_after_seconds"]),
            ("escalate_due_at", packet["escalate_due_at"]),
            ("escalation_target", packet["escalation_target"]),
            ("acknowledged_at", packet["acknowledged_at"]),
            ("escalated_at", packet["escalated_at"]),
            ("human_review_actor", packet["human_review_actor"]),
            ("human_review_note", packet["human_review_note"]),
            ("human_review_updated_at", packet["human_review_updated_at"]),
            ("human_review_status", packet["human_review_status"]),
            ("human_final_disposition", packet["human_final_disposition"]),
            ("external_person_key", packet["external_person_key"]),
            ("packet_revision", packet["packet_revision"]),
            ("supersedes_packet_id", packet["supersedes_packet_id"]),
            ("superseded_by_packet_id", None),
            ("transition_reason", packet["transition_reason"]),
            ("emitted_at", emitted_at),
            ("canonical_updated_at", packet["canonical_updated_at"]),
            ("last_observed_at", packet["last_observed_at"]),
            ("status", packet["status"]),
            ("best_source_type", packet["best_source_type"]),
            ("payload_json", json.dumps(packet, ensure_ascii=False)),
        ]
        columns_sql = ",\n                ".join(name for name, _ in insert_items)
        placeholders_sql = ", ".join("?" for _ in insert_items)
        self.conn.execute(
            f"""
            INSERT INTO emitted_packets (
                {columns_sql}
            ) VALUES ({placeholders_sql})
            """,
            tuple(value for _, value in insert_items),
        )
        if supersedes_packet_id:
            self.conn.execute(
                """
                UPDATE emitted_packets
                SET superseded_by_packet_id = ?
                WHERE packet_id = ?
                """,
                (packet["packet_id"], supersedes_packet_id),
            )
        self.append_packet_event(
            packet_id=packet["packet_id"],
            canonical_event_id=packet["canonical_event_id"],
            event_type="packet_emitted",
            source="packet_emitter",
            payload={
                "packet_kind": packet["packet_kind"],
                "route": packet["route"],
                "priority": packet["priority"],
                "status": packet["status"],
                "best_source_type": packet["best_source_type"],
                "packet_revision": packet["packet_revision"],
                "supersedes_packet_id": packet["supersedes_packet_id"],
                "transition_reason": packet["transition_reason"],
            },
            commit=False,
        )
        self.conn.commit()
        with self.output_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(packet, ensure_ascii=False) + "\n")
        if self.allows_auto_dispatch(emitted_at):
            self.dispatch_packet(packet)

    def dispatch_packet(self, packet: dict[str, Any]) -> bool:
        mode = packet.get("dispatch_mode")
        packet_id = str(packet.get("packet_id") or "")
        if mode not in {"local_imessage", "local_command", "remote_webhook"}:
            return False
        try:
            delivery_metadata: dict[str, Any] = {}
            if mode == "local_imessage":
                delivery_metadata = self._send_imessage(packet)
            elif mode == "local_command":
                self._run_command(packet)
            elif mode == "remote_webhook":
                self._post_webhook(packet)
            self.record_dispatch_result(packet_id, accepted=True, metadata=delivery_metadata)
            if mode == "local_imessage" and self.pending_replies_path is not None:
                try:
                    pending_entry = self.register_pending_reply(
                        packet,
                        sent_at=utc_now(),
                    )
                    self.append_packet_event(
                        packet_id=packet_id,
                        canonical_event_id=packet.get("canonical_event_id"),
                        event_type="pending_reply_registered",
                        source="pending_replies",
                        payload={
                            "path": str(self.pending_replies_path),
                            "entry_id": (pending_entry or {}).get("id"),
                        },
                    )
                except Exception as exc:
                    self.append_packet_event(
                        packet_id=packet_id,
                        canonical_event_id=packet.get("canonical_event_id"),
                        event_type="pending_reply_registration_failed",
                        source="pending_replies",
                        payload={
                            "path": str(self.pending_replies_path),
                            "error": str(exc),
                        },
                    )
                    print(f"[operator_packets] pending reply tracking failed for {packet_id}: {exc}")
            return True
        except Exception as exc:
            self.record_dispatch_result(packet_id, accepted=False, error=str(exc))
            print(f"[operator_packets] dispatch failed for {packet_id}: {exc}")
            return False

    def record_dispatch_result(
        self,
        packet_id: str,
        *,
        accepted: bool,
        error: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        now = utc_now()
        row = self.conn.execute(
            """
            SELECT canonical_event_id, dispatch_mode, dispatch_target,
                   delivery_attempt_count, payload_json, ack_required,
                   ack_timeout_seconds, escalate_after_seconds
            FROM emitted_packets
            WHERE packet_id = ?
            """,
            (packet_id,),
        ).fetchone()
        if row is None:
            return
        attempt_count = int(row["delivery_attempt_count"] or 0) + 1
        payload = safe_json_object(row["payload_json"])
        payload["delivery_status"] = "accepted_by_adapter" if accepted else "delivery_failed"
        payload["delivery_attempt_count"] = attempt_count
        payload["last_delivery_attempt_at"] = now
        payload["last_delivery_error"] = None if accepted else error
        if metadata:
            payload.update(metadata)
        if accepted:
            payload["presented_at"] = now
            if row["ack_required"]:
                payload["ack_due_at"] = future_iso(int(row["ack_timeout_seconds"] or 0)) if row["ack_timeout_seconds"] else None
                payload["escalate_due_at"] = future_iso(int(row["escalate_after_seconds"] or 0)) if row["escalate_after_seconds"] else None
        self.conn.execute(
            """
            UPDATE emitted_packets
            SET delivery_status = ?,
                delivery_attempt_count = ?,
                last_delivery_attempt_at = ?,
                last_delivery_error = ?,
                delivered_at = CASE
                    WHEN ? IS NOT NULL THEN ?
                    ELSE delivered_at
                END,
                presented_at = CASE
                    WHEN ? IS NOT NULL THEN ?
                    ELSE presented_at
                END,
                ack_due_at = CASE
                    WHEN ? IS NOT NULL THEN ?
                    ELSE ack_due_at
                END,
                escalate_due_at = CASE
                    WHEN ? IS NOT NULL THEN ?
                    ELSE escalate_due_at
                END,
                payload_json = ?
            WHERE packet_id = ?
            """,
            (
                payload["delivery_status"],
                attempt_count,
                now,
                None if accepted else error,
                payload.get("delivered_at"),
                payload.get("delivered_at"),
                payload.get("presented_at"),
                payload.get("presented_at"),
                payload.get("ack_due_at"),
                payload.get("ack_due_at"),
                payload.get("escalate_due_at"),
                payload.get("escalate_due_at"),
                json.dumps(payload, ensure_ascii=False),
                packet_id,
            ),
        )
        self.append_packet_event(
            packet_id=packet_id,
            canonical_event_id=row["canonical_event_id"],
            event_type="dispatch_accepted" if accepted else "dispatch_failed",
            source=row["dispatch_mode"] or "relay",
            note=error,
            payload={
                "dispatch_mode": row["dispatch_mode"],
                "dispatch_target": row["dispatch_target"],
                "delivery_status": payload["delivery_status"],
                "delivery_attempt_count": attempt_count,
                "last_delivery_attempt_at": now,
                "error": error,
                **(metadata or {}),
            },
            commit=False,
        )
        self.conn.commit()

    def _post_webhook(self, packet: dict[str, Any]) -> None:
        assert self.webhook_url is not None
        body = json.dumps({"packet": packet}, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.webhook_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=10) as response:
            response.read()

    def _run_command(self, packet: dict[str, Any]) -> None:
        assert self.command is not None
        argv = shlex.split(self.command)
        if not argv:
            raise ValueError("packet command resolved to an empty argv")
        subprocess.run(
            argv,
            input=json.dumps({"packet": packet}, ensure_ascii=False),
            text=True,
            check=True,
            env=os.environ.copy(),
        )

    def apply_operator_update(
        self,
        *,
        packet_id: str,
        acknowledged: bool = False,
        review_status: str | None = None,
        final_disposition: str | None = None,
        review_actor: str | None = None,
        review_note: str | None = None,
        action_type: str | None = None,
        action_source: str | None = None,
        commit: bool = True,
    ) -> dict[str, Any]:
        row = self.conn.execute(
            """
            SELECT *
            FROM emitted_packets
            WHERE packet_id = ?
            """,
            (packet_id,),
        ).fetchone()
        if row is None:
            raise ValueError(f"unknown packet_id: {packet_id}")

        now = utc_now()
        payload = safe_json_object(row["payload_json"])
        next_review_status = normalize_text(review_status) or row["human_review_status"]
        next_final_disposition = normalize_text(final_disposition) or row["human_final_disposition"]
        next_review_actor = normalize_text(review_actor) or row["human_review_actor"]
        next_review_note = normalize_text(review_note) or row["human_review_note"]
        next_acknowledged_at = row["acknowledged_at"]

        if acknowledged and not next_acknowledged_at:
            next_acknowledged_at = now
            if not next_review_status:
                next_review_status = "acknowledged"

        payload["human_review_status"] = next_review_status
        payload["human_final_disposition"] = next_final_disposition
        payload["human_review_actor"] = next_review_actor
        payload["human_review_note"] = next_review_note
        payload["human_review_updated_at"] = now
        payload["acknowledged_at"] = next_acknowledged_at

        self.conn.execute(
            """
            UPDATE emitted_packets
            SET human_review_status = ?,
                human_final_disposition = ?,
                human_review_actor = ?,
                human_review_note = ?,
                human_review_updated_at = ?,
                acknowledged_at = ?,
                payload_json = ?
            WHERE packet_id = ?
            """,
            (
                next_review_status,
                next_final_disposition,
                next_review_actor,
                next_review_note,
                now,
                next_acknowledged_at,
                json.dumps(payload, ensure_ascii=False),
                packet_id,
            ),
        )
        self.append_packet_event(
            packet_id=packet_id,
            canonical_event_id=row["canonical_event_id"],
            event_type="operator_action",
            action_type=action_type or next_review_status,
            source=action_source or "manual_update",
            actor=next_review_actor,
            note=next_review_note,
            payload={
                "acknowledged": acknowledged,
                "human_review_status": next_review_status,
                "human_final_disposition": next_final_disposition,
                "human_review_actor": next_review_actor,
                "human_review_note": next_review_note,
                "human_review_updated_at": now,
                "acknowledged_at": next_acknowledged_at,
            },
            commit=False,
        )
        if commit:
            self.conn.commit()
            self.write_latest_snapshot()
        return {
            "packet_id": packet_id,
            "human_review_status": next_review_status,
            "human_final_disposition": next_final_disposition,
            "human_review_actor": next_review_actor,
            "human_review_note": next_review_note,
            "human_review_updated_at": now,
            "acknowledged_at": next_acknowledged_at,
        }

    def apply_operator_action(
        self,
        *,
        packet_id: str,
        action_type: str,
        actor: str | None = None,
        source: str | None = None,
        note: str | None = None,
        commit: bool = True,
    ) -> dict[str, Any]:
        action = (normalize_text(action_type) or "").casefold()
        if not action:
            raise ValueError("action_type is required")

        if action == "ack":
            acknowledged = True
            review_status = "acknowledged"
            final_disposition = None
        elif action == "done":
            acknowledged = True
            review_status = "done"
            final_disposition = "handled"
        elif action == "esc":
            acknowledged = True
            review_status = "escalated"
            final_disposition = "escalate"
        elif action == "nack":
            acknowledged = False
            review_status = "nack"
            final_disposition = "cannot_handle"
        else:
            acknowledged = False
            review_status = action
            final_disposition = None

        result = self.apply_operator_update(
            packet_id=packet_id,
            acknowledged=acknowledged,
            review_status=review_status,
            final_disposition=final_disposition,
            review_actor=actor,
            review_note=note,
            action_type=action.upper(),
            action_source=source or "generic_operator_action",
            commit=commit,
        )
        result["action_type"] = action.upper()
        result["action_source"] = source or "generic_operator_action"
        return result

    def apply_operator_reply(
        self,
        *,
        reply_text: str,
        review_actor: str | None = None,
    ) -> dict[str, Any]:
        parsed = parse_operator_reply(reply_text)
        if parsed is None:
            raise ValueError("reply text did not match ACK/DONE/ESC/NACK token format")

        token = parsed["token"]
        rows = self.conn.execute(
            """
            SELECT packet_id
            FROM current_packets
            WHERE UPPER(SUBSTR(packet_id, 1, 8)) = ?
            """,
            (token,),
        ).fetchall()
        if not rows:
            raise ValueError(f"no open packet matched token {token}")
        if len(rows) > 1:
            raise ValueError(f"operator token {token} matched multiple open packets")

        action = parsed["action"]
        note = parsed["note"] or reply_text
        return self.apply_operator_action(
            packet_id=rows[0]["packet_id"],
            action_type=action,
            actor=review_actor,
            source="reply_text_token",
            note=note,
        )

    def load_connector_cursor(self, source_key: str) -> str | None:
        row = self.conn.execute(
            "SELECT cursor_value FROM connector_cursors WHERE source_key = ?",
            (source_key,),
        ).fetchone()
        return row["cursor_value"] if row is not None else None

    def save_connector_cursor(
        self,
        *,
        source_key: str,
        cursor_value: str,
        details: dict[str, Any] | None = None,
        commit: bool = True,
    ) -> None:
        now = utc_now()
        self.conn.execute(
            """
            INSERT INTO connector_cursors (source_key, cursor_value, observed_at, details_json)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(source_key) DO UPDATE SET
                cursor_value = excluded.cursor_value,
                observed_at = excluded.observed_at,
                details_json = excluded.details_json
            """,
            (
                source_key,
                cursor_value,
                now,
                json.dumps(details or {}, ensure_ascii=False, sort_keys=True),
            ),
        )
        if commit:
            self.conn.commit()

    def list_imessage_chats(
        self,
        *,
        chat_db_path: Path,
        limit: int = 20,
        include_group_chats: bool = False,
    ) -> dict[str, Any]:
        msg_conn = open_imessage_db(chat_db_path)
        try:
            where_clause = "" if include_group_chats else "WHERE c.style = 45"
            rows = msg_conn.execute(
                f"""
                SELECT c.ROWID AS chat_rowid,
                       c.guid AS chat_guid,
                       c.style AS chat_style,
                       MAX(m.date) AS last_message_date,
                       COUNT(*) AS message_count,
                       SUM(CASE WHEN COALESCE(m.is_from_me, 0) = 0 THEN 1 ELSE 0 END) AS inbound_message_count
                FROM chat c
                JOIN chat_message_join cmj ON cmj.chat_id = c.ROWID
                JOIN message m ON m.ROWID = cmj.message_id
                {where_clause}
                GROUP BY c.ROWID
                ORDER BY MAX(m.date) DESC
                LIMIT ?
                """,
                (max(1, int(limit)),),
            ).fetchall()

            chats: list[dict[str, Any]] = []
            for row in rows:
                handle_rows = msg_conn.execute(
                    """
                    SELECT DISTINCT h.id AS handle_id
                    FROM chat_handle_join chj
                    LEFT JOIN handle h ON h.ROWID = chj.handle_id
                    WHERE chj.chat_id = ?
                    ORDER BY h.id ASC
                    """,
                    (row["chat_rowid"],),
                ).fetchall()
                handles = [
                    value
                    for value in (
                        normalize_operator_handle(handle_row["handle_id"])
                        for handle_row in handle_rows
                    )
                    if value
                ]
                latest_message = msg_conn.execute(
                    """
                    SELECT m.ROWID AS rowid,
                           m.guid,
                           m.text,
                           m.attributedBody,
                           m.date,
                           m.is_from_me,
                           m.service
                    FROM chat_message_join cmj
                    JOIN message m ON m.ROWID = cmj.message_id
                    WHERE cmj.chat_id = ?
                    ORDER BY m.date DESC, m.ROWID DESC
                    LIMIT 1
                    """,
                    (row["chat_rowid"],),
                ).fetchone()
                preview = truncate_line(
                    imessage_message_text(latest_message) if latest_message is not None else None,
                    140,
                )
                chats.append(
                    {
                        "chat_guid": row["chat_guid"],
                        "chat_style": "dm" if int(row["chat_style"] or 0) == 45 else "group",
                        "handles": handles,
                        "handle_count": len(handles),
                        "last_message_at": apple_ns_to_iso(row["last_message_date"]),
                        "last_message_preview": preview or None,
                        "last_message_is_from_me": bool(int((latest_message["is_from_me"] if latest_message is not None else 0) or 0)),
                        "last_message_service": normalize_text(latest_message["service"]) if latest_message is not None else None,
                        "message_count": int(row["message_count"] or 0),
                        "inbound_message_count": int(row["inbound_message_count"] or 0),
                    }
                )
        finally:
            msg_conn.close()

        return {
            "adapter": "imessage_chatdb",
            "path": str(chat_db_path),
            "include_group_chats": include_group_chats,
            "count": len(chats),
            "chats": chats,
        }

    def poll_imessage_actions(
        self,
        *,
        chat_db_path: Path,
        operator_handles: list[str],
        operator_chat_guid: str | None = None,
        source_key: str | None = None,
        prime_cursor: bool = False,
    ) -> dict[str, Any]:
        normalized_handles = sorted(
            {
                value for value in (
                    normalize_operator_handle(handle) for handle in operator_handles
                ) if value
            }
        )
        if not normalized_handles and not operator_chat_guid:
            raise ValueError("operator handle allowlist or operator chat guid is required")

        source_name = source_key or stable_hash(
            [
                "imessage_chatdb",
                str(chat_db_path),
                operator_chat_guid,
                ",".join(normalized_handles),
            ]
        )

        try:
            msg_conn = open_imessage_db(chat_db_path)
            max_row = msg_conn.execute("SELECT MAX(ROWID) AS max_rowid FROM message").fetchone()
        except RuntimeError:
            raise

        try:
            latest_rowid = int(max_row["max_rowid"] or 0)
            stored = self.load_connector_cursor(source_name)
            if stored is None:
                initial = latest_rowid if prime_cursor or latest_rowid else 0
                self.save_connector_cursor(
                    source_key=source_name,
                    cursor_value=str(initial),
                    details={
                        "adapter": "imessage_chatdb",
                        "chat_db_path": str(chat_db_path),
                        "primed": True,
                        "operator_chat_guid": operator_chat_guid,
                        "operator_handles": normalized_handles,
                    },
                    commit=True,
                )
                return {
                    "source_key": source_name,
                    "primed": True,
                    "cursor_rowid": initial,
                    "rows_seen": 0,
                    "rows_matched": 0,
                    "actions_applied": 0,
                    "rows_rejected": 0,
                    "rows_deferred": 0,
                    "deferred_retried": 0,
                    "deferred_resolved": 0,
                }

            watermark = int(stored)
            placeholders = ",".join("?" for _ in normalized_handles) if normalized_handles else ""
            where_parts = ["m.ROWID > ?"]
            params: list[Any] = [watermark]
            if operator_chat_guid:
                where_parts.append("c.guid = ?")
                params.append(operator_chat_guid)
            else:
                where_parts.append("c.style = 45")
            if normalized_handles:
                where_parts.append(f"LOWER(COALESCE(h.id, '')) IN ({placeholders})")
                params.extend(normalized_handles)
            query = f"""
                SELECT m.ROWID AS rowid,
                       m.guid,
                       m.text,
                       m.attributedBody,
                       m.date,
                       m.is_from_me,
                       m.service,
                       h.id AS handle_id,
                       c.guid AS chat_guid,
                       c.style AS chat_style
                FROM message m
                JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
                JOIN chat c ON c.ROWID = cmj.chat_id
                LEFT JOIN handle h ON h.ROWID = m.handle_id
                WHERE {" AND ".join(where_parts)}
                ORDER BY m.ROWID ASC
            """
            rows = msg_conn.execute(query, params).fetchall()
        finally:
            msg_conn.close()

        rows_seen = len(rows)
        rows_matched = 0
        actions_applied = 0
        rows_rejected = 0
        rows_deferred = 0
        duplicate_rows = 0
        newest_rowid = watermark
        changed = False
        deferred_retry = self.retry_deferred_operator_actions(source_key=source_name)
        if deferred_retry["resolved"]:
            changed = True

        for row in rows:
            newest_rowid = max(newest_rowid, int(row["rowid"]))
            raw_text = imessage_message_text(row)
            external_event_id = str(row["guid"] or f"rowid:{row['rowid']}")
            if self.connector_event_exists(source_name, external_event_id):
                duplicate_rows += 1
                continue
            if int(row["is_from_me"] or 0) != 0:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="ignored_from_me",
                    actor=normalize_operator_handle(row["handle_id"]),
                    raw_text=raw_text,
                    reason="message_is_from_me",
                    payload={"rowid": row["rowid"], "chat_guid": row["chat_guid"]},
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                continue
            actor = normalize_operator_handle(row["handle_id"])
            if normalized_handles and actor not in normalized_handles:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="rejected_unauthorized",
                    actor=actor or row["handle_id"],
                    raw_text=raw_text,
                    reason="sender_not_allowlisted",
                    payload={"rowid": row["rowid"], "chat_guid": row["chat_guid"]},
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                rows_rejected += 1
                continue
            if operator_chat_guid and row["chat_guid"] != operator_chat_guid:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="rejected_wrong_chat",
                    actor=actor or row["handle_id"],
                    raw_text=raw_text,
                    reason="chat_guid_mismatch",
                    payload={"rowid": row["rowid"], "chat_guid": row["chat_guid"]},
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                rows_rejected += 1
                continue
            parsed = parse_operator_reply(raw_text)
            if parsed is None:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="rejected_unparseable",
                    actor=actor or row["handle_id"],
                    raw_text=raw_text,
                    reason="token_grammar_mismatch",
                    payload={"rowid": row["rowid"], "chat_guid": row["chat_guid"]},
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                rows_rejected += 1
                continue
            rows_matched += 1
            token = parsed["token"]
            packet_rows = self.conn.execute(
                """
                SELECT packet_id
                FROM current_packets
                WHERE UPPER(SUBSTR(packet_id, 1, 8)) = ?
                """,
                (token,),
            ).fetchall()
            if len(packet_rows) == 0:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="deferred_packet_resolution",
                    actor=actor or row["handle_id"],
                    raw_text=raw_text,
                    reason="packet_not_yet_available",
                    payload={
                        "rowid": row["rowid"],
                        "chat_guid": row["chat_guid"],
                        "token": token,
                        "action_type": parsed["action"],
                        "note": parsed["note"] or raw_text,
                        "match_count": 0,
                    },
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                rows_deferred += 1
                continue
            if len(packet_rows) != 1:
                self.append_connector_event(
                    source_key=source_name,
                    connector_type="imessage_chatdb",
                    external_event_id=external_event_id,
                    status="rejected_packet_resolution",
                    actor=actor or row["handle_id"],
                    raw_text=raw_text,
                    reason="token_did_not_resolve_to_exactly_one_open_packet",
                    payload={
                        "rowid": row["rowid"],
                        "chat_guid": row["chat_guid"],
                        "token": token,
                        "match_count": len(packet_rows),
                    },
                    observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                    commit=False,
                )
                changed = True
                rows_rejected += 1
                continue
            self.apply_operator_action(
                packet_id=packet_rows[0]["packet_id"],
                action_type=parsed["action"],
                actor=actor or row["handle_id"],
                source="imessage_chatdb",
                note=parsed["note"] or raw_text,
                commit=False,
            )
            self.append_connector_event(
                source_key=source_name,
                connector_type="imessage_chatdb",
                external_event_id=external_event_id,
                status="accepted",
                actor=actor or row["handle_id"],
                raw_text=raw_text,
                reason=None,
                payload={
                    "rowid": row["rowid"],
                    "chat_guid": row["chat_guid"],
                    "packet_id": packet_rows[0]["packet_id"],
                    "action_type": parsed["action"],
                },
                observed_at=apple_ns_to_iso(row["date"]) or utc_now(),
                commit=False,
            )
            changed = True
            actions_applied += 1

        self.save_connector_cursor(
            source_key=source_name,
            cursor_value=str(newest_rowid),
            details={
                "adapter": "imessage_chatdb",
                "chat_db_path": str(chat_db_path),
                "operator_chat_guid": operator_chat_guid,
                "operator_handles": normalized_handles,
                "rows_seen": rows_seen,
                "rows_matched": rows_matched,
                "actions_applied": actions_applied,
                "rows_rejected": rows_rejected,
                "rows_deferred": rows_deferred,
                "duplicate_rows": duplicate_rows,
                "deferred_retried": deferred_retry["retried"],
                "deferred_resolved": deferred_retry["resolved"],
                "latest_polled_at": utc_now(),
            },
            commit=False,
        )
        self.conn.commit()
        if changed:
            self.write_latest_snapshot()
        return {
            "source_key": source_name,
            "primed": False,
            "cursor_rowid": newest_rowid,
            "rows_seen": rows_seen,
            "rows_matched": rows_matched,
            "actions_applied": actions_applied,
            "rows_rejected": rows_rejected,
            "rows_deferred": rows_deferred,
            "duplicate_rows": duplicate_rows,
            "deferred_retried": deferred_retry["retried"],
            "deferred_resolved": deferred_retry["resolved"],
        }

    def run_once(self) -> dict[str, Any]:
        emitted = 0
        dispatched_existing = 0
        skipped_existing = 0
        skipped_ineligible = 0
        last_packet: dict[str, Any] | None = None
        for row in self.fetch_candidate_rows():
            if not self.should_emit(row):
                skipped_ineligible += 1
                continue
            packet = self.build_packet(row)
            if self.packet_exists(packet["packet_id"]):
                skipped_existing += 1
                continue
            try:
                self.emit_packet(packet)
            except sqlite3.IntegrityError:
                skipped_existing += 1
                continue
            emitted += 1
            last_packet = packet

        dispatched_existing = self.dispatch_existing_packets()

        total_packets = self.conn.execute(
            "SELECT COUNT(*) AS count FROM emitted_packets"
        ).fetchone()["count"]
        latest_packets = self.conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN route = 'review_now' THEN 1 ELSE 0 END) AS review_now_count,
                SUM(CASE WHEN route = 'review_pending_confirmation' THEN 1 ELSE 0 END) AS review_pending_count,
                SUM(CASE WHEN route = 'hold_for_confirmation' THEN 1 ELSE 0 END) AS hold_count,
                SUM(CASE WHEN route = 'log_only' THEN 1 ELSE 0 END) AS log_only_count
            FROM current_packets
            """
        ).fetchone()
        event_rollup = self.conn.execute(
            """
            SELECT COUNT(*) AS total, MAX(observed_at) AS latest_observed_at
            FROM packet_events
            """
        ).fetchone()
        latest_queue_rows = self.conn.execute(
            """
            SELECT route, last_observed_at, ack_required, ack_due_at, acknowledged_at, delivery_status, presented_at
            FROM current_packets
            ORDER BY emitted_at DESC
            """
        ).fetchall()
        review_now_ages = [
            age_seconds_from_iso(row["last_observed_at"])
            for row in latest_queue_rows
            if row["route"] == "review_now"
        ]
        review_pending_ages = [
            age_seconds_from_iso(row["last_observed_at"])
            for row in latest_queue_rows
            if row["route"] == "review_pending_confirmation"
        ]
        review_now_ages = [value for value in review_now_ages if value is not None]
        review_pending_ages = [value for value in review_pending_ages if value is not None]
        ack_pending_count = 0
        ack_overdue_count = 0
        delivery_failed_count = 0
        unwired_destination_count = 0
        local_queue_only_count = 0
        unpresented_ack_required_count = 0
        now = now_dt()
        for row in latest_queue_rows:
            if row["delivery_status"] == "delivery_failed":
                delivery_failed_count += 1
            if row["delivery_status"] == "blocked_unwired_target":
                unwired_destination_count += 1
            if row["delivery_status"] == "queued_local_only":
                local_queue_only_count += 1
            if row["ack_required"] and not row["presented_at"] and not row["acknowledged_at"]:
                unpresented_ack_required_count += 1
            if row["ack_required"] and row["presented_at"] and not row["acknowledged_at"]:
                ack_pending_count += 1
                due = parse_iso(row["ack_due_at"])
                if due is not None and due.astimezone(timezone.utc) < now:
                    ack_overdue_count += 1
        latest_snapshot = self.write_latest_snapshot()
        coverage_profile = coverage_profile_for(
            relay_adapter=self.relay_adapter,
            webhook_url=self.webhook_url,
            command=self.command,
            pending_replies_path=self.pending_replies_path,
        )
        details = {
            "merge_db": str(self.merge_db),
            "state_db": str(self.state_db),
            "output_path": str(self.output_path),
            "latest_snapshot_path": str(self.latest_snapshot_path) if self.latest_snapshot_path else None,
            "include_notification_only": self.include_notification_only,
            "webhook_url": self.webhook_url,
            "command": self.command,
            "relay_adapter": self.relay_adapter,
            "primary_destination": self.primary_destination,
            "after_hours_destination": self.after_hours_destination,
            "backup_destination": self.backup_destination,
            "pending_replies_path": str(self.pending_replies_path) if self.pending_replies_path else None,
            "dispatch_not_before": self.dispatch_not_before,
            "imessage_service": self.imessage_service if self.relay_adapter == "imessage" else None,
            "imessage_chat_guid": self.imessage_chat_guid if self.relay_adapter == "imessage" else None,
            "business_hours_start": self.business_hours_start,
            "business_hours_end": self.business_hours_end,
            "emitted": emitted,
            "dispatched_existing": dispatched_existing,
            "skipped_existing": skipped_existing,
            "skipped_ineligible": skipped_ineligible,
            "total_packets": total_packets,
            "latest_packets_total": latest_packets["total"] or 0,
            "latest_review_now_count": latest_packets["review_now_count"] or 0,
            "latest_review_pending_count": latest_packets["review_pending_count"] or 0,
            "latest_hold_count": latest_packets["hold_count"] or 0,
            "latest_log_only_count": latest_packets["log_only_count"] or 0,
            "latest_ack_pending_count": ack_pending_count,
            "latest_ack_overdue_count": ack_overdue_count,
            "latest_unpresented_ack_required_count": unpresented_ack_required_count,
            "latest_delivery_failed_count": delivery_failed_count,
            "latest_unwired_destination_count": unwired_destination_count,
            "latest_local_queue_only_count": local_queue_only_count,
            "oldest_review_now_age_seconds": max(review_now_ages) if review_now_ages else None,
            "oldest_review_pending_age_seconds": max(review_pending_ages) if review_pending_ages else None,
            "latest_snapshot_generated_at": latest_snapshot["generated_at"],
            "last_packet": last_packet,
            "packet_event_count": event_rollup["total"] or 0,
            "latest_packet_event_at": event_rollup["latest_observed_at"],
            "coverage_profile": coverage_profile,
        }
        self.write_heartbeat(details)
        return details


def parse_args() -> argparse.Namespace:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--merge-db", type=Path, default=base / "merged-events.sqlite3")
    parser.add_argument("--state-db", type=Path, default=base / "operator-packets.sqlite3")
    parser.add_argument("--output", type=Path, default=base / "operator-packets.jsonl")
    parser.add_argument("--status-json", type=Path, default=base / "packet-status.json")
    parser.add_argument("--latest-snapshot", type=Path, default=base / "operator-packets-latest.json")
    parser.add_argument("--process-role")
    parser.add_argument("--follow", action="store_true")
    parser.add_argument("--interval", type=float, default=2.0)
    parser.add_argument("--include-notification-only", action="store_true")
    parser.add_argument("--webhook-url", default=os.environ.get("WA_PACKET_WEBHOOK_URL"))
    parser.add_argument("--event-command", default=os.environ.get("WA_PACKET_EVENT_COMMAND"))
    parser.add_argument("--packet-relay", default=os.environ.get("WA_PACKET_RELAY"))
    parser.add_argument("--primary-destination", default=os.environ.get("WA_PRIMARY_DESTINATION"))
    parser.add_argument("--after-hours-destination", default=os.environ.get("WA_AFTER_HOURS_DESTINATION"))
    parser.add_argument("--backup-destination", default=os.environ.get("WA_BACKUP_DESTINATION"))
    parser.add_argument("--dispatch-not-before", default=os.environ.get("WA_PACKET_DISPATCH_NOT_BEFORE"))
    parser.add_argument(
        "--pending-replies-path",
        type=Path,
        default=Path(value) if (value := os.environ.get("WA_PENDING_REPLIES_PATH")) else None,
    )
    parser.add_argument("--imessage-service", default=os.environ.get("WA_IMESSAGE_SERVICE", "iMessage"))
    parser.add_argument("--imessage-chat-guid", default=os.environ.get("WA_IMESSAGE_CHAT_GUID"))
    parser.add_argument("--imessage-db-path", type=Path, default=Path(os.environ.get("IMESSAGE_DB_PATH", str(Path.home() / "Library" / "Messages" / "chat.db"))))
    parser.add_argument("--action-status-json", type=Path, default=base / "runtime" / "operator-actions-status.json")
    parser.add_argument("--list-imessage-chats", action="store_true")
    parser.add_argument("--list-limit", type=int, default=20)
    parser.add_argument("--include-group-chats", action="store_true")
    parser.add_argument("--operator-handle", action="append")
    parser.add_argument("--poll-imessage-actions", action="store_true")
    parser.add_argument("--prime-imessage-cursor", action="store_true")
    parser.add_argument("--business-hours-start", type=int, default=int(os.environ.get("WA_BUSINESS_HOURS_START", "8")))
    parser.add_argument("--business-hours-end", type=int, default=int(os.environ.get("WA_BUSINESS_HOURS_END", "18")))
    parser.add_argument("--ack-timeout-high", type=int, default=int(os.environ.get("WA_ACK_TIMEOUT_HIGH", "300")))
    parser.add_argument("--ack-timeout-medium", type=int, default=int(os.environ.get("WA_ACK_TIMEOUT_MEDIUM", "900")))
    parser.add_argument("--ack-timeout-low", type=int, default=int(os.environ.get("WA_ACK_TIMEOUT_LOW", "1800")))
    parser.add_argument("--escalate-after-high", type=int, default=int(os.environ.get("WA_ESCALATE_AFTER_HIGH", "600")))
    parser.add_argument("--escalate-after-medium", type=int, default=int(os.environ.get("WA_ESCALATE_AFTER_MEDIUM", "1800")))
    parser.add_argument("--escalate-after-low", type=int, default=int(os.environ.get("WA_ESCALATE_AFTER_LOW", "3600")))
    parser.add_argument("--ack-packet-id")
    parser.add_argument("--action-packet-id")
    parser.add_argument("--action-type")
    parser.add_argument("--action-source")
    parser.add_argument("--dispatch-packet-id")
    parser.add_argument("--dispatch-force", action="store_true")
    parser.add_argument("--reply-text")
    parser.add_argument("--review-status")
    parser.add_argument("--final-disposition")
    parser.add_argument("--review-actor")
    parser.add_argument("--review-note")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    emitter = PacketEmitter(
        merge_db=args.merge_db,
        state_db=args.state_db,
        output_path=args.output,
        status_path=args.status_json,
        latest_snapshot_path=args.latest_snapshot,
        include_notification_only=args.include_notification_only,
        webhook_url=args.webhook_url,
        command=args.event_command,
        relay_adapter=args.packet_relay,
        primary_destination=args.primary_destination,
        after_hours_destination=args.after_hours_destination,
        backup_destination=args.backup_destination,
        pending_replies_path=args.pending_replies_path,
        dispatch_not_before=args.dispatch_not_before,
        imessage_service=args.imessage_service,
        imessage_chat_guid=args.imessage_chat_guid,
        business_hours_start=args.business_hours_start,
        business_hours_end=args.business_hours_end,
        ack_timeout_high=args.ack_timeout_high,
        ack_timeout_medium=args.ack_timeout_medium,
        ack_timeout_low=args.ack_timeout_low,
        escalate_after_high=args.escalate_after_high,
        escalate_after_medium=args.escalate_after_medium,
        escalate_after_low=args.escalate_after_low,
    )
    try:
        operator_handles: list[str] = []
        for value in args.operator_handle or []:
            operator_handles.extend(part.strip() for part in value.split(",") if part.strip())
        if not operator_handles:
            env_handles = os.environ.get("WA_OPERATOR_HANDLES")
            if env_handles:
                operator_handles.extend(part.strip() for part in env_handles.split(",") if part.strip())
        if args.ack_packet_id:
            result = emitter.apply_operator_update(
                packet_id=args.ack_packet_id,
                acknowledged=True,
                review_status=args.review_status,
                final_disposition=args.final_disposition,
                review_actor=args.review_actor,
                review_note=args.review_note,
                action_type="ACK",
                action_source=args.action_source or "ack_packet_id",
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.action_packet_id and args.action_type:
            result = emitter.apply_operator_action(
                packet_id=args.action_packet_id,
                action_type=args.action_type,
                actor=args.review_actor,
                source=args.action_source or "cli_action",
                note=args.review_note,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.dispatch_packet_id:
            result = emitter.dispatch_packet_by_id(
                args.dispatch_packet_id,
                force=args.dispatch_force,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.reply_text:
            result = emitter.apply_operator_reply(
                reply_text=args.reply_text,
                review_actor=args.review_actor,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.list_imessage_chats:
            try:
                result = emitter.list_imessage_chats(
                    chat_db_path=args.imessage_db_path,
                    limit=args.list_limit,
                    include_group_chats=args.include_group_chats,
                )
            except Exception as exc:
                error_payload, returncode = classify_operator_action_error(exc, args.imessage_db_path)
                print(json.dumps(error_payload, ensure_ascii=False, indent=2), file=sys.stderr)
                return returncode
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.poll_imessage_actions:
            while True:
                try:
                    result = emitter.poll_imessage_actions(
                        chat_db_path=args.imessage_db_path,
                        operator_handles=operator_handles,
                        operator_chat_guid=args.imessage_chat_guid,
                        prime_cursor=args.prime_imessage_cursor,
                    )
                    status_payload = operator_action_status_payload(
                        state="primed" if result.get("primed") else "healthy",
                        path=args.imessage_db_path,
                        source_key=result.get("source_key"),
                        details={
                            "cursor_rowid": result.get("cursor_rowid"),
                            "rows_seen": result.get("rows_seen"),
                            "rows_matched": result.get("rows_matched"),
                            "actions_applied": result.get("actions_applied"),
                            "rows_rejected": result.get("rows_rejected"),
                            "duplicate_rows": result.get("duplicate_rows"),
                            "operator_chat_guid": args.imessage_chat_guid,
                            "operator_handles": sorted(
                                {
                                    value
                                    for value in (
                                        normalize_operator_handle(handle)
                                        for handle in operator_handles
                                    )
                                    if value
                                }
                            ),
                        },
                    )
                    write_runtime_status(args.action_status_json, status_payload)
                    if not args.follow:
                        print(json.dumps(result, ensure_ascii=False, indent=2))
                        return 0
                except Exception as exc:
                    error_payload, returncode = classify_operator_action_error(exc, args.imessage_db_path)
                    write_runtime_status(args.action_status_json, error_payload)
                    if not args.follow:
                        print(json.dumps(error_payload, ensure_ascii=False, indent=2), file=sys.stderr)
                        return returncode
                if not args.follow:
                    return 0
                time.sleep(args.interval)
        while True:
            emitter.run_once()
            if not args.follow:
                return 0
            time.sleep(args.interval)
    finally:
        emitter.close()


if __name__ == "__main__":
    raise SystemExit(main())
