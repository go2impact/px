#!/usr/bin/env python3
"""
Lightweight environment and runtime doctor for the WhatsApp intake starter kit.
"""

from __future__ import annotations

import argparse
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import stack_control


BASE_DIR = Path(__file__).resolve().parent


def run_command(argv: list[str]) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return {"ok": False, "error": "missing"}
    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def status_snapshot() -> list[dict[str, Any]]:
    return [stack_control.status_proc(spec) for spec in stack_control.SPECS.values()]


def package_json_present() -> bool:
    return (BASE_DIR / "package.json").exists()


def node_modules_present() -> bool:
    return (BASE_DIR / "node_modules" / "@whiskeysockets" / "baileys").exists()


def state_of(by_name: dict[str, dict[str, Any]], name: str) -> str:
    item = by_name.get(name) or {}
    return item.get("state_summary") or "missing"


def classify_readiness(statuses: list[dict[str, Any]]) -> dict[str, Any]:
    by_name = {item["name"]: item for item in statuses}
    warnings: list[str] = []
    blockers: list[str] = []

    native_state = state_of(by_name, "native")
    baileys_state = state_of(by_name, "baileys")
    merge_state = state_of(by_name, "merge")
    packets_state = state_of(by_name, "packets")
    actions_state = state_of(by_name, "actions")
    soak_state = state_of(by_name, "soak")

    if native_state in {"down", "stale", "missing"}:
        warnings.append("Native notification collector is not healthy yet.")
    if baileys_state in {"registration_required", "needs_reauth", "logged_out"}:
        blockers.append("Baileys observer account still needs to be linked or re-authenticated.")
    elif baileys_state in {"down", "stale", "missing"}:
        warnings.append("Baileys richer collector is not healthy yet.")
    if merge_state in {"down", "stale", "missing"}:
        warnings.append("Merge layer is not healthy yet.")
    if packets_state in {"down", "stale", "missing"}:
        warnings.append("Packet layer is not healthy yet.")
    else:
        packet_health = (by_name.get("packets") or {}).get("health") or {}
        packet_details = packet_health.get("details") or {}
        coverage_profile = packet_details.get("coverage_profile") or {}
        relay_wired = bool(
            packet_details.get("webhook_url")
            or packet_details.get("command")
            or packet_details.get("relay_adapter") == "imessage"
        )
        if packet_details.get("latest_review_now_count", 0) and not relay_wired:
            warnings.append("Packet queue has actionable items but no outbound relay is wired yet.")
        if packet_details.get("latest_unwired_destination_count", 0):
            warnings.append("Some packets have destinations but no transport wired to deliver them.")
        if coverage_profile.get("native_dms") == "best_effort_notification_only":
            warnings.append("DM coverage is best-effort only right now; do not treat it as authoritative intake.")
        if coverage_profile.get("baileys_dms") == "unsupported":
            warnings.append("Baileys DM coverage is currently unsupported.")
        if coverage_profile.get("operator_loop_state") == "local_queue_only":
            warnings.append("Operator loop is still local-only; packets are not reaching a human yet.")
    packet_health = (by_name.get("packets") or {}).get("health") or {}
    packet_details = packet_health.get("details") or {}
    relay_wired = bool(
        packet_details.get("webhook_url")
        or packet_details.get("command")
        or packet_details.get("relay_adapter") == "imessage"
    )
    action_health = (by_name.get("actions") or {}).get("health") or {}
    action_details = action_health.get("details") or {}
    action_reason = action_details.get("reason")
    if actions_state == "blocked":
        if action_reason == "operator_identity_unconfigured":
            if relay_wired:
                warnings.append("Inbound operator replies are not configured yet. This only matters if you want reply tracking on this Mac.")
        elif action_reason == "chat_db_unreadable":
            if relay_wired:
                warnings.append("Inbound operator replies cannot be read yet because Messages chat.db access is missing.")
        else:
            if relay_wired:
                warnings.append("Inbound operator reply adapter is blocked.")
    elif relay_wired and actions_state in {"degraded", "stale", "missing", "down"}:
        warnings.append("Inbound operator reply adapter is not healthy yet.")
    if soak_state in {"down", "stale", "missing"}:
        warnings.append("Soak watcher is not healthy yet.")

    baileys_health = (by_name.get("baileys") or {}).get("health") or {}
    baileys_details = baileys_health.get("details") or {}
    linked = baileys_details.get("state") == "connected"
    startable = (
        all(name in by_name for name in stack_control.SPECS)
        and native_state != "missing"
        and merge_state != "missing"
        and packets_state != "missing"
        and soak_state != "missing"
        and package_json_present()
        and node_modules_present()
        and baileys_state not in {"registration_required", "needs_reauth", "logged_out", "missing"}
    )

    ready = linked and merge_state not in {"down", "stale"} and packets_state not in {"down", "stale"}
    return {
        "ready_for_live_test": ready,
        "startable_without_help": startable,
        "warnings": warnings,
        "blockers": blockers,
    }


def next_steps_for(statuses: list[dict[str, Any]], package_ok: bool, node_modules_ok: bool) -> list[str]:
    by_name = {item["name"]: item for item in statuses}
    steps: list[str] = []
    if not package_ok:
        steps.append("The bundle is missing package.json; use a fresh starter bundle.")
        return steps
    if not node_modules_ok:
        steps.append("Run `npm install` in this folder, then rerun `python3 doctor_runtime.py` or `RUN_DOCTOR.command`.")
        return steps

    native_state = state_of(by_name, "native")
    baileys_state = state_of(by_name, "baileys")
    merge_state = state_of(by_name, "merge")
    packets_state = state_of(by_name, "packets")
    actions_state = state_of(by_name, "actions")
    soak_state = state_of(by_name, "soak")
    action_health = (by_name.get("actions") or {}).get("health") or {}
    action_details = action_health.get("details") or {}

    all_down = all(
        state == "down"
        for state in [native_state, baileys_state, merge_state, packets_state, actions_state, soak_state]
    )

    if all_down and package_ok and node_modules_ok:
        steps.append("Run `python3 stack_control.py start native baileys merge packets soak` or `START_STACK.command`.")
        return steps

    if native_state in {"down", "stale"}:
        steps.append("Open WhatsApp Desktop, make sure notifications are enabled, then restart `native`.")
    if baileys_state == "registration_required":
        steps.append("Run `npm run baileys:onboarding`, link the phone in WhatsApp > Linked Devices, then rerun status.")
    elif baileys_state in {"down", "stale", "needs_reauth", "logged_out"}:
        steps.append("Restart `baileys`; if it still fails, rerun onboarding and relink the observer account.")
    if merge_state in {"down", "stale"}:
        steps.append("Restart `merge` after the source collectors are healthy.")
    if packets_state in {"down", "stale"}:
        steps.append("Restart `packets` after `merge` is healthy.")
    if relay_wired and actions_state == "blocked":
        reason = action_details.get("reason")
        if reason == "operator_identity_unconfigured":
            steps.append("Set `WA_OPERATOR_HANDLES` or `WA_IMESSAGE_CHAT_GUID`, then restart `actions`.")
        elif reason == "chat_db_unreadable":
            steps.append("Grant Full Disk Access to Messages chat.db for this harness, then restart `actions`.")
        else:
            steps.append("Fix the operator reply adapter blocker, then restart `actions`.")
    elif relay_wired and actions_state in {"down", "stale", "degraded"}:
        steps.append("Restart `actions` after confirming Messages chat.db access and operator handle configuration.")
    if packet_details.get("latest_review_now_count", 0) and not relay_wired:
        steps.append("Wire one outbound relay for packets, or expect the queue to remain local-only on this Mac.")
    if not steps:
        steps.append("Send one fresh test message from another account and inspect `operator-packets-latest.json`.")
    return steps


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    node_version = run_command(["node", "--version"])
    npm_version = run_command(["npm", "--version"])
    python_version = {
        "ok": True,
        "stdout": sys.version.split()[0],
    }

    package_ok = (BASE_DIR / "package.json").exists()
    node_modules_ok = (BASE_DIR / "node_modules" / "@whiskeysockets" / "baileys").exists()
    runtime_dir_ok = stack_control.RUNTIME_DIR.exists()

    statuses = status_snapshot()
    readiness = classify_readiness(statuses)
    next_steps = next_steps_for(statuses, package_ok, node_modules_ok)

    payload = {
        "base_dir": str(BASE_DIR),
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "python": python_version,
            "node": node_version,
            "npm": npm_version,
        },
        "filesystem": {
            "package_json": package_ok,
            "node_modules_baileys": node_modules_ok,
            "runtime_dir": runtime_dir_ok,
        },
        "statuses": statuses,
        "readiness": readiness,
        "coverage": (({item["name"]: item for item in statuses}.get("packets") or {}).get("health") or {}).get("details", {}).get("coverage_profile"),
        "next_steps": next_steps,
        "suggested_commands": {
            "start_stack": f"python3 {BASE_DIR / 'stack_control.py'} start native baileys merge packets soak",
            "stop_stack": f"python3 {BASE_DIR / 'stack_control.py'} stop native baileys merge packets soak",
            "restart_baileys": f"python3 {BASE_DIR / 'stack_control.py'} restart baileys",
            "restart_actions": f"python3 {BASE_DIR / 'stack_control.py'} restart actions",
            "configure_operator_handle": f"python3 {BASE_DIR / 'stack_control.py'} restart actions --operator-handle +15551234567",
            "configure_imessage_chat_guid": f"python3 {BASE_DIR / 'stack_control.py'} restart actions --imessage-chat-guid iMessage;-;chat########",
            "configure_imessage_relay": f"python3 {BASE_DIR / 'stack_control.py'} restart packets --packet-relay imessage --primary-destination +15551234567 --dispatch-not-before 2026-04-10T15:00:00Z",
            "clear_packet_config": f"python3 {BASE_DIR / 'stack_control.py'} restart packets --clear-managed-env",
            "clear_action_config": f"python3 {BASE_DIR / 'stack_control.py'} restart actions --clear-managed-env",
            "status": f"python3 {BASE_DIR / 'stack_control.py'} status",
            "onboarding": f"cd {BASE_DIR} && npm run baileys:onboarding",
        },
    }

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    print("WHATSAPP STARTER DOCTOR")
    print(f"Base dir: {payload['base_dir']}")
    print(f"Platform: {payload['platform']['system']} {payload['platform']['release']}")
    print(f"Python: {python_version['stdout']}")
    print(f"Node: {node_version.get('stdout') or node_version.get('error')}")
    print(f"npm: {npm_version.get('stdout') or npm_version.get('error')}")
    print("")
    print("Filesystem:")
    print(f"  package.json: {'yes' if package_ok else 'no'}")
    print(f"  node_modules/@whiskeysockets/baileys: {'yes' if node_modules_ok else 'no'}")
    print(f"  runtime dir: {'yes' if runtime_dir_ok else 'no'}")
    print("")
    print("Runtime:")
    for item in statuses:
        print(f"  {item['name']}: {item['state_summary']}")
        if item.get("recommended_action"):
            print(f"    action: {item['recommended_action']}")
    print("")
    coverage = payload.get("coverage") or {}
    if coverage:
        print("Coverage:")
        print(f"  groups: {coverage.get('groups')}")
        print(f"  native_dms: {coverage.get('native_dms')}")
        print(f"  baileys_dms: {coverage.get('baileys_dms')}")
        print(f"  operator_loop: {coverage.get('operator_loop_state')}")
        limitations = coverage.get("limitations") or []
        if limitations:
            print("  limitations:")
            for item in limitations:
                print(f"    - {item}")
        print("")
    print(f"Ready for live test: {'yes' if readiness['ready_for_live_test'] else 'no'}")
    if readiness["blockers"]:
        print("Blockers:")
        for blocker in readiness["blockers"]:
            print(f"  - {blocker}")
    if readiness["warnings"]:
        print("Warnings:")
        for warning in readiness["warnings"]:
            print(f"  - {warning}")
    print("Next steps:")
    for step in next_steps:
        print(f"  - {step}")
    print("")
    print("Suggested commands:")
    for label, command in payload["suggested_commands"].items():
        print(f"  {label}: {command}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
