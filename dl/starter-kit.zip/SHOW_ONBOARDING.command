#!/bin/zsh
set -e
cd "$(dirname "$0")"
npm run baileys:onboarding
echo
read '?Press [Enter] to close...'
