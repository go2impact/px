#!/bin/zsh
set -e
cd "$(dirname "$0")"
npm install
echo
read '?Press [Enter] to close...'
