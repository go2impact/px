#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import subprocess
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from AppKit import NSWorkspace
from ApplicationServices import AXUIElementCopyAttributeValue, AXUIElementCreateApplication


SCHEMA = '''
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY,
    source TEXT NOT NULL,
    content_key TEXT,
    process_name TEXT,
    surface TEXT,
    app_name TEXT NOT NULL,
    chat_name TEXT,
    sender TEXT,
    message_text TEXT,
    titles_json TEXT,
    texts_json TEXT,
    raw_description TEXT NOT NULL,
    dedupe_key TEXT NOT NULL UNIQUE,
    first_observed_at TEXT NOT NULL,
    last_observed_at TEXT NOT NULL,
    ended_at TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    payload_json TEXT NOT NULL,
    collector_version TEXT,
    parser_version TEXT,
    delivery_mode TEXT,
    confidence REAL,
    completeness_json TEXT,
    stack_key TEXT
);
CREATE INDEX IF NOT EXISTS idx_notifications_app_last_seen
ON notifications (app_name, last_observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_process_last_seen
ON notifications (process_name, last_observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_content_active
ON notifications (content_key, active, last_observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_stack_active
ON notifications (source, active, stack_key, last_observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_stack_ended
ON notifications (source, active, stack_key, ended_at DESC);
CREATE TABLE IF NOT EXISTS heartbeats (
    source TEXT PRIMARY KEY,
    observed_at TEXT NOT NULL,
    details_json TEXT NOT NULL
);
'''

SOURCE = "notification_center_ax"
COLLECTOR_VERSION = "0.2.0-bundle"
PARSER_VERSION = "notification_center_ax_bundle_v1"
APP_NAMES = ("NotificationCenter", "UserNotificationCenter")
MAX_DEPTH = 6
NOISE_VALUES = {
    "stacked",
    "most recent",
    "notification center",
    "today",
    "yesterday",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_hash(parts: list[Any]) -> str:
    blob = json.dumps(parts, ensure_ascii=False, sort_keys=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def normalize_text(value: Any) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).strip().split())
    return text or None


def ax_value(element: Any, attribute: str) -> Any:
    try:
        result = AXUIElementCopyAttributeValue(element, attribute, None)
    except Exception:
        return None
    if not result or result[0] != 0:
        return None
    return result[1]


def ax_children(element: Any) -> list[Any]:
    values: list[Any] = []
    for attr in ("AXChildren", "AXChildrenInNavigationOrder"):
        children = ax_value(element, attr)
        if isinstance(children, (list, tuple)):
            values.extend(children)
    deduped: list[Any] = []
    seen: set[int] = set()
    for child in values:
        marker = id(child)
        if marker in seen:
            continue
        seen.add(marker)
        deduped.append(child)
    return deduped


def collect_strings(element: Any, depth: int = 0, seen: set[int] | None = None) -> list[str]:
    if seen is None:
        seen = set()
    marker = id(element)
    if marker in seen or depth > MAX_DEPTH:
        return []
    seen.add(marker)

    values: list[str] = []
    for attr in ("AXTitle", "AXValue", "AXDescription", "AXLabel"):
        text = normalize_text(ax_value(element, attr))
        if text:
            values.append(text)
    for child in ax_children(element):
        values.extend(collect_strings(child, depth + 1, seen))
    return values


def unique_strings(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        cleaned = normalize_text(value)
        if not cleaned:
            continue
        key = cleaned.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(cleaned)
    return out


def strip_noise(values: list[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        norm = value.casefold()
        if norm == "whatsapp":
            continue
        if norm in NOISE_VALUES:
            continue
        if norm.endswith(" ago"):
            continue
        out.append(value)
    return out


def parse_notification(values: list[str], process_name: str, surface: str) -> dict[str, Any] | None:
    unique = unique_strings(values)
    if not unique:
        return None
    joined = " | ".join(unique).casefold()
    if "whatsapp" not in joined:
        return None

    body = strip_noise(unique)
    if not body:
        return None

    sender = None
    chat_name = None
    message_text = None
    parse_hints: dict[str, Any] = {}

    if len(body) >= 3:
        sender = body[0]
        chat_name = body[1]
        message_text = ", ".join(body[2:])
        delivery_mode = "group_message_guess"
        parse_hints["shape"] = "group"
    elif len(body) == 2:
        sender = body[0]
        chat_name = body[0]
        message_text = body[1]
        delivery_mode = "direct_message_guess"
        parse_hints["shape"] = "direct"
    else:
        return None

    sender = normalize_text(sender)
    chat_name = normalize_text(chat_name)
    message_text = normalize_text(message_text)
    if not message_text:
        return None

    completeness = {
        "has_chat_name": bool(chat_name),
        "has_sender": bool(sender),
        "has_text": bool(message_text),
    }
    raw_description = ", ".join(unique)
    content_key = stable_hash(["content", chat_name or "", sender or "", message_text])
    stack_key = stable_hash(["stack", process_name, surface, raw_description])
    now = utc_now()

    return {
        "event_id": stable_hash(["event", SOURCE, stack_key, content_key]),
        "schema_version": "2026-04-08.notification-v1",
        "event_type": "whatsapp_notification",
        "observed_at": now,
        "source_emitted_at": now,
        "source_type": SOURCE,
        "source_instance_id": f"{process_name}:{surface}",
        "collector_version": COLLECTOR_VERSION,
        "parser_version": PARSER_VERSION,
        "delivery_mode": delivery_mode,
        "confidence": 0.95,
        "completeness": completeness,
        "content_key": content_key,
        "stack_key": stack_key,
        "process_name": process_name,
        "surface": surface,
        "app_name": "WhatsApp",
        "chat_name": chat_name,
        "conversation_display": chat_name,
        "sender": sender,
        "sender_display": sender,
        "message_text": message_text,
        "raw_description": raw_description,
        "titles": [],
        "texts": body,
        "parse_hints": parse_hints,
    }


def scan_candidates() -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for app in NSWorkspace.sharedWorkspace().runningApplications():
        process_name = app.localizedName()
        if process_name not in APP_NAMES:
            continue
        root = AXUIElementCreateApplication(app.processIdentifier())
        surfaces: list[tuple[str, Any]] = []
        windows = ax_value(root, "AXWindows")
        if isinstance(windows, (list, tuple)):
            for idx, window in enumerate(windows, start=1):
                surfaces.append((f"{process_name}:window:{idx}", window))
        for idx, child in enumerate(ax_children(root), start=1):
            surfaces.append((f"{process_name}:candidate:{idx}", child))

        for surface, element in surfaces:
            parsed = parse_notification(collect_strings(element), process_name, surface)
            if parsed:
                events.append(parsed)
    return events


class Store:
    def __init__(self, db_path: Path) -> None:
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def upsert_notification(self, payload: dict[str, Any]) -> bool:
        dedupe_key = stable_hash([payload["source_type"], payload["stack_key"], payload["content_key"]])
        now = utc_now()
        existing = self.conn.execute(
            "SELECT id FROM notifications WHERE dedupe_key = ?",
            (dedupe_key,),
        ).fetchone()
        titles_json = json.dumps(payload.get("titles") or [], ensure_ascii=False)
        texts_json = json.dumps(payload.get("texts") or [], ensure_ascii=False)
        completeness_json = json.dumps(payload.get("completeness") or {}, ensure_ascii=False, sort_keys=True)
        payload_json = json.dumps(payload, ensure_ascii=False)

        if existing is None:
            self.conn.execute(
                '''
                INSERT INTO notifications (
                    source, content_key, process_name, surface, app_name, chat_name, sender, message_text,
                    titles_json, texts_json, raw_description, dedupe_key, first_observed_at, last_observed_at,
                    active, payload_json, collector_version, parser_version, delivery_mode, confidence,
                    completeness_json, stack_key
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (
                    payload["source_type"],
                    payload.get("content_key"),
                    payload.get("process_name"),
                    payload.get("surface"),
                    payload.get("app_name"),
                    payload.get("chat_name"),
                    payload.get("sender"),
                    payload.get("message_text"),
                    titles_json,
                    texts_json,
                    payload.get("raw_description"),
                    dedupe_key,
                    now,
                    now,
                    payload_json,
                    payload.get("collector_version"),
                    payload.get("parser_version"),
                    payload.get("delivery_mode"),
                    payload.get("confidence"),
                    completeness_json,
                    payload.get("stack_key"),
                ),
            )
            self.conn.commit()
            return True

        self.conn.execute(
            '''
            UPDATE notifications
            SET last_observed_at = ?, ended_at = NULL, active = 1, payload_json = ?, titles_json = ?, texts_json = ?,
                raw_description = ?, chat_name = ?, sender = ?, message_text = ?, collector_version = ?,
                parser_version = ?, delivery_mode = ?, confidence = ?, completeness_json = ?, stack_key = ?
            WHERE dedupe_key = ?
            ''',
            (
                now,
                payload_json,
                titles_json,
                texts_json,
                payload.get("raw_description"),
                payload.get("chat_name"),
                payload.get("sender"),
                payload.get("message_text"),
                payload.get("collector_version"),
                payload.get("parser_version"),
                payload.get("delivery_mode"),
                payload.get("confidence"),
                completeness_json,
                payload.get("stack_key"),
                dedupe_key,
            ),
        )
        self.conn.commit()
        return False

    def end_missing(self, seen_stack_keys: set[str]) -> None:
        now = utc_now()
        rows = self.conn.execute(
            "SELECT dedupe_key, stack_key FROM notifications WHERE source = ? AND active = 1",
            (SOURCE,),
        ).fetchall()
        for row in rows:
            if row["stack_key"] not in seen_stack_keys:
                self.conn.execute(
                    "UPDATE notifications SET active = 0, ended_at = ? WHERE dedupe_key = ?",
                    (now, row["dedupe_key"]),
                )
        self.conn.commit()

    def write_heartbeat(self, details: dict[str, Any]) -> None:
        now = utc_now()
        self.conn.execute(
            '''
            INSERT INTO heartbeats (source, observed_at, details_json)
            VALUES (?, ?, ?)
            ON CONFLICT(source) DO UPDATE SET observed_at = excluded.observed_at, details_json = excluded.details_json
            ''',
            (SOURCE, now, json.dumps(details, ensure_ascii=False, sort_keys=True)),
        )
        self.conn.commit()


def emit_event(event_log: Path | None, payload: dict[str, Any], webhook_url: str | None, event_command: str | None) -> None:
    if event_log is not None:
        event_log.parent.mkdir(parents=True, exist_ok=True)
        with event_log.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
    if webhook_url:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(webhook_url, data=body, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=5).read()
        except Exception:
            pass
    if event_command:
        try:
            subprocess.run(event_command.split(), input=json.dumps(payload, ensure_ascii=False), text=True, check=False)
        except Exception:
            pass


def run_once(args: argparse.Namespace) -> list[dict[str, Any]]:
    store = Store(args.db)
    events = scan_candidates()
    seen_stack_keys: set[str] = set()
    emitted: list[dict[str, Any]] = []
    for payload in events:
        seen_stack_keys.add(payload["stack_key"])
        created = store.upsert_notification(payload)
        if created:
            emitted.append(payload)
            emit_event(None if args.no_event_log else args.event_log, payload, args.webhook_url, args.event_command)
    store.end_missing(seen_stack_keys)
    store.write_heartbeat(
        {
            "collector_version": COLLECTOR_VERSION,
            "parser_version": PARSER_VERSION,
            "candidate_count": len(events),
            "new_event_count": len(emitted),
            "active_stack_count": len(seen_stack_keys),
            "app_filter": args.app_filter,
        }
    )
    return emitted


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=float, default=2.0)
    parser.add_argument("--db", type=Path, default=Path("observer.sqlite3"))
    parser.add_argument("--event-log", type=Path, default=Path("events.jsonl"))
    parser.add_argument("--no-event-log", action="store_true")
    parser.add_argument("--webhook-url")
    parser.add_argument("--event-command")
    parser.add_argument("--app-filter", default="WhatsApp")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.once:
        events = run_once(args)
        if args.json:
            print(json.dumps({"events": events}, ensure_ascii=False))
        return 0

    while True:
        run_once(args)
        time.sleep(args.interval)


if __name__ == "__main__":
    raise SystemExit(main())
