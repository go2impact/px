#!/usr/bin/env python3
"""
Merge source events from multiple collector spools into a canonical local event log.

This is the first pass at the layer above individual collectors:
- collector-specific raw/source events are preserved
- canonical events are merged heuristically
- notification-only events stay provisional
- richer sources can confirm and upgrade canonicals
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = """
CREATE TABLE IF NOT EXISTS source_events (
    source_event_id TEXT PRIMARY KEY,
    source_type TEXT NOT NULL,
    source_instance_id TEXT,
    collector_version TEXT,
    parser_version TEXT,
    observed_at TEXT,
    source_emitted_at TEXT,
    source_message_id TEXT,
    conversation_key TEXT,
    conversation_display TEXT,
    sender_key TEXT,
    sender_display TEXT,
    delivery_mode TEXT,
    confidence REAL,
    completeness_json TEXT,
    message_text TEXT,
    raw_payload_json TEXT NOT NULL,
    canonical_event_id TEXT,
    match_status TEXT NOT NULL,
    ingested_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_source_events_canonical
ON source_events (canonical_event_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS source_spools (
    spool_path TEXT PRIMARY KEY,
    source_hint TEXT,
    inode TEXT,
    last_offset INTEGER NOT NULL DEFAULT 0,
    last_mtime_ns INTEGER,
    last_error TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS heartbeats (
    source TEXT PRIMARY KEY,
    observed_at TEXT NOT NULL,
    details_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS canonical_events (
    canonical_event_id TEXT PRIMARY KEY,
    canonical_key TEXT NOT NULL UNIQUE,
    match_key TEXT NOT NULL,
    status TEXT NOT NULL,
    best_source_type TEXT,
    merged_confidence REAL NOT NULL,
    first_observed_at TEXT NOT NULL,
    last_observed_at TEXT NOT NULL,
    conversation_key TEXT,
    conversation_display TEXT,
    sender_key TEXT,
    sender_display TEXT,
    message_text TEXT,
    source_count INTEGER NOT NULL DEFAULT 0,
    evidence_count INTEGER NOT NULL DEFAULT 0,
    evidence_sources_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

"""


SOURCE_PRIORITY = {
    "baileys": 3,
    "whatsapp_web": 3,
    "whatsapp_web_js": 3,
    "notification_center_ax": 1,
    "macos_notification": 1,
}

PROVISIONAL_CONFIDENCE_CAP = 0.65
CONFIRMED_CONFIDENCE_CAP = 0.99
DIRECT_SINGLE_SOURCE_CONFIDENCE_CAP = 0.85
STRICT_CROSS_SOURCE_WINDOW_SECONDS = 45
UNIQUE_CROSS_SOURCE_WINDOW_SECONDS = 5 * 60


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = " ".join(value.strip().split())
    return cleaned or None


def iso_bucket(value: str | None, seconds: int = 30) -> str:
    if not value:
        return "no-time"
    try:
        ts = datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return "bad-time"
    bucket = int(ts // seconds) * seconds
    return str(bucket)


def iso_timestamp_seconds(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def earlier_iso(a: str | None, b: str | None) -> str | None:
    if not a:
        return b
    if not b:
        return a
    a_ts = iso_timestamp_seconds(a)
    b_ts = iso_timestamp_seconds(b)
    if a_ts is None:
        return b
    if b_ts is None:
        return a
    return a if a_ts <= b_ts else b


def later_iso(a: str | None, b: str | None) -> str | None:
    if not a:
        return b
    if not b:
        return a
    a_ts = iso_timestamp_seconds(a)
    b_ts = iso_timestamp_seconds(b)
    if a_ts is None:
        return b
    if b_ts is None:
        return a
    return a if a_ts >= b_ts else b


def stable_hash(parts: list[str | None]) -> str:
    blob = json.dumps(parts, ensure_ascii=False, sort_keys=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(f"{path.suffix}.tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.replace(path)


@dataclass
class NormalizedSourceEvent:
    source_event_id: str
    source_type: str
    source_instance_id: str | None
    collector_version: str | None
    parser_version: str | None
    observed_at: str | None
    source_emitted_at: str | None
    source_message_id: str | None
    conversation_key: str | None
    conversation_display: str | None
    sender_key: str | None
    sender_display: str | None
    delivery_mode: str | None
    confidence: float
    completeness: dict[str, Any]
    message_text: str | None
    raw_payload: dict[str, Any]

    @property
    def source_rank(self) -> int:
        return SOURCE_PRIORITY.get(self.source_type, 0)

    @property
    def canonical_key(self) -> str:
        if self.source_rank >= 3 and self.source_message_id:
            return stable_hash(
                [
                    "source-message",
                    self.conversation_key or self.conversation_display or "",
                    self.source_message_id,
                ]
            )
        return self.match_key

    @property
    def match_key(self) -> str:
        return stable_hash(
            [
                (self.conversation_display or self.conversation_key or "").casefold(),
                (self.sender_display or self.sender_key or "").casefold(),
                (self.message_text or "")[:160],
                iso_bucket(self.source_emitted_at or self.observed_at),
            ]
        )


def normalize_native_event(payload: dict[str, Any]) -> NormalizedSourceEvent:
    source_event_id = payload.get("event_id") or stable_hash([json.dumps(payload, sort_keys=True)])
    conversation_display = normalize_text(payload.get("chat_name"))
    sender_display = normalize_text(payload.get("sender"))
    message_text = normalize_text(payload.get("message_text"))
    completeness = payload.get("completeness") or {}
    conversation_key = stable_hash(["notification_chat", (conversation_display or "").casefold()]) if conversation_display else None
    sender_key = stable_hash(["notification_sender", (sender_display or "").casefold()]) if sender_display else None
    return NormalizedSourceEvent(
        source_event_id=source_event_id,
        source_type=payload.get("source_type") or payload.get("source") or "notification_center_ax",
        source_instance_id=payload.get("source_instance_id"),
        collector_version=payload.get("collector_version"),
        parser_version=payload.get("parser_version"),
        observed_at=payload.get("observed_at"),
        source_emitted_at=payload.get("source_emitted_at") or payload.get("observed_at"),
        source_message_id=payload.get("source_message_id") or source_event_id,
        conversation_key=conversation_key,
        conversation_display=conversation_display,
        sender_key=sender_key,
        sender_display=sender_display,
        delivery_mode=payload.get("delivery_mode"),
        confidence=float(payload.get("confidence", 0.0) or 0.0),
        completeness=completeness,
        message_text=message_text,
        raw_payload=payload,
    )


def normalize_baileys_event(payload: dict[str, Any]) -> NormalizedSourceEvent:
    source_event_id = payload.get("event_id") or stable_hash([json.dumps(payload, sort_keys=True)])
    completeness = payload.get("completeness") or {}
    return NormalizedSourceEvent(
        source_event_id=source_event_id,
        source_type=payload.get("source_type") or "baileys",
        source_instance_id=payload.get("source_instance_id"),
        collector_version=payload.get("collector_version"),
        parser_version=payload.get("parser_version"),
        observed_at=payload.get("observed_at"),
        source_emitted_at=payload.get("source_emitted_at") or payload.get("message_timestamp"),
        source_message_id=payload.get("source_message_id") or payload.get("event_id"),
        conversation_key=payload.get("conversation_key") or payload.get("remote_jid"),
        conversation_display=normalize_text(payload.get("conversation_display") or payload.get("chat_name")),
        sender_key=payload.get("sender_key") or payload.get("participant_jid"),
        sender_display=normalize_text(payload.get("sender_display") or payload.get("sender")),
        delivery_mode=payload.get("delivery_mode"),
        confidence=float(payload.get("confidence", 0.0) or 0.0),
        completeness=completeness,
        message_text=normalize_text(payload.get("message_text")),
        raw_payload=payload,
    )


def normalize_event(payload: dict[str, Any]) -> NormalizedSourceEvent:
    source_type = payload.get("source_type") or payload.get("source")
    if source_type in {"baileys", "whatsapp_web", "whatsapp_web_js"}:
        return normalize_baileys_event(payload)
    return normalize_native_event(payload)


def merged_confidence_for(
    *,
    source_types: list[str],
    prior_confidence: float | None,
    event_confidence: float,
) -> float:
    unique_sources = sorted(set(source_types))
    has_richer_source = any(SOURCE_PRIORITY.get(source_type, 0) >= 3 for source_type in unique_sources)
    baseline = max(prior_confidence or 0.0, event_confidence)
    if len(unique_sources) > 1:
        baseline += 0.15 if has_richer_source else 0.05
    if has_richer_source and len(unique_sources) > 1:
        cap = CONFIRMED_CONFIDENCE_CAP
    elif has_richer_source:
        cap = DIRECT_SINGLE_SOURCE_CONFIDENCE_CAP
    else:
        cap = PROVISIONAL_CONFIDENCE_CAP
    return min(cap, baseline)


def canonical_status_for(source_types: list[str]) -> str:
    unique_sources = sorted(set(source_types))
    has_richer_source = any(SOURCE_PRIORITY.get(source_type, 0) >= 3 for source_type in unique_sources)
    if has_richer_source and len(unique_sources) > 1:
        return "confirmed"
    return "provisional"


def match_status_for(event: NormalizedSourceEvent) -> str:
    if event.source_rank >= 3:
        return "direct"
    return "provisional"


class MergeStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, timeout=30.0)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA busy_timeout = 30000")
        self.conn.execute("PRAGMA synchronous = NORMAL")
        self.conn.executescript(SCHEMA)
        self._ensure_schema()
        self.conn.commit()

    def _ensure_schema(self) -> None:
        existing_columns = {
            row["name"] for row in self.conn.execute("PRAGMA table_info(canonical_events)")
        }
        if "match_key" not in existing_columns:
            self.conn.execute("ALTER TABLE canonical_events ADD COLUMN match_key TEXT")
            self.conn.execute("UPDATE canonical_events SET match_key = canonical_key WHERE match_key IS NULL")
        self.conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_canonical_events_match_key
            ON canonical_events (match_key, updated_at DESC)
            """
        )

    def has_source_event(self, source_event_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM source_events WHERE source_event_id = ?",
            (source_event_id,),
        ).fetchone()
        return row is not None

    def find_canonical(self, event: NormalizedSourceEvent) -> sqlite3.Row | None:
        canonical = self.conn.execute(
            "SELECT * FROM canonical_events WHERE canonical_key = ?",
            (event.canonical_key,),
        ).fetchone()
        if canonical is not None:
            return canonical
        if event.source_rank < 3 or not event.source_message_id:
            canonical = self.find_recent_match_key(event)
            if canonical is not None:
                return canonical
        return self.find_cross_source_soft_match(event)

    def find_recent_match_key(self, event: NormalizedSourceEvent) -> sqlite3.Row | None:
        event_ts = iso_timestamp_seconds(event.source_emitted_at or event.observed_at)
        if event_ts is None:
            return None
        candidates = self.conn.execute(
            """
            SELECT *
            FROM canonical_events
            WHERE match_key = ?
            ORDER BY updated_at DESC
            LIMIT 12
            """,
            (event.match_key,),
        ).fetchall()
        if not candidates:
            return None
        for candidate in candidates:
            candidate_ts = iso_timestamp_seconds(candidate["last_observed_at"])
            if candidate_ts is None:
                continue
            if abs(candidate_ts - event_ts) <= 45:
                return candidate
        return None

    def find_cross_source_soft_match(self, event: NormalizedSourceEvent) -> sqlite3.Row | None:
        conversation_probe = (event.conversation_display or event.conversation_key or "").casefold()
        message_probe = event.message_text or ""
        event_ts = iso_timestamp_seconds(event.source_emitted_at or event.observed_at)
        if not conversation_probe or not message_probe or event_ts is None:
            return None

        candidates = self.conn.execute(
            """
            SELECT *
            FROM canonical_events
            WHERE status = 'provisional'
              AND lower(coalesce(conversation_display, conversation_key, '')) = ?
              AND coalesce(message_text, '') = ?
            ORDER BY updated_at DESC
            LIMIT 12
            """,
            (conversation_probe, message_probe),
        ).fetchall()
        if not candidates:
            return None

        viable_candidates: list[sqlite3.Row] = []
        for candidate in candidates:
            candidate_rank = SOURCE_PRIORITY.get(candidate["best_source_type"], 0)
            if bool(candidate_rank >= 3) == bool(event.source_rank >= 3):
                continue
            candidate_ts = iso_timestamp_seconds(candidate["last_observed_at"])
            if candidate_ts is None:
                continue
            delta = abs(candidate_ts - event_ts)
            if delta <= STRICT_CROSS_SOURCE_WINDOW_SECONDS:
                return candidate
            if delta <= UNIQUE_CROSS_SOURCE_WINDOW_SECONDS:
                viable_candidates.append(candidate)
        if len(viable_candidates) == 1:
            return viable_candidates[0]
        return None

    def ingest(self, event: NormalizedSourceEvent) -> str:
        canonical = self.find_canonical(event)
        now = utc_now()
        if canonical is None:
            canonical_event_id = stable_hash(["canonical", event.canonical_key])
            evidence_sources = [event.source_type]
            status = canonical_status_for(evidence_sources)
            merged_confidence = merged_confidence_for(
                source_types=evidence_sources,
                prior_confidence=None,
                event_confidence=event.confidence,
            )
            self.conn.execute(
                """
                INSERT INTO canonical_events (
                    canonical_event_id,
                    canonical_key,
                    match_key,
                    status,
                    best_source_type,
                    merged_confidence,
                    first_observed_at,
                    last_observed_at,
                    conversation_key,
                    conversation_display,
                    sender_key,
                    sender_display,
                    message_text,
                    source_count,
                    evidence_count,
                    evidence_sources_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?, ?)
                """,
                (
                    canonical_event_id,
                    event.canonical_key,
                    event.match_key,
                    status,
                    event.source_type,
                    merged_confidence,
                    event.observed_at or now,
                    event.observed_at or now,
                    event.conversation_key,
                    event.conversation_display,
                    event.sender_key,
                    event.sender_display,
                    event.message_text,
                    json.dumps(evidence_sources, ensure_ascii=False, sort_keys=True),
                    now,
                    now,
                ),
            )
        else:
            canonical_event_id = canonical["canonical_event_id"]
            evidence_sources = json.loads(canonical["evidence_sources_json"])
            if event.source_type not in evidence_sources:
                evidence_sources.append(event.source_type)
            best_source_type = canonical["best_source_type"]
            best_rank = SOURCE_PRIORITY.get(best_source_type, 0) if best_source_type else -1
            preferred_message_text = canonical["message_text"]
            preferred_conversation_display = canonical["conversation_display"]
            preferred_sender_display = canonical["sender_display"]
            preferred_canonical_key = canonical["canonical_key"]
            if event.source_rank >= best_rank:
                best_source_type = event.source_type
                preferred_message_text = event.message_text or preferred_message_text
                preferred_conversation_display = event.conversation_display or preferred_conversation_display
                preferred_sender_display = event.sender_display or preferred_sender_display
            if event.source_rank >= 3 and event.source_message_id:
                preferred_canonical_key = event.canonical_key

            merged_confidence = merged_confidence_for(
                source_types=evidence_sources,
                prior_confidence=float(canonical["merged_confidence"]),
                event_confidence=event.confidence,
            )
            status = canonical_status_for(evidence_sources)
            event_observed_at = event.observed_at or now
            merged_first_observed_at = earlier_iso(canonical["first_observed_at"], event_observed_at) or event_observed_at
            merged_last_observed_at = later_iso(canonical["last_observed_at"], event_observed_at) or event_observed_at
            self.conn.execute(
                """
                UPDATE canonical_events
                SET canonical_key = ?,
                    match_key = ?,
                    status = ?,
                    best_source_type = ?,
                    merged_confidence = ?,
                    first_observed_at = ?,
                    last_observed_at = ?,
                    conversation_key = COALESCE(conversation_key, ?),
                    conversation_display = ?,
                    sender_key = COALESCE(sender_key, ?),
                    sender_display = ?,
                    message_text = ?,
                    source_count = source_count + 1,
                    evidence_count = evidence_count + 1,
                    evidence_sources_json = ?,
                    updated_at = ?
                WHERE canonical_event_id = ?
                """,
                (
                    preferred_canonical_key,
                    event.match_key,
                    status,
                    best_source_type,
                    merged_confidence,
                    merged_first_observed_at,
                    merged_last_observed_at,
                    event.conversation_key,
                    preferred_conversation_display,
                    event.sender_key,
                    preferred_sender_display,
                    preferred_message_text,
                    json.dumps(sorted(set(evidence_sources)), ensure_ascii=False),
                    now,
                    canonical_event_id,
                ),
            )

        match_status = match_status_for(event)
        self.conn.execute(
            """
            INSERT INTO source_events (
                source_event_id,
                source_type,
                source_instance_id,
                collector_version,
                parser_version,
                observed_at,
                source_emitted_at,
                source_message_id,
                conversation_key,
                conversation_display,
                sender_key,
                sender_display,
                delivery_mode,
                confidence,
                completeness_json,
                message_text,
                raw_payload_json,
                canonical_event_id,
                match_status,
                ingested_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event.source_event_id,
                event.source_type,
                event.source_instance_id,
                event.collector_version,
                event.parser_version,
                event.observed_at,
                event.source_emitted_at,
                event.source_message_id,
                event.conversation_key,
                event.conversation_display,
                event.sender_key,
                event.sender_display,
                event.delivery_mode,
                event.confidence,
                json.dumps(event.completeness, ensure_ascii=False, sort_keys=True),
                event.message_text,
                json.dumps(event.raw_payload, ensure_ascii=False),
                canonical_event_id,
                match_status,
                now,
            ),
        )
        self.conn.commit()
        return canonical_event_id

    def status(self) -> dict[str, Any]:
        source_event_count = self.conn.execute("SELECT COUNT(*) AS count FROM source_events").fetchone()["count"]
        canonical_event_count = self.conn.execute("SELECT COUNT(*) AS count FROM canonical_events").fetchone()["count"]
        last_source_event = self.conn.execute(
            """
            SELECT source_type, observed_at, source_emitted_at, conversation_display, sender_display
            FROM source_events
            ORDER BY ingested_at DESC
            LIMIT 1
            """
        ).fetchone()
        last_canonical_event = self.conn.execute(
            """
            SELECT canonical_event_id, updated_at, status, best_source_type, conversation_display, sender_display
            FROM canonical_events
            ORDER BY updated_at DESC
            LIMIT 1
            """
        ).fetchone()
        provisional_count = self.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM canonical_events
            WHERE status = 'provisional'
            """
        ).fetchone()["count"]
        confirmed_count = self.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM canonical_events
            WHERE status = 'confirmed'
            """
        ).fetchone()["count"]
        rich_provisional_count = self.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM canonical_events
            WHERE status = 'provisional'
              AND coalesce(best_source_type, '') IN ('baileys', 'whatsapp_web', 'whatsapp_web_js')
            """
        ).fetchone()["count"]
        notification_provisional_count = self.conn.execute(
            """
            SELECT COUNT(*) AS count
            FROM canonical_events
            WHERE status = 'provisional'
              AND coalesce(best_source_type, '') NOT IN ('baileys', 'whatsapp_web', 'whatsapp_web_js')
            """
        ).fetchone()["count"]
        canonical_rows = self.conn.execute(
            """
            SELECT canonical_event_id, status, best_source_type, merged_confidence,
                   conversation_display, sender_display, substr(message_text, 1, 120) AS message_prefix
            FROM canonical_events
            ORDER BY updated_at DESC
            LIMIT 10
            """
        ).fetchall()
        return {
            "db_path": str(self.db_path),
            "source_event_count": source_event_count,
            "canonical_event_count": canonical_event_count,
            "provisional_canonical_count": provisional_count,
            "confirmed_canonical_count": confirmed_count,
            "rich_provisional_canonical_count": rich_provisional_count,
            "notification_provisional_canonical_count": notification_provisional_count,
            "last_source_event": dict(last_source_event) if last_source_event else None,
            "last_canonical_event": dict(last_canonical_event) if last_canonical_event else None,
            "source_spools": [dict(row) for row in self.conn.execute(
                """
                SELECT spool_path, source_hint, inode, last_offset, last_mtime_ns, last_error, updated_at
                FROM source_spools
                ORDER BY spool_path
                """
            ).fetchall()],
            "heartbeats": [
                {
                    "source": row["source"],
                    "observed_at": row["observed_at"],
                    "details": json.loads(row["details_json"]),
                }
                for row in self.conn.execute(
                    """
                    SELECT source, observed_at, details_json
                    FROM heartbeats
                    ORDER BY source
                    """
                ).fetchall()
            ],
            "recent_canonicals": [dict(row) for row in canonical_rows],
        }

    def get_spool_state(self, spool_path: Path) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT spool_path, source_hint, inode, last_offset, last_mtime_ns, last_error, updated_at
            FROM source_spools
            WHERE spool_path = ?
            """,
            (str(spool_path),),
        ).fetchone()

    def upsert_spool_state(
        self,
        spool_path: Path,
        *,
        source_hint: str | None,
        inode: str | None,
        last_offset: int,
        last_mtime_ns: int | None,
        last_error: str | None,
    ) -> None:
        self.conn.execute(
            """
            INSERT INTO source_spools (
                spool_path,
                source_hint,
                inode,
                last_offset,
                last_mtime_ns,
                last_error,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(spool_path) DO UPDATE SET
                source_hint = excluded.source_hint,
                inode = excluded.inode,
                last_offset = excluded.last_offset,
                last_mtime_ns = excluded.last_mtime_ns,
                last_error = excluded.last_error,
                updated_at = excluded.updated_at
            """,
            (
                str(spool_path),
                source_hint,
                inode,
                last_offset,
                last_mtime_ns,
                last_error,
                utc_now(),
            ),
        )
        self.conn.commit()

    def upsert_heartbeat(self, source: str, details: dict[str, Any]) -> None:
        self.conn.execute(
            """
            INSERT INTO heartbeats (source, observed_at, details_json)
            VALUES (?, ?, ?)
            ON CONFLICT(source) DO UPDATE SET
                observed_at = excluded.observed_at,
                details_json = excluded.details_json
            """,
            (source, utc_now(), json.dumps(details, ensure_ascii=False, sort_keys=True)),
        )
        self.conn.commit()


def file_inode_key(path: Path) -> tuple[str, int]:
    stat = path.stat()
    return f"{stat.st_dev}:{stat.st_ino}", stat.st_mtime_ns


def ingest_spool(store: MergeStore, spool_path: Path, source_hint: str | None = None) -> dict[str, Any]:
    previous = store.get_spool_state(spool_path)
    last_offset = int(previous["last_offset"]) if previous else 0
    previous_inode = previous["inode"] if previous else None
    last_error: str | None = None

    if not spool_path.exists():
        store.upsert_spool_state(
            spool_path,
            source_hint=source_hint,
            inode=previous_inode,
            last_offset=last_offset,
            last_mtime_ns=None,
            last_error=None,
        )
        return {
            "spool_path": str(spool_path),
            "source_hint": source_hint,
            "ingested": 0,
            "duplicates": 0,
            "parse_errors": 0,
            "last_offset": last_offset,
            "exists": False,
        }

    inode, mtime_ns = file_inode_key(spool_path)
    file_size = spool_path.stat().st_size
    if previous_inode and previous_inode != inode:
        last_offset = 0
    elif file_size < last_offset:
        last_offset = 0

    ingested = 0
    duplicates = 0
    parse_errors = 0

    with spool_path.open("rb") as handle:
        handle.seek(last_offset)
        chunk = handle.read()
        end_offset = handle.tell()

    if chunk:
        lines = chunk.split(b"\n")
        trailing_fragment = b""
        if chunk[-1:] != b"\n":
            trailing_fragment = lines.pop()
        safe_end_offset = end_offset - len(trailing_fragment)

        consumed_offset = last_offset
        for raw_line in lines:
            consumed_offset += len(raw_line) + 1
            stripped = raw_line.strip()
            last_offset = consumed_offset
            if not stripped:
                continue

            try:
                payload = json.loads(stripped.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                parse_errors += 1
                last_error = f"json_decode_error:{exc}@{consumed_offset}"
                print(
                    json.dumps(
                        {
                            "warning": "merge_spool_parse_error",
                            "spool_path": str(spool_path),
                            "source_hint": source_hint,
                            "offset": consumed_offset,
                            "error": str(exc),
                        },
                        ensure_ascii=False,
                    ),
                    file=sys.stderr,
                )
                continue

            event = normalize_event(payload)
            if store.has_source_event(event.source_event_id):
                duplicates += 1
                continue
            store.ingest(event)
            ingested += 1

        if safe_end_offset > last_offset:
            last_offset = safe_end_offset

    store.upsert_spool_state(
        spool_path,
        source_hint=source_hint,
        inode=inode,
        last_offset=last_offset,
        last_mtime_ns=mtime_ns,
        last_error=last_error,
    )
    return {
        "spool_path": str(spool_path),
        "source_hint": source_hint,
        "ingested": ingested,
        "duplicates": duplicates,
        "parse_errors": parse_errors,
        "last_offset": last_offset,
        "exists": True,
    }


def parse_args() -> argparse.Namespace:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--native-log", type=Path, default=base / "events.jsonl")
    parser.add_argument("--baileys-log", type=Path, default=base / "baileys-events.jsonl")
    parser.add_argument("--db", type=Path, default=base / "merged-events.sqlite3")
    parser.add_argument("--status-json", type=Path, default=base / "merge-status.json")
    parser.add_argument("--interval", type=float, default=2.0)
    parser.add_argument("--follow", action="store_true")
    parser.add_argument("--verbose-duplicates", action="store_true")
    parser.add_argument("--status", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    store = MergeStore(args.db)
    if args.status:
        print(json.dumps(store.status(), ensure_ascii=False, indent=2))
        return 0

    sources = [
        ("notification_center_ax", args.native_log),
        ("baileys", args.baileys_log),
    ]

    def run_cycle() -> dict[str, Any]:
        cycle_results = [ingest_spool(store, path, source_hint=source_hint) for source_hint, path in sources]
        result = {
            "runner": "merge_collector_events",
            "runner_version": "0.2.1",
            "mode": "follow" if args.follow else "once",
            "run_at": utc_now(),
            "ingested": sum(result["ingested"] for result in cycle_results),
            "duplicates": sum(result["duplicates"] for result in cycle_results),
            "parse_errors": sum(result["parse_errors"] for result in cycle_results),
            "cycle_results": cycle_results,
            **store.status(),
        }
        store.upsert_heartbeat(
            "merge_collector_events",
            {
                "pid": os.getpid(),
                "follow": args.follow,
                "interval": args.interval,
                "native_log": str(args.native_log),
                "baileys_log": str(args.baileys_log),
                "status_json": str(args.status_json),
                "ingested": result["ingested"],
                "duplicates": result["duplicates"],
                "parse_errors": result["parse_errors"],
                "verbose_duplicates": args.verbose_duplicates,
            },
        )
        result = store.status() | {
            "runner": result["runner"],
            "runner_version": result["runner_version"],
            "mode": result["mode"],
            "run_at": result["run_at"],
            "ingested": result["ingested"],
            "duplicates": result["duplicates"],
            "parse_errors": result["parse_errors"],
            "cycle_results": cycle_results,
        }
        atomic_write_json(args.status_json, result)
        return result

    if args.follow:
        try:
            while True:
                result = run_cycle()
                if result["ingested"] or result["parse_errors"] or (args.verbose_duplicates and result["duplicates"]):
                    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            pass
        return 0

    print(json.dumps(run_cycle(), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
